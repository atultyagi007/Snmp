package com.hcl.snmp;
/**
 * Constant class for SNMPUtill. It have all global constants.
 * 
 * @author HCL Technologies
 * 
 */
public class SNMPUtilConstant {
	public static final String GET = "GET";
	public static final String GETNEXT = "GETNEXT";
	public static final String GETBULK = "GETBULK";
	public static final int    NON_REPEATER = 0;
	public static final String VERSION1 = "v1";
	public static final String VERSION2C = "v2c";
	public static final String VERSION3 = "v3";
	public static final String AUTH_PRIV = "AuthPriv";
	public static final String AUTH_NOPRIV = "AuthNoPriv";
	public static final String NOAUTH_NOPRIV = "NoAuthNoPriv";
	public static final String MD5 = "MD5";
	public static final String SHA = "SHA";
	public static final String AES = "AES";
	public static final String DES = "DES";
	public static final String DES3 = "3DES";
	public static final String AES128 = "AES128";
	public static final String AES192 = "AES192";
	public static final String AES256 = "AES256";

}
