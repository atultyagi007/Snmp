package com.hcl.snmp;

import org.snmp4j.PDU;
import org.snmp4j.smi.VariableBinding;

import com.hcl.probe.Constants;
import com.nimsoft.nimbus.NimAlarm;
import com.nimsoft.nimbus.NimException;
import com.nimsoft.pf.common.log.Log;

public class UCCEAlarms {
	public void generateUCCEAlarm(PDU pdu, String source){
		int severity = 0;
		String message = Constants.CCCA_ICM_EVENT_MESSAGE;
		String messageId = "";
		for(VariableBinding vb: pdu.getVariableBindings()){
			if(vb.getOid().toString().equals(Constants.CCCA_EVENT_SEVERITY_OID)){
				severity = setUCCESeverity(vb.getVariable().toString());
			}else if(vb.getOid().toString().equals(Constants.CCCA_EVENT_MESSAGE_ID_OID)){
				messageId = vb.getVariable().toString();
			}else if(vb.getOid().toString().equals(Constants.CCCA_EVENT_TEXT_OID)){
				message = message.replace("%CccaEventText", vb.getVariable().toString());
			}else if(vb.getOid().toString().equals(Constants.CCCA_EVENT_TIMESTAMP_OID)){
				message = message.replace("%CccaEventTimestamp", vb.getVariable().toString());
			}else if(vb.getOid().toString().equals(Constants.CCCA_EVENT_ORIGINATING_PROCESS_NAME_OID)){
				message = message.replace("%CccaEventOriginatingProcessName", vb.getVariable().toString());
			}
		}
		if(TrapReceiver.ucceMessageIdMap.containsKey(messageId)){
			String action = TrapReceiver.ucceMessageIdMap.get(messageId);
			if(action.equals("No action needed")){
				TrapReceiver.ucceTrapLog.info(message);
			}else if(action.equals("Page out to the ICM Support Team")){
				TrapReceiver.ucceTrapLog.info(message);
				TrapReceiver.icmTrapLog.info(message);
			}else if(action.equals("Email ICM Support Team")){
				
			}
			try{
				NimAlarm alarm = null;
				alarm = new NimAlarm(severity, message, Constants.SUBSYSTEM_ID, "supressionId", source ,null, "metricId");
				alarm.send();
				alarm.close();
			}catch(NimException nimException){
				Log.error(nimException.getMessage());
			}
		}
	}

	public int setUCCESeverity(String variable){
		int sev=0;
		if(variable.equals("1")){
			sev =1;
		}else if(variable.equals("2")){
			sev =2;
		}else if(variable.equals("3")){
			sev =4;
		}
		return sev;
	}
}
