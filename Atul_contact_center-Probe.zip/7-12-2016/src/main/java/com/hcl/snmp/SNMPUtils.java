package com.hcl.snmp;

import java.io.IOException;
import java.util.List;
import java.util.Vector;

import org.snmp4j.CommunityTarget;
import org.snmp4j.MessageDispatcher;
import org.snmp4j.PDU;
import org.snmp4j.Snmp;
import org.snmp4j.TransportMapping;
import org.snmp4j.event.ResponseEvent;
import org.snmp4j.mp.SnmpConstants;
import org.snmp4j.security.AuthMD5;
import org.snmp4j.security.AuthSHA;
import org.snmp4j.security.Priv3DES;
import org.snmp4j.security.PrivAES128;
import org.snmp4j.security.PrivAES192;
import org.snmp4j.security.PrivAES256;
import org.snmp4j.security.PrivDES;
import org.snmp4j.security.SecurityLevel;
import org.snmp4j.security.UsmUser;
import org.snmp4j.smi.Address;
import org.snmp4j.smi.GenericAddress;
import org.snmp4j.smi.Integer32;
import org.snmp4j.smi.Null;
import org.snmp4j.smi.OID;
import org.snmp4j.smi.OctetString;
import org.snmp4j.smi.VariableBinding;
import org.snmp4j.transport.DefaultUdpTransportMapping;
import org.snmp4j.util.DefaultPDUFactory;
import org.snmp4j.util.PDUFactory;
import org.snmp4j.util.TableEvent;
import org.snmp4j.util.TableUtils;

import com.nimsoft.pf.common.log.Log;

/**
 * Copyright HCL Technologies. All rights reserved.
 * @author HCL Technologies
 * The SNMPUtils class implements an application that is used to perform SNMP actions.
 * 
 */
public class SNMPUtils {
	//final static Logger logger = Logger.getLogger(SNMPUtils.class);
	/**
	 * Returns Vector of VariableBinding which contains polled value of all OIDs.
	 * The List of OID and SnmpCreditionals object is given by user, which is used for polling.
	 * @param  SnmpCreditionals object contains user inputs for SNMP GET, GETNEXT and GETBULK.
	 * @param  oidList is a List of OIDs which need to be polled. 
	 * @return Vector of VariableBinding.
	 */
	public static Vector<? extends VariableBinding> poll(SnmpCreditionals snmpCreditional,List<String> oidList){
		Vector<? extends VariableBinding> variableBindingList=null;		
		try {
			@SuppressWarnings("rawtypes")
			TransportMapping transport = new DefaultUdpTransportMapping();
			Snmp snmp=null;
			//getTarget method return   CommunityTarget object with setting of all parameter in this object.
			CommunityTarget target = getTarget(snmpCreditional);
			PDU pdu = new PDU();
			//check the Request type and set this in PDU object.
			if(snmpCreditional.getRequestType()  != null){
				if(snmpCreditional.getRequestType().equalsIgnoreCase(SNMPUtilConstant.GET)){
					//logger.debug("Request type == GET");
					pdu.setType(PDU.GET);
				}else if(snmpCreditional.getRequestType().equalsIgnoreCase(SNMPUtilConstant.GETNEXT))
				{
					//logger.debug("Request type == GETNEXT");
					pdu.setType(PDU.GETNEXT);
				}else if(snmpCreditional.getRequestType().equalsIgnoreCase(SNMPUtilConstant.GETBULK))
				{
					//logger.debug("Request type == GETBULK");
					pdu.setType(PDU.GETBULK);
					//Sets the number of non repeater variable bindings in a GETBULK PDU.
					pdu.setNonRepeaters(SNMPUtilConstant.NON_REPEATER);
				}
				else{
					//logger.error("Not Valid SNMP Request Type");
				}
			}
			else{ 
				//logger.error("SNMP Request Type is NULL");
			}
			// Get all the OID list and Add in PDU object which has to be polled .
			for(String oid:oidList){
				//logger.debug(oid+"  OID added to PDU");
				pdu.add(new VariableBinding(new OID(oid)));
			}
			//if version is V3, add some other security information like user name,password ,private password into SNMP object.
			if(snmpCreditional.getVersion().equals(SNMPUtilConstant.VERSION3)){
				//logger.debug("version == v3");
				snmp = addUSMUser(snmpCreditional, transport,null);
			}else{
				//logger.debug("create SNMP object");
				snmp = new Snmp(transport);
			}
			//logger.debug("call listen method on SNMP object");
			snmp.listen(); //Puts all associated transport mappings into listen mode
			//Sends a PDU to the given target .
			//logger.debug("Sends a PDU to the given target");
			ResponseEvent responseEvent = snmp.send(pdu, target); 
			//Gets the response PDU.
			PDU responsePDU = responseEvent.getResponse(); 
			//logger.debug("Gets the response PDU");
			//Gets the variable binding object which contains all information of given OID.
			variableBindingList =responsePDU.getVariableBindings();
			//logger.debug("Gets the variable binding vector  " +variableBindingList.toString());
			//Closes the session and frees any allocated resources
			snmp.close();
			//logger.debug("Closes the session");
		} catch (IOException ioException) {
			//logger.error(ioException);
		}
		return variableBindingList;
	}
	
	/**
	 * Returns Vector of VariableBinding which contains polled value of all OIDs.
	 * The List of OID and SnmpCreditionals object is given by user, which is used for polling.
	 * @param  SnmpCreditionals object contains user inputs for SNMP GET, GETNEXT and GETBULK.
	 * @param  oidList is a List of OIDs which need to be polled. 
	 * @return Vector of VariableBinding.
	 */
	public static VariableBinding poll(SnmpCreditionals snmpCreditional,String oid){
		VariableBinding variableBinding = null;		
		try {
			@SuppressWarnings("rawtypes")
			TransportMapping transport = new DefaultUdpTransportMapping();
			Snmp snmp=null;
			//getTarget method return   CommunityTarget object with setting of all parameter in this object.
			CommunityTarget target = getTarget(snmpCreditional);
			PDU pdu = new PDU();
			//check the Request type and set this in PDU object.
			if(snmpCreditional.getRequestType()  != null){
				if(snmpCreditional.getRequestType().equalsIgnoreCase(SNMPUtilConstant.GET)){
					//logger.debug("Request type == GET");
					pdu.setType(PDU.GET);
				}else if(snmpCreditional.getRequestType().equalsIgnoreCase(SNMPUtilConstant.GETNEXT))
				{
					//logger.debug("Request type == GETNEXT");
					pdu.setType(PDU.GETNEXT);
				}else if(snmpCreditional.getRequestType().equalsIgnoreCase(SNMPUtilConstant.GETBULK))
				{
					//logger.debug("Request type == GETBULK");
					pdu.setType(PDU.GETBULK);
					//Sets the number of non repeater variable bindings in a GETBULK PDU.
					pdu.setNonRepeaters(SNMPUtilConstant.NON_REPEATER);
				}
				else{
					//logger.error("Not Valid SNMP Request Type");
				}
			}
			else{ 
				//logger.error("SNMP Request Type is NULL");
			}
			// Add OID in PDU object which has to be polled .
				pdu.add(new VariableBinding(new OID(oid)));
			//if version is V3, add some other security information like user name,password ,private password into SNMP object.
			if(snmpCreditional.getVersion().equals(SNMPUtilConstant.VERSION3)){
				//logger.debug("version == v3");
				snmp = addUSMUser(snmpCreditional, transport,null);
			}else{
				//logger.debug("create SNMP object");
				snmp = new Snmp(transport);
			}
			//logger.debug("call listen method on SNMP object");
			snmp.listen(); //Puts all associated transport mappings into listen mode
			//Sends a PDU to the given target .
			//logger.debug("Sends a PDU to the given target");
			ResponseEvent responseEvent = snmp.send(pdu, target); 
			//Gets the response PDU.
			PDU responsePDU = responseEvent.getResponse(); 
			//logger.debug("Gets the response PDU");
			//Gets the variable binding object which contains all information of given OID.
			variableBinding =responsePDU.getVariableBindings().get(0);
			//logger.debug("Gets the variable binding vector  " +variableBinding.toString());
			//Closes the session and frees any allocated resources
			snmp.close();
			//logger.debug("Closes the session");
		} catch (IOException ioException) {
			Log.info("########################Exception in polling:-"+ioException);
			//logger.error(ioException);
		}
		return variableBinding;
	}
	
	public static Vector<? extends VariableBinding> pollBulk(SnmpCreditionals snmpCreditional,String oid){
		Vector<? extends VariableBinding> variableBindingList=null;		
		try {
			@SuppressWarnings("rawtypes")
			TransportMapping transport = new DefaultUdpTransportMapping();
			Snmp snmp=null;
			//getTarget method return   CommunityTarget object with setting of all parameter in this object.
			CommunityTarget target = getTarget(snmpCreditional);
			PDU pdu = new PDU();
			//check the Request type and set this in PDU object.
			if(snmpCreditional.getRequestType()  != null){
				//logger.debug("Request type == GETBULK");
				pdu.setType(PDU.GETBULK);
				//Sets the number of non repeater variable bindings in a GETBULK PDU.
				pdu.setNonRepeaters(SNMPUtilConstant.NON_REPEATER);
				pdu.setMaxRepetitions(200);
				
			}
			else{ 
				//logger.error("SNMP Request Type is NULL");
			}
			// Get all the OID list and Add in PDU object which has to be polled .
			
			//logger.debug(oid+"  OID added to PDU");
			pdu.add(new VariableBinding(new OID(oid)));
			
			//if version is V3, add some other security information like user name,password ,private password into SNMP object.
			if(snmpCreditional.getVersion().equals(SNMPUtilConstant.VERSION3)){
				//logger.debug("version == v3");
				snmp = addUSMUser(snmpCreditional, transport,null);
			}else{
				//logger.debug("create SNMP object");
				snmp = new Snmp(transport);
			}
			//logger.debug("call listen method on SNMP object");
			snmp.listen(); //Puts all associated transport mappings into listen mode
			//Sends a PDU to the given target .
			//logger.debug("Sends a PDU to the given target");
			ResponseEvent responseEvent = snmp.send(pdu, target); 
			//Gets the response PDU.
			PDU responsePDU = responseEvent.getResponse(); 
			//logger.debug("Gets the response PDU");
			//Gets the variable binding object which contains all information of given OID.
			variableBindingList =responsePDU.getVariableBindings();
			//logger.debug("Gets the variable binding vector  " +variableBindingList.toString());
			//Closes the session and frees any allocated resources
			snmp.close();
			//logger.debug("Closes the session");
		} catch (IOException ioException) {
			//logger.error(ioException);
		}
		return variableBindingList;
	}	
	/**
	 * Return the CommunityTarget by setting different properties of device provided by user.
	 * @param  SnmpCreditionals object contains user inputs for SNMP GET.	 
	 * @return CommunityTarget of the device.
	 */	
	public static CommunityTarget getTarget(SnmpCreditionals snmpCreditional){
		String version=snmpCreditional.getVersion();
		CommunityTarget target = new CommunityTarget(); 
		//Parses a given transport protocol dependent address string into an Address instance that is subsumed by this GenericAddress object
		//logger.debug("Parses a given transport protocol dependent address string into an Address instance");
		Address targetAddress = GenericAddress.parse("udp:"+snmpCreditional.getIpAddress()+"/"+snmpCreditional.getPort());
		//set community string into CommunityTarget object.
		//logger.debug("set community string == "+ snmpCreditional.getCommunity()+"  into CommunityTarget object");
		target.setCommunity(new OctetString(snmpCreditional.getCommunity())); 
		//set targetAddress  into CommunityTarget object.
		//logger.debug("set targetAddress string into CommunityTarget object");
		target.setAddress(targetAddress); 
		//set Retry  into CommunityTarget object.
		//logger.debug("set Retry  into CommunityTarget object");
		target.setRetries(snmpCreditional.getRetry());
		//set Timeout  into CommunityTarget object.
		//logger.debug("set Timeout  "+snmpCreditional.getTimeout() +"  into CommunityTarget object");
		target.setTimeout(snmpCreditional.getTimeout()); 
		//check if the SNMP version is null or not.
		if(version != null){
			//if version is V1 set it in the target object.
			if(version.equalsIgnoreCase(SNMPUtilConstant.VERSION1) ){
				//logger.debug("version == version1");
				target.setVersion(SnmpConstants.version1);
			}
			//if version is V2C set it in the target object.
			if(version.equalsIgnoreCase(SNMPUtilConstant.VERSION2C) ){
				//logger.debug("version == version2c");
				target.setVersion(SnmpConstants.version2c);
			}
			//if version is V3 set it in the target object
			if(version.equals(SNMPUtilConstant.VERSION3) ){
				//logger.debug("version == version3");
				target.setVersion(SnmpConstants.version3);
				//set the security level as AuthPriv in to target object.
				if(snmpCreditional.getSecurityLevel().equalsIgnoreCase(SNMPUtilConstant.AUTH_PRIV)){
					//logger.debug("SecurityLevel == AuthPriv");
					target.setSecurityLevel(SecurityLevel.AUTH_PRIV);
					target.setSecurityName(new OctetString(snmpCreditional.getUserName()));
					
				}
				//set the security level as AuthNoPriv in to target object.
				else if(snmpCreditional.getSecurityLevel().equalsIgnoreCase(SNMPUtilConstant.AUTH_NOPRIV)){
					//logger.debug("SecurityLevel == AuthNoPriv");
					target.setSecurityLevel(SecurityLevel.AUTH_NOPRIV);
					target.setSecurityName(new OctetString(snmpCreditional.getUserName()));
				}
				//set the security level as NoAuthNoPriv in to target object.
				else{
					//logger.debug("SecurityLevel == NOAUTH_NOPRIV");
					target.setSecurityLevel(SecurityLevel.NOAUTH_NOPRIV);
					target.setSecurityName(new OctetString(snmpCreditional.getUserName()));
				}
			}}else {
				//logger.error("version is null");
			}
		return target;
	}
	
	/**
	 * This method is used to add user for SNMP version 3. The user contains information about authentication and encryption.
	 * @param  SnmpCreditionals object contains user inputs for SNMP GET.
	 * @param  TransportMapping
	 * @param  MessageDispatcher is used in Traps while MultiThreadedMessageDispatcher. This value is used to invoke Snmp class constructor with MessageDispatcher.
	 * @return Snmp object with information of SNMP version 3 user.
	 */		
	public static Snmp addUSMUser(SnmpCreditionals snmpCreditional,@SuppressWarnings("rawtypes") TransportMapping transport,MessageDispatcher mtDispatcher){
		Snmp snmp = null;
		if(mtDispatcher != null){
			//logger.debug("MessageDispatcher != null");
			snmp = new Snmp(mtDispatcher, transport); 
		}else{
			//logger.debug("MessageDispatcher == null");
			snmp = new Snmp(transport);
		}
		// Check the SecurityLevel existence 
		//logger.debug("Check the SecurityLevel existence");
		if(snmpCreditional.getSecurityLevel() != null){
			//if SecurityLevel is AuthPriv ,set all user information into SNMP object.
			if(snmpCreditional.getSecurityLevel().equalsIgnoreCase(SNMPUtilConstant.AUTH_PRIV))
			{
				//logger.debug("SecurityLevel == AuthPriv");
				//Check null for  authentication field.
				if(snmpCreditional.getAuthentication() != null){
					//if  Authentication is AuthMD5  ,set all user information into SNMP object.
					if(snmpCreditional.getAuthentication().equalsIgnoreCase(SNMPUtilConstant.MD5)){
						//logger.debug("Authentication == AuthMD5");
						String encryption=snmpCreditional.getEncryption();
						if(encryption.equalsIgnoreCase(SNMPUtilConstant.DES)){
							//logger.debug("encryption == DES");
							snmp.getUSM().addUser(new OctetString(snmpCreditional.getUserName()),new UsmUser(new OctetString(snmpCreditional.getUserName()),AuthMD5.ID,new OctetString(snmpCreditional.getAuth_password()),PrivDES.ID,new OctetString(snmpCreditional.getPrivatePassWord())));
						}else if(encryption.equalsIgnoreCase(SNMPUtilConstant.DES3)){
							//logger.debug("encryption == 3DES");
							snmp.getUSM().addUser(new OctetString(snmpCreditional.getUserName()),new UsmUser(new OctetString(snmpCreditional.getUserName()),AuthMD5.ID,new OctetString(snmpCreditional.getAuth_password()),Priv3DES.ID,new OctetString(snmpCreditional.getPrivatePassWord())));
						}else if(encryption.equalsIgnoreCase(SNMPUtilConstant.AES128) || encryption.equalsIgnoreCase(SNMPUtilConstant.AES)){
							//logger.debug("encryption == "+snmpCreditional.getEncryption());
							snmp.getUSM().addUser(new OctetString(snmpCreditional.getUserName()),new UsmUser(new OctetString(snmpCreditional.getUserName()),AuthMD5.ID,new OctetString(snmpCreditional.getAuth_password()),PrivAES128.ID,new OctetString(snmpCreditional.getPrivatePassWord())));
						}else if(encryption.equalsIgnoreCase(SNMPUtilConstant.AES192)){
							//logger.debug("encryption == AES192");
							snmp.getUSM().addUser(new OctetString(snmpCreditional.getUserName()),new UsmUser(new OctetString(snmpCreditional.getUserName()),AuthMD5.ID,new OctetString(snmpCreditional.getAuth_password()),PrivAES192.ID,new OctetString(snmpCreditional.getPrivatePassWord())));
						}else if(encryption.equalsIgnoreCase(SNMPUtilConstant.AES256)){
							//logger.debug("encryption == AES256");
							snmp.getUSM().addUser(new OctetString(snmpCreditional.getUserName()),new UsmUser(new OctetString(snmpCreditional.getUserName()),AuthMD5.ID,new OctetString(snmpCreditional.getAuth_password()),PrivAES256.ID,new OctetString(snmpCreditional.getPrivatePassWord())));
						}else {
							//logger.error("encryption is invalid");
						}
					}
					//if  Authentication is AuthSHA  ,set all user information into SNMP object.
					else if(snmpCreditional.getAuthentication().equalsIgnoreCase(SNMPUtilConstant.SHA)){
						//logger.debug("Authentication == AuthSHA");
						String encryption=snmpCreditional.getEncryption();
						if(encryption.equalsIgnoreCase(SNMPUtilConstant.DES)){
							//logger.debug("encryption == DES");
							snmp.getUSM().addUser(new OctetString(snmpCreditional.getUserName()),new UsmUser(new OctetString(snmpCreditional.getUserName()),AuthSHA.ID,new OctetString(snmpCreditional.getAuth_password()),PrivDES.ID,new OctetString(snmpCreditional.getPrivatePassWord())));
						}else if(encryption.equalsIgnoreCase(SNMPUtilConstant.DES3)){
							//logger.debug("encryption == 3DES");
							snmp.getUSM().addUser(new OctetString(snmpCreditional.getUserName()),new UsmUser(new OctetString(snmpCreditional.getUserName()),AuthSHA.ID,new OctetString(snmpCreditional.getAuth_password()),Priv3DES.ID,new OctetString(snmpCreditional.getPrivatePassWord())));
						}else if(encryption.equalsIgnoreCase(SNMPUtilConstant.AES128) || encryption.equalsIgnoreCase(SNMPUtilConstant.AES)){
							//logger.debug("encryption == "+snmpCreditional.getEncryption());
							snmp.getUSM().addUser(new OctetString(snmpCreditional.getUserName()),new UsmUser(new OctetString(snmpCreditional.getUserName()),AuthSHA.ID,new OctetString(snmpCreditional.getAuth_password()),PrivAES128.ID,new OctetString(snmpCreditional.getPrivatePassWord())));
						}else if(encryption.equalsIgnoreCase(SNMPUtilConstant.AES192)){
							//logger.debug("encryption == AES192");
							snmp.getUSM().addUser(new OctetString(snmpCreditional.getUserName()),new UsmUser(new OctetString(snmpCreditional.getUserName()),AuthSHA.ID,new OctetString(snmpCreditional.getAuth_password()),PrivAES192.ID,new OctetString(snmpCreditional.getPrivatePassWord())));
						}else if(encryption.equalsIgnoreCase(SNMPUtilConstant.AES256)){
							//logger.debug("encryption == AES256");
							snmp.getUSM().addUser(new OctetString(snmpCreditional.getUserName()),new UsmUser(new OctetString(snmpCreditional.getUserName()),AuthSHA.ID,new OctetString(snmpCreditional.getAuth_password()),PrivAES256.ID,new OctetString(snmpCreditional.getPrivatePassWord())));
						}else {
							//logger.error("Invalid Encryption");
						}

					}else{
						//logger.error("Invalid Authentication");
					}}else{
						//logger.error("Authentication is null");
					}
			}
			//if SecurityLevel is AuthNoPriv ,set all user information into SNMP object.
			else if(snmpCreditional.getSecurityLevel().equalsIgnoreCase(SNMPUtilConstant.AUTH_NOPRIV)){
				//logger.debug("SecurityLevel == AuthNoPriv");
				if(snmpCreditional.getAuthentication().equalsIgnoreCase(SNMPUtilConstant.MD5)){
					//logger.debug("Authentication == AuthMD5");
					snmp.getUSM().addUser(new OctetString(snmpCreditional.getUserName()),new UsmUser(new OctetString(snmpCreditional.getUserName()),AuthMD5.ID,new OctetString(snmpCreditional.getAuth_password()),null,null));
				}else if(snmpCreditional.getAuthentication().equalsIgnoreCase(SNMPUtilConstant.SHA)){
					//logger.debug("Authentication == AuthSHA");
					snmp.getUSM().addUser(new OctetString(snmpCreditional.getUserName()),new UsmUser(new OctetString(snmpCreditional.getUserName()),AuthSHA.ID,new OctetString(snmpCreditional.getAuth_password()),null,null));
				}
			}
			//if SecurityLevel is NoAuthNoPriv ,set all user information into SNMP object.
			else{
				//logger.debug("SecurityLevel == NoAuthNoPriv");
				snmp.getUSM().addUser(new OctetString(snmpCreditional.getUserName()), new UsmUser(new OctetString(snmpCreditional.getUserName()), null, null,null, null));
			}}else{
				//logger.error("SecurityLevel is null");
			}
		return snmp;

	}
	
	public static Vector<? extends VariableBinding> getBulk1(SnmpCreditionals snmpCreditional,String oid){
        //Vector<? extends VariableBinding> ret=null; 
        Vector<VariableBinding> ret = new Vector<VariableBinding>();     
        PDU requestPDU = new PDU();
        OID rootOID = new OID(oid);
  requestPDU.add(new VariableBinding(rootOID,rootOID));
  requestPDU.setType(PDU.GETBULK);
  // maximum oid per pdu request
  requestPDU.setMaxRepetitions(1);

  CommunityTarget target = getTarget(snmpCreditional);
  
        try
  {
      TransportMapping transport = new DefaultUdpTransportMapping();
      Snmp snmp = new Snmp(transport);
      transport.listen();

      boolean finished = false;
      int iter = 0;

      while (!finished)
      {
      iter++;
          VariableBinding vb = null;

          ResponseEvent respEvt = snmp.send(requestPDU, target);
        //  Logger.getLogger(SnmpV2cUtils.class.getName()).log(Level.INFO,"GETBULK iteration number "+iter++);
          PDU responsePDU = respEvt.getResponse();
          
          if (responsePDU != null)
          {                    
              Vector<? extends VariableBinding> vbs = responsePDU.getVariableBindings();
              if (vbs!=null && vbs.size()>0)
              {
                  for (int i=0; i<vbs.size(); i++)
                  {
                      // vb sanity check
                      vb = (VariableBinding) vbs.get(i);
                      if (vb.getOid() == null)
                      {
                          //Logger.getLogger(SnmpV2cUtils.class.getName()).log(Level.INFO,"vb.getOid() == null");
                          finished = true;
                          break;
                      } else if (vb.getOid().size() < rootOID.size())
                      {
                          //Logger.getLogger(SnmpV2cUtils.class.getName()).log(Level.INFO,"vb.getOid().size() < targetOID.size()");
                          finished = true;
                          break;
                      } else if (rootOID.leftMostCompare(rootOID.size(), vb.getOid()) != 0)
                      {                    
                          //Logger.getLogger(SnmpV2cUtils.class.getName()).log(Level.INFO,"targetOID.leftMostCompare() != 0)");
                          finished = true;
                          break;
                      } else if (Null.isExceptionSyntax(vb.getVariable().getSyntax()))
                      {
                          //Logger.getLogger(SnmpV2cUtils.class.getName()).log(Level.INFO,"Null.isExceptionSyntax(vb.getVariable().getSyntax())");
                          finished = true;
                          break;
                      } else if (vb.getOid().compareTo(rootOID) <= 0)
                      {
                             //Logger.getLogger(SnmpV2cUtils.class.getName()).log(Level.INFO,"Variable received is not "+"lexicographic successor of requested "+"one:");
                          //Logger.getLogger(SnmpV2cUtils.class.getName()).log(Level.INFO,vb.toString() + " <= "+rootOID);
                          finished = true;
                          break;
                      } 
                      ret.add(vb);
                  }                        
              }
          }

          if (!finished)
          {
              if (responsePDU == null)
              {
                  
                  //Logger.getLogger(SnmpV2cUtils.class.getName()).log(Level.INFO,"responsePDU == null");
                  finished = true;
                  
              } else if (responsePDU.getErrorStatus() != 0)
              {
                  //Logger.getLogger(SnmpV2cUtils.class.getName()).log(Level.INFO,"responsePDU.getErrorStatus() != 0");
                  //Logger.getLogger(SnmpV2cUtils.class.getName()).log(Level.INFO,responsePDU.getErrorStatusText());
                  finished = true;
              } else {                    
                  // Set up the variable binding for the next entry.
                  requestPDU.setRequestID(new Integer32(0));
                  requestPDU.set(0, vb);
              }
          }
      }
      snmp.close();
  } catch (IOException e)
  {
  }
        return (Vector<? extends VariableBinding>) ret;
 }
 
	public static Vector<? extends VariableBinding> getBulk(SnmpCreditionals snmpCreditional, String oid) {
		Vector<VariableBinding> ret = new Vector<VariableBinding>();
		Snmp snmp= null;
		try{
			OID query = new OID(oid);
		    final TransportMapping transport = new DefaultUdpTransportMapping();
		    snmp = new Snmp(transport);
		    snmp.listen();
		    final CommunityTarget target = getTarget(snmpCreditional);
		    // creating PDU
		    final PDUFactory pduFactory = new DefaultPDUFactory(PDU.GETBULK);
		    final TableUtils utils = new TableUtils(snmp, pduFactory);
		    List<TableEvent> obj= utils.getTable(target, new OID[]{ query }, null, null);
		    for(TableEvent t:obj){
				VariableBinding vb1[]=t.getColumns();
				ret.add(vb1[0]);
			}		    
		}catch(Exception ex){
			Log.error(ex.toString());
		}finally{
			try {
				snmp.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				Log.error(e.toString());
			}
		}
	    return ret;
	}
	
public static void main(String args[]){
	try{
		SnmpCreditionals obj=new SnmpCreditionals();
		obj.setIpAddress("10.112.73.248");
		obj.setCommunity("public");
		obj.setPort("161");
		obj.setRequestType("BULK");
		obj.setVersion("v2c");
		Vector<? extends VariableBinding> indexList = SNMPUtils.getBulk(obj,".1.3.6.1.4.1.9.9.156.1.3.1.1.2");
		System.out.println(indexList.size());
		for(VariableBinding vb:indexList){
			System.out.println("oid: "+vb.getOid()+" value: "+vb.getVariable());
		}
	}catch(Exception ex){
		Log.error("error: "+ex);
	}
	
}

}
