package com.hcl.snmp;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Set;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.snmp4j.CommandResponder;
import org.snmp4j.CommandResponderEvent;
import org.snmp4j.CommunityTarget;
import org.snmp4j.MessageDispatcher;
import org.snmp4j.MessageDispatcherImpl;
import org.snmp4j.PDU;
import org.snmp4j.Snmp;
import org.snmp4j.mp.MPv1;
import org.snmp4j.mp.MPv2c;
import org.snmp4j.mp.MPv3;
import org.snmp4j.smi.OctetString;
import org.snmp4j.smi.TcpAddress;
import org.snmp4j.smi.TransportIpAddress;
import org.snmp4j.smi.UdpAddress;
import org.snmp4j.smi.VariableBinding;
import org.snmp4j.transport.AbstractTransportMapping;
import org.snmp4j.transport.DefaultTcpTransportMapping;
import org.snmp4j.transport.DefaultUdpTransportMapping;
import org.snmp4j.util.MultiThreadedMessageDispatcher;
import org.snmp4j.util.ThreadPool;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.hcl.probe.Constants;
import com.nimsoft.nimbus.NimConfig;
import com.nimsoft.nimbus.NimException;
import com.nimsoft.nimbus.NimRequest;
import com.nimsoft.nimbus.PDS;
import com.nimsoft.pf.common.log.Log;

public class TrapReceiver implements CommandResponder
{
	static HashMap<String,String> trapMap = null;
	static HashMap<String,String> ucceMessageIdMap = null;
	public static final Logger ucceTrapLog = LogManager.getLogger("ucceTrapLog");
	public static final Logger icmTrapLog = LogManager.getLogger("icmTrapLog");
	
	public TrapReceiver(){
		trapMap = getTrapMap();
		ucceMessageIdMap = getUcceMessageIdMap();
		Set<String> dd = ucceMessageIdMap.keySet();
		for(String ddd : dd){
			System.out.println("<msg messageId=\""+ddd+"\" action=\""+ucceMessageIdMap.get(ddd));
		}
		System.out.println(ucceMessageIdMap.size());
	}

	public static void main(String[] args)
	{
		 startTrapReceiver();
	}

	public static void startTrapReceiver(){
		TrapReceiver snmp4jTrapReceiver = new TrapReceiver();
		try
		{
			PDS controllerCallbackPDS = new PDS();
			controllerCallbackPDS = snmp4jTrapReceiver.sendRequest(Constants.CONTROLLER_PATH, Constants.CONTROLLER_CALLBACK_GET_INFO);
			NimConfig configReader = new NimConfig("contact_center.cfg");
			if(controllerCallbackPDS != null && controllerCallbackPDS.size() > 0){
				if(controllerCallbackPDS.containsKey(Constants.CONTROLLER_CALLBACK_GET_INFO_ROBOT_IP)){
					SnmpCreditionals snmpCredential = new SnmpCreditionals();
					snmpCredential.setIpAddress(controllerCallbackPDS.getString(Constants.CONTROLLER_CALLBACK_GET_INFO_ROBOT_IP));
					snmpCredential.setPort(configReader.getValue("/TrapConfig/", "port"));
					snmpCredential.setVersion(configReader.getValue("/TrapConfig/", "version"));
					snmpCredential.setCommunity(configReader.getValue("/TrapConfig/", "community"));
					snmp4jTrapReceiver.listen(snmpCredential);
				}else{
					Log.error(Constants.ROBOT_IP_NOT_FOUND);
					Log.error(Constants.TRAP_LISTENING_NOT_STARTED);
				}
			}else{
				Log.error(Constants.CONTROLLER_PDS_NULL);
				Log.error(Constants.TRAP_LISTENING_NOT_STARTED);
			}



		}
		catch(IOException io)
		{
			Log.error(Constants.TRAP_LISTENING_ERROR);
			Log.error(Constants.EXCEPTION_MESSAGE + io.getMessage());
			Log.error(Constants.TRAP_LISTENING_NOT_STARTED);

		}catch(NimException ne){
			Log.error(Constants.CONTROLLER_IP_RETREIVING_ERROR);
			Log.error(Constants.EXCEPTION_MESSAGE + ne.getMessage());
			Log.error(Constants.TRAP_LISTENING_NOT_STARTED);
		}
	}

	private PDS sendRequest(String probePath, String probeCommand) throws NimException {
		NimRequest request = new NimRequest(probePath, probeCommand);
		PDS pds = new PDS();
		pds = request.send();
		request.close();
		return pds;
	}

	public HashMap<String,String> getTrapMap(){
		String fileName= Constants.TRAP_FILE_NAME;
		InputStream in = getClass().getResourceAsStream(fileName); 
		trapMap = new HashMap<String, String>();
		try{
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(in);
			NodeList trapListNode = doc.getElementsByTagName(Constants.TRAP);
			for(int trapCount = 0; trapCount < trapListNode.getLength(); trapCount++){
				Node trapNode = trapListNode.item(trapCount);
				Element trapElement = (Element) trapNode;
				String trapOid= trapElement.getAttribute(Constants.OID);
				String attributeName= trapElement.getAttribute(Constants.ATTRIBUTE_NAME);
				trapMap.put(trapOid, attributeName);
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return trapMap;
	}

	public HashMap<String,String> getUcceMessageIdMap(){
		String fileName= Constants.UCCE_MESSAGE_ID_FILE_NAME;
		InputStream in = getClass().getResourceAsStream(fileName); 
		ucceMessageIdMap = new HashMap<String, String>();
		try{
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(in);
			NodeList messageListNode = doc.getElementsByTagName("msg");
			for(int messageCount = 0; messageCount < messageListNode.getLength(); messageCount++){
				Node msgNode = messageListNode.item(messageCount);
				Element msgElement = (Element) msgNode;
				String messageId = msgElement.getAttribute("messageId");
				String action = msgElement.getAttribute("action");
				ucceMessageIdMap.put(messageId, action);
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return ucceMessageIdMap;
	}	


	/**
	 * This method will listen for traps and response pdu's from SNMP agent.
	 */
	public synchronized void listen(SnmpCreditionals snmpCredential) throws IOException
	{
		TransportIpAddress address = new UdpAddress(snmpCredential.getIpAddress()+"/"+snmpCredential.getPort());
		@SuppressWarnings("rawtypes")
		AbstractTransportMapping transport;
		if (address instanceof TcpAddress)
		{
			transport = new DefaultTcpTransportMapping((TcpAddress) address);
		}
		else
		{
			transport = new DefaultUdpTransportMapping((UdpAddress) address);
		}

		ThreadPool threadPool = ThreadPool.create("DispatcherPool", 10);		
		MessageDispatcher mtDispatcher = new MultiThreadedMessageDispatcher(threadPool, new MessageDispatcherImpl());
		CommunityTarget target = new CommunityTarget();
		Snmp snmp =null;

		if(snmpCredential.getVersion().equalsIgnoreCase("v1")){
			mtDispatcher.addMessageProcessingModel(new MPv1());
			target.setCommunity( new OctetString(snmpCredential.getCommunity()));
			snmp = new Snmp(mtDispatcher, transport);  
		}else if(snmpCredential.getVersion().equalsIgnoreCase("v2c")){
			mtDispatcher.addMessageProcessingModel(new MPv2c());
			target.setCommunity( new OctetString(snmpCredential.getCommunity()));
			snmp = new Snmp(mtDispatcher, transport);   
		}else if(snmpCredential.getVersion().equalsIgnoreCase("v3")){
			mtDispatcher.addMessageProcessingModel(new MPv3());
			snmp = SNMPUtils.addUSMUser(snmpCredential, transport, mtDispatcher);   
		}else{
			Log.error("Not Valid SNMP Version.");
			return;
		}
		snmp.addCommandResponder(this);        
		snmp.listen();
		Log.info("Listening on " + address);
		try
		{
			this.wait();


		}
		catch (InterruptedException interruptedException)
		{
			Thread.currentThread().interrupt();
			Log.error(" error occour"+interruptedException);
		}
	}

	/**
	 * This method will be called whenever a pdu is received on the given port specified in the listen() method
	 */
	public synchronized void processPdu(CommandResponderEvent cmdRespEvent)
	{
		Log.info("Received PDU...");
		PDU pdu = cmdRespEvent.getPDU();
		String source = cmdRespEvent.getPeerAddress().toString().split("/")[0];
		Log.info("IPAddress "+cmdRespEvent.getPeerAddress());
		if (pdu != null)
		{
			Log.info("Trap Type = " + pdu.getType());
			String trapType = identifyTrapType(pdu);
			if(trapType != null){
				generateAlarm(trapType, pdu, source);
			}else{
				Log.info(Constants.TRAP_UNDEFINED + pdu);
			}
		}
	}

	public String identifyTrapType(PDU pdu){
		String trapType = null;
		for(VariableBinding vb: pdu.getVariableBindings()){
			if(vb.getOid().toString().equals(Constants.SNMP_TRAP_OID)){
				trapType = trapMap.get(vb.getVariable().toString().trim());
				break;
			}
		}
		return trapType;
	}

	public void generateAlarm(String trapType, PDU pdu, String source){
		CUCMAlarms cucmAlarm = null;
		UCCXAlarms uccxAlarm = null;
		UCCEAlarms ucceAlarm = null;
		if(trapType.equals(Constants.CCM_CALL_MANAGER_FAILED)){
			cucmAlarm = new CUCMAlarms();
			cucmAlarm.generateCallManagerFailedAlarm(pdu, source);
		}else if(trapType.equals(Constants.CCM_PHONE_FAILED)){
			cucmAlarm = new CUCMAlarms();
			cucmAlarm.generatePhoneFailedAlarm(pdu, source);
		}else if(trapType.equals(Constants.CCM_PHONE_STATUS_UPDATE)){
			cucmAlarm = new CUCMAlarms();
			cucmAlarm.generatePhoneStatusUpdateAlarm(pdu, source);
		}else if(trapType.equals(Constants.CCM_GATEWAY_FAILED)){
			cucmAlarm = new CUCMAlarms();
			cucmAlarm.generateGatewayFailedAlarm(pdu, source);
		}else if(trapType.equals(Constants.CCM_MEDIA_RESOURCE_LIST_EXHAUSTED)){
			cucmAlarm = new CUCMAlarms();
			cucmAlarm.generateMediaResourceListExhaustedAlarm(pdu,source);
		}else if(trapType.equals(Constants.CCM_ROUTE_LIST_EXHAUSTED)){
			cucmAlarm = new CUCMAlarms();
			cucmAlarm.generateRouteListExhaustedAlarm(pdu, source);
		}else if(trapType.equals(Constants.CCM_GATEWAY_LAYER_CHANGE)){
			cucmAlarm = new CUCMAlarms();
			cucmAlarm.generateGatewayLayerChangeAlarm(pdu, source);
		}else if(trapType.equals(Constants.CCM_MALICIOUS_CALL)){
			cucmAlarm = new CUCMAlarms();
			cucmAlarm.generateMaliciousCallAlarm(pdu, source);
		}else if(trapType.equals(Constants.CCM_QUALITY_REPORT)){
			cucmAlarm = new CUCMAlarms();
			cucmAlarm.generateQualityReportAlarm(pdu, source);
		}else if(trapType.equals(Constants.CCM_TLS_CONNECTION_FAILURE)){
			cucmAlarm = new CUCMAlarms();
			cucmAlarm.generateTLSConnectionFailureAlarm(pdu, source);
		}else if(trapType.equals(Constants.CCM_GATEWAY_FAILED_REASON)){
			cucmAlarm = new CUCMAlarms();
			cucmAlarm.generateGatewayFailedReasonAlarm(pdu, source);
		}else if(trapType.equals(Constants.CVA_MODULE_START)){
			uccxAlarm = new UCCXAlarms();
			uccxAlarm.generateModuleStartAlarm(pdu, source);
		}else if(trapType.equals(Constants.CVA_MODULE_STOP)){
			uccxAlarm = new UCCXAlarms();
			uccxAlarm.generateModuleStopAlarm(pdu, source);
		}else if(trapType.equals(Constants.CVA_MODULE_RUN_TIME_FAILURE)){
			uccxAlarm = new UCCXAlarms();
			uccxAlarm.generateModuleRunTimeFailureAlarm(pdu, source);
		}else if(trapType.equals(Constants.CVA_PROCESS_START)){
			uccxAlarm = new UCCXAlarms();
			uccxAlarm.generateProcessStartAlarm(pdu, source);
		}else if(trapType.equals(Constants.CCCA_ICM_EVENT)){
			ucceAlarm = new UCCEAlarms();
			ucceAlarm.generateUCCEAlarm(pdu, source);
		}
	}
}