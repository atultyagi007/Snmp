package com.hcl.snmp;

import org.snmp4j.PDU;
import org.snmp4j.smi.VariableBinding;

import com.hcl.probe.Constants;
import com.nimsoft.nimbus.NimAlarm;
import com.nimsoft.nimbus.NimException;
import com.nimsoft.pf.common.log.Log;

public class UCCXAlarms {

	public void generateModuleStartAlarm(PDU pdu, String source){
		int severity = 0;
		String message = Constants.CVA_MODULE_START_MESSAGE;
		for(VariableBinding vb: pdu.getVariableBindings()){
			if(vb.getOid().toString().equals(Constants.CVA_ALARM_SEVERITY_OID)){
				severity = setUCCXSeverity(vb.getVariable().toString());
			}else if(vb.getOid().toString().equals(Constants.CVA_MODULE_NAME_OID)){
				message = message.replace("%ModuleName", vb.getVariable().toString());
			}
		}
		try{
			NimAlarm alarm = null;
			alarm = new NimAlarm(severity, message, Constants.SUBSYSTEM_ID, "supressionId", source ,null, "metricId");
			alarm.send();
			alarm.close();
		}catch(NimException nimException){
			Log.error(nimException.getMessage());
		}
	}
	
	public void generateModuleStopAlarm(PDU pdu, String source){
		int severity = 0;
		String message = Constants.CVA_MODULE_STOP_MESSAGE;
		for(VariableBinding vb: pdu.getVariableBindings()){
			if(vb.getOid().toString().equals(Constants.CVA_ALARM_SEVERITY_OID)){
				severity = setUCCXSeverity(vb.getVariable().toString());
			}else if(vb.getOid().toString().equals(Constants.CVA_MODULE_NAME_OID)){
				message = message.replace("%ModuleName", vb.getVariable().toString());
			}else if(vb.getOid().toString().equals(Constants.CVA_MODULE_FAILURE_CAUSE_OID)){
				if(vb.getVariable().toString().equals("1")){
					message = message.replace("%FailureCause", "Other");
				}else if(vb.getVariable().toString().equals("2")){
					message = message.replace("%FailureCause", "Graceful Shut Down");
				}else if(vb.getVariable().toString().equals("3")){
					message = message.replace("%FailureCause", "Heartbeat Failure");
				}else if(vb.getVariable().toString().equals("4")){
					message = message.replace("%FailureCause", "Init Failure");
				}else if(vb.getVariable().toString().equals("5")){
					message = message.replace("%FailureCause", "Out of Resource");
				}else if(vb.getVariable().toString().equals("6")){
					message = message.replace("%FailureCause", "Partial Failure");
				}				
			}else if(vb.getOid().toString().equals(Constants.CVA_MODULE_FAILURE_NAME_OID)){
				message = message.replace("%FailureName", vb.getVariable().toString());
			}else if(vb.getOid().toString().equals(Constants.CVA_MODULE_FAILURE_MESSAGE_OID)){
				message = message.replace("%FailureMessage", vb.getVariable().toString());
			}
		}
		try{
			NimAlarm alarm = null;
			alarm = new NimAlarm(severity, message, Constants.SUBSYSTEM_ID, "supressionId", source ,null, "metricId");
			alarm.send();
			alarm.close();
		}catch(NimException nimException){
			Log.error(nimException.getMessage());
		}
	}
	
	public void generateModuleRunTimeFailureAlarm(PDU pdu, String source){
		int severity = 0;
		String message = Constants.CVA_MODULE_RUN_TIME_FAILURE_MESSAGE;
		for(VariableBinding vb: pdu.getVariableBindings()){
			if(vb.getOid().toString().equals(Constants.CVA_ALARM_SEVERITY_OID)){
				severity = setUCCXSeverity(vb.getVariable().toString());
			}else if(vb.getOid().toString().equals(Constants.CVA_MODULE_NAME_OID)){
				message = message.replace("%ModuleName", vb.getVariable().toString());
			}else if(vb.getOid().toString().equals(Constants.CVA_MODULE_RUN_TIME_FAILURE_CAUSE_OID)){
				if(vb.getVariable().toString().equals("1")){
					message = message.replace("%RunTimeFailureCause", "Other");
				}else if(vb.getVariable().toString().equals("2")){
					message = message.replace("%RunTimeFailureCause", "Read Access Failure");
				}else if(vb.getVariable().toString().equals("3")){
					message = message.replace("%RunTimeFailureCause", "Write Access Failure");
				}else if(vb.getVariable().toString().equals("4")){
					message = message.replace("%RunTimeFailureCause", "Create Failure");
				}else if(vb.getVariable().toString().equals("5")){
					message = message.replace("%RunTimeFailureCause", "Delete Failure");
				}else if(vb.getVariable().toString().equals("6")){
					message = message.replace("%RunTimeFailureCause", "Update Failure");
				}else if(vb.getVariable().toString().equals("7")){
					message = message.replace("%RunTimeFailureCause", "Init Failure");
				}else if(vb.getVariable().toString().equals("8")){
					message = message.replace("%RunTimeFailureCause", "Load Failure");
				}else if(vb.getVariable().toString().equals("9")){
					message = message.replace("%RunTimeFailureCause", "Out of Resource");
				}else if(vb.getVariable().toString().equals("10")){
					message = message.replace("%RunTimeFailureCause", "Call Process Failure");
				}else if(vb.getVariable().toString().equals("11")){
					message = message.replace("%RunTimeFailureCause", "Registration Failure");
				}else if(vb.getVariable().toString().equals("12")){
					message = message.replace("%RunTimeFailureCause", "DeRegistration Failure");
				}else if(vb.getVariable().toString().equals("13")){
					message = message.replace("%RunTimeFailureCause", "Connection Failure");
				}else if(vb.getVariable().toString().equals("14")){
					message = message.replace("%RunTimeFailureCause", "Disconnection Failure");
				}else if(vb.getVariable().toString().equals("15")){
					message = message.replace("%RunTimeFailureCause", "Unknown Target");
				}else if(vb.getVariable().toString().equals("16")){
					message = message.replace("%RunTimeFailureCause", "UnReachable Target");
				}			
			}else if(vb.getOid().toString().equals(Constants.CVA_MODULE_FAILURE_NAME_OID)){
				message = message.replace("%FailureName", vb.getVariable().toString());
			}else if(vb.getOid().toString().equals(Constants.CVA_MODULE_FAILURE_MESSAGE_OID)){
				message = message.replace("%FailureMessage", vb.getVariable().toString());
			}
		}
		try{
			NimAlarm alarm = null;
			alarm = new NimAlarm(severity, message, Constants.SUBSYSTEM_ID, "supressionId", source ,null, "metricId");
			alarm.send();
			alarm.close();
		}catch(NimException nimException){
			Log.error(nimException.getMessage());
		}
	}
	
	public void generateProcessStartAlarm(PDU pdu, String source){
		int severity = 0;
		String message = Constants.CVA_PROCESS_START_MESSAGE;
		for(VariableBinding vb: pdu.getVariableBindings()){
			if(vb.getOid().toString().equals(Constants.CVA_ALARM_SEVERITY_OID)){
				severity = setUCCXSeverity(vb.getVariable().toString());
			}else if(vb.getOid().toString().equals(Constants.CVA_MODULE_NAME_OID)){
				message = message.replace("%ModuleName", vb.getVariable().toString());
			}else if(vb.getOid().toString().equals(Constants.CVA_PROCESS_ID_OID)){
				message = message.replace("%ProcessId", vb.getVariable().toString());
			}
		}
		try{
			NimAlarm alarm = null;
			alarm = new NimAlarm(severity, message, Constants.SUBSYSTEM_ID, "supressionId", source ,null, "metricId");
			alarm.send();
			alarm.close();
		}catch(NimException nimException){
			Log.error(nimException.getMessage());
		}
	}
	
	public void generateProcessStopAlarm(PDU pdu, String source){
		int severity = 0;
		String message = Constants.CVA_PROCESS_STOP_MESSAGE;
		for(VariableBinding vb: pdu.getVariableBindings()){
			if(vb.getOid().toString().equals(Constants.CVA_ALARM_SEVERITY_OID)){
				severity = setUCCXSeverity(vb.getVariable().toString());
			}else if(vb.getOid().toString().equals(Constants.CVA_MODULE_NAME_OID)){
				message = message.replace("%ModuleName", vb.getVariable().toString());
			}else if(vb.getOid().toString().equals(Constants.CVA_PROCESS_ID_OID)){
				message = message.replace("%ProcessId", vb.getVariable().toString());
			}
		}
		try{
			NimAlarm alarm = null;
			alarm = new NimAlarm(severity, message, Constants.SUBSYSTEM_ID, "supressionId", source ,null, "metricId");
			alarm.send();
			alarm.close();
		}catch(NimException nimException){
			Log.error(nimException.getMessage());
		}
	}
	
	public int setUCCXSeverity(String variable){
		int sev=0;
		if(variable.equals("1") || variable.equals("2") || variable.equals("3")){
			sev =5;
		}else if(variable.equals("4")){
			sev =4;
		}else if(variable.equals("5")){
			sev =2;
		}else if(variable.equals("6") || variable.equals("7")){
			sev =1;
		}
		return sev;
	}
}
