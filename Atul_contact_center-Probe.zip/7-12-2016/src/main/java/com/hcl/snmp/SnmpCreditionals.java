package com.hcl.snmp;
public class SnmpCreditionals {
	private String ipAddress;
	private String community;
	private String version;
	private String port;
	private String userName;
	private String password;	
	private String auth_password;
	private String privatePassWord;
	private String context_path;
	private String securityLevel;
	private String authentication;
	private String encryption;
	private String requestType;
	private int retry=1;
	private long timeout=5000;
	private String type;
	
	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}
	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}
	public String getRequestType() {
		return requestType;
	}
	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}
	public int getRetry() {
		return retry;
	}
	public void setRetry(int retry) {
		this.retry = retry;
	}
	public long getTimeout() {
		return timeout;
	}
	public void setTimeout(long timeout) {
		this.timeout = timeout;
	}
	public String getAuthentication() {
		return authentication;
	}
	public void setAuthentication(String authentication) {
		this.authentication = authentication;
	}
	public String getEncryption() {
		return encryption;
	}
	public void setEncryption(String encryption) {
		this.encryption = encryption;
	}
	public String getSecurityLevel() {
		return securityLevel;
	}
	public void setSecurityLevel(String securityLevel) {
		this.securityLevel = securityLevel;
	}
	public String getAuth_password() {
		return auth_password;
	}
	public void setAuth_password(String auth_password) {
		this.auth_password = auth_password;
	}
	public String getPrivatePassWord() {
		return privatePassWord;
	}
	public void setPrivatePassWord(String privatePassWord) {
		this.privatePassWord = privatePassWord;
	}
	public String getContext_path() {
		return context_path;
	}
	public void setContext_path(String context_path) {
		this.context_path = context_path;
	}
	public String getIpAddress() {
		return ipAddress;
	}
	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}
	public String getCommunity() {
		return community;
	}
	public void setCommunity(String community) {
		this.community = community;
	}
	public String getVersion() {
		return version;
	}
	public void setVersion(String version) {
		this.version = version;
	}
	public String getPort() {
		return port;
	}
	public void setPort(String port) {
		this.port = port;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
}
