package com.hcl.snmp;


public class ListenerThread extends Thread{

	@Override
	public void run() {
		TrapReceiver snmp4jTrapReceiver = new TrapReceiver();
		snmp4jTrapReceiver.startTrapReceiver();
	}
}
