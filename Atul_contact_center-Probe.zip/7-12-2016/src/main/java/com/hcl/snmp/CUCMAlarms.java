package com.hcl.snmp;

import org.snmp4j.PDU;
import org.snmp4j.smi.VariableBinding;

import com.hcl.probe.Constants;
import com.nimsoft.nimbus.NimAlarm;
import com.nimsoft.nimbus.NimException;
import com.nimsoft.pf.common.log.Log;

public class CUCMAlarms {
	public void generateCallManagerFailedAlarm(PDU pdu, String source){		
		int severity = 0;
		String message = "";
		for(VariableBinding vb: pdu.getVariableBindings()){
			if(vb.getOid().toString().equals(Constants.CCM_ALARM_SEVERITY)){
				severity = setCUCMSeverity(vb.getVariable().toString());
			}else if(vb.getOid().toString().equals(Constants.CCM_FAIL_CAUSE_CODE_MESSAGE_)){
				if(vb.getVariable().toString().equals("1")){
					message = Constants.CCM_FAIL_CAUSE_CODE_MESSAGE_1;
				}else if(vb.getVariable().toString().equals("2")){
					message = Constants.CCM_FAIL_CAUSE_CODE_MESSAGE_2;
				}else if(vb.getVariable().toString().equals("3")){
					message = Constants.CCM_FAIL_CAUSE_CODE_MESSAGE_3;
				}else if(vb.getVariable().toString().equals("4")){
					message = Constants.CCM_FAIL_CAUSE_CODE_MESSAGE_4;
				}else if(vb.getVariable().toString().equals("5")){
					message = Constants.CCM_FAIL_CAUSE_CODE_MESSAGE_5;
				}else if(vb.getVariable().toString().equals("6")){
					message = Constants.CCM_FAIL_CAUSE_CODE_MESSAGE_6;
				}else if(vb.getVariable().toString().equals("7")){
					message = Constants.CCM_FAIL_CAUSE_CODE_MESSAGE_7;
				}else if(vb.getVariable().toString().equals("8")){
					message = Constants.CCM_FAIL_CAUSE_CODE_MESSAGE_8;
				}else if(vb.getVariable().toString().equals("9")){
					message = Constants.CCM_FAIL_CAUSE_CODE_MESSAGE_9;
				}else if(vb.getVariable().toString().equals("10")){
					message = Constants.CCM_FAIL_CAUSE_CODE_MESSAGE_10;
				}else if(vb.getVariable().toString().equals("11")){
					message = Constants.CCM_FAIL_CAUSE_CODE_MESSAGE_11;
				}else if(vb.getVariable().toString().equals("12")){
					message = Constants.CCM_FAIL_CAUSE_CODE_MESSAGE_12;
				}
			}
		}
		try{
			NimAlarm alarm = null;
			alarm = new NimAlarm(severity, message, Constants.SUBSYSTEM_ID, "supressionId", source ,null, "metricId");
			alarm.send();
			alarm.close();
		}catch(NimException nimException){
			Log.error(nimException.getMessage());
		}		
	}

	public void generatePhoneFailedAlarm(PDU pdu, String source){
		int severity = 0;
		String message = "";
		for(VariableBinding vb: pdu.getVariableBindings()){
			if(vb.getOid().toString().equals(Constants.CCM_ALARM_SEVERITY)){
				severity = setCUCMSeverity(vb.getVariable().toString());
			}else if(vb.getOid().toString().equals(Constants.CCM_PHONE_FAILURES)){
				message = Constants.CCM_PHONE_FAILURES_MESSAGE + vb.getVariable();
			}
		}
		try{
			NimAlarm alarm = null;
			alarm = new NimAlarm(severity, message, Constants.SUBSYSTEM_ID, "supressionId", source ,null, "metricId");
			alarm.send();
			alarm.close();
		}catch(NimException nimException){
			Log.error(nimException.getMessage());
		}
	}

	public void generatePhoneStatusUpdateAlarm(PDU pdu, String source){
		int severity = 0;
		String message = "";
		for(VariableBinding vb: pdu.getVariableBindings()){
			if(vb.getOid().toString().equals(Constants.CCM_ALARM_SEVERITY)){
				severity = setCUCMSeverity(vb.getVariable().toString());
			}else if(vb.getOid().toString().equals(Constants.CCM_PHONE_UPDATES)){
				message = Constants.CCM_PHONE_UPDATE_MESSAGE + vb.getVariable();
			}
		}
		try{
			NimAlarm alarm = null;
			alarm = new NimAlarm(severity, message, Constants.SUBSYSTEM_ID, "supressionId", source ,null, "metricId");
			alarm.send();
			alarm.close();
		}catch(NimException nimException){
			Log.error(nimException.getMessage());
		}
	}

	public void generateGatewayFailedAlarm(PDU pdu, String source){
		int severity = 0;		
		String message = Constants.CCM_GATEWAY_FAILED_MESSAGE;
		for(VariableBinding vb: pdu.getVariableBindings()){
			if(vb.getOid().toString().equals(Constants.CCM_ALARM_SEVERITY)){
				severity = setCUCMSeverity(vb.getVariable().toString());
			}else if(vb.getOid().toString().equals(Constants.CCM_GATEWAY_NAME_OID)){
				message = message.replace("%GatewayName", vb.getVariable().toString());
			}else if(vb.getOid().toString().equals(Constants.CCM_GATEWAY_INET_ADDRESS_OID)){
				message = message.replace("%IpAddress", vb.getVariable().toString());
			}else if(vb.getOid().toString().equals(Constants.CCM_GATEWAY_INET_ADDRESS_TYPE_OID)){
				message = message.replace("%IpAddressType", getInetAddressType(vb.getVariable().toString()));
			}else if(vb.getOid().toString().equals(Constants.CCM_GATEWAY_FAIL_CAUSE_CODE)){
				if(vb.getVariable().toString().equals("0")){
					message = message.replace("%FailedCode", Constants.CCM_GATEWAY_FAILED_MESSAGE_0);
				}else if(vb.getVariable().toString().equals("1")){
					message = message.replace("%FailedCode", Constants.CCM_GATEWAY_FAILED_MESSAGE_1);
				}else if(vb.getVariable().toString().equals("2")){
					message = message.replace("%FailedCode", Constants.CCM_GATEWAY_FAILED_MESSAGE_2);
				}else if(vb.getVariable().toString().equals("3")){
					message = message.replace("%FailedCode", Constants.CCM_GATEWAY_FAILED_MESSAGE_3);
				}else if(vb.getVariable().toString().equals("4")){
					message = message.replace("%FailedCode", Constants.CCM_GATEWAY_FAILED_MESSAGE_4);
				}else if(vb.getVariable().toString().equals("5")){
					message = message.replace("%FailedCode", Constants.CCM_GATEWAY_FAILED_MESSAGE_5);
				}else if(vb.getVariable().toString().equals("6")){
					message = message.replace("%FailedCode", Constants.CCM_GATEWAY_FAILED_MESSAGE_6);
				}else if(vb.getVariable().toString().equals("7")){
					message = message.replace("%FailedCode", Constants.CCM_GATEWAY_FAILED_MESSAGE_7);
				}else if(vb.getVariable().toString().equals("8")){
					message = message.replace("%FailedCode", Constants.CCM_GATEWAY_FAILED_MESSAGE_8);
				}else if(vb.getVariable().toString().equals("9")){
					message = message.replace("%FailedCode", Constants.CCM_GATEWAY_FAILED_MESSAGE_9);
				}else if(vb.getVariable().toString().equals("10")){
					message = message.replace("%FailedCode", Constants.CCM_GATEWAY_FAILED_MESSAGE_10);
				}else if(vb.getVariable().toString().equals("11")){
					message = message.replace("%FailedCode", Constants.CCM_GATEWAY_FAILED_MESSAGE_11);
				}else if(vb.getVariable().toString().equals("12")){
					message = message.replace("%FailedCode", Constants.CCM_GATEWAY_FAILED_MESSAGE_12);
				}else if(vb.getVariable().toString().equals("13")){
					message = message.replace("%FailedCode", Constants.CCM_GATEWAY_FAILED_MESSAGE_13);
				}else if(vb.getVariable().toString().equals("14")){
					message = message.replace("%FailedCode", Constants.CCM_GATEWAY_FAILED_MESSAGE_14);
				}				
			}
		}
		try{
			NimAlarm alarm = null;
			alarm = new NimAlarm(severity, message, Constants.SUBSYSTEM_ID, "supressionId", source ,null, "metricId");
			alarm.send();
			alarm.close();
		}catch(NimException nimException){
			Log.error(nimException.getMessage());
		}
	}

	public void generateMediaResourceListExhaustedAlarm(PDU pdu, String source){
		int severity = 0;
		String message = Constants.CCM_MEDIA_LIST_EXHAUSTED_MESSAGE;
		for(VariableBinding vb: pdu.getVariableBindings()){
			if(vb.getOid().toString().equals(Constants.CCM_ALARM_SEVERITY)){
				severity = setCUCMSeverity(vb.getVariable().toString());
			}else if(vb.getOid().toString().equals(Constants.CCM_MEDIA_RESOURCE_TYPE)){
				message = message.replace("%MediaListType", vb.getVariable().toString());
			}else if(vb.getOid().toString().equals(Constants.CCM_MEDIA_RESOURCE_LIST_NAME)){
				message = message.replace("%MediaListName", vb.getVariable().toString());
			}
		}
		try{
			NimAlarm alarm = null;
			alarm = new NimAlarm(severity, message, Constants.SUBSYSTEM_ID, "supressionId", source ,null, "metricId");
			alarm.send();
			alarm.close();
		}catch(NimException nimException){
			Log.error(nimException.getMessage());
		}
	}

	public void generateRouteListExhaustedAlarm(PDU pdu, String source){
		int severity = 0;
		String message = Constants.CCM_ROUTE_LIST_EXHAUSTED_MESSAGE;
		for(VariableBinding vb: pdu.getVariableBindings()){
			if(vb.getOid().toString().equals(Constants.CCM_ALARM_SEVERITY)){
				severity = setCUCMSeverity(vb.getVariable().toString());
			}else if(vb.getOid().toString().equals(Constants.CCM_ROUTE_LIST_NAME)){
				message = message.replace("%RouteListName", vb.getVariable().toString());
			}
		}
		try{
			NimAlarm alarm = null;
			alarm = new NimAlarm(severity, message, Constants.SUBSYSTEM_ID, "supressionId", source ,null, "metricId");
			alarm.send();
			alarm.close();
		}catch(NimException nimException){
			Log.error(nimException.getMessage());
		}
	}

	public void generateGatewayLayerChangeAlarm(PDU pdu, String source){
		int severity = 0;
		String message = Constants.CCM_GATEWAY_LAYER2_CHANGE_MESSAGE;
		for(VariableBinding vb: pdu.getVariableBindings()){
			if(vb.getOid().toString().equals(Constants.CCM_ALARM_SEVERITY)){
				severity = setCUCMSeverity(vb.getVariable().toString());
			}else if(vb.getOid().toString().equals(Constants.CCM_GATEWAY_NAME_OID)){
				message = message.replace("%GatewayName", vb.getVariable().toString());
			}else if(vb.getOid().toString().equals(Constants.CCM_GATEWAY_INET_ADDRESS_OID)){
				message = message.replace("%GatewayInetAddress", vb.getVariable().toString());
			}else if(vb.getOid().toString().equals(Constants.CCM_GATEWAY_PHYS_IF_INDEX)){
				message = message.replace("%InterfaceName", vb.getVariable().toString());
			}else if(vb.getOid().toString().equals(Constants.CCM_GATEWAY_PHYS_IF_L2_STATUS)){
				if(vb.getVariable().toString().equals("0")){
					message = message.replace("%GatewayInterfaceStatus", Constants.CCM_GATEWAY_FAILED_MESSAGE_1);
				}else if(vb.getVariable().toString().equals("1")){
					message = message.replace("%GatewayInterfaceStatus", Constants.CCM_GATEWAY_LAYER2_CHANGE_MESSAGE_1);
				}else if(vb.getVariable().toString().equals("2")){
					message = message.replace("%GatewayInterfaceStatus", Constants.CCM_GATEWAY_LAYER2_CHANGE_MESSAGE_2);
				}				
			}
		}
		try{
			NimAlarm alarm = null;
			alarm = new NimAlarm(severity, message, Constants.SUBSYSTEM_ID, "supressionId", source ,null, "metricId");
			alarm.send();
			alarm.close();
		}catch(NimException nimException){
			Log.error(nimException.getMessage());
		}
	}

	public void generateMaliciousCallAlarm(PDU pdu, String source){
		int severity = 0;
		String message = Constants.CCM_MALICIOUS_CALL_MESSAGE;
		for(VariableBinding vb: pdu.getVariableBindings()){
			if(vb.getOid().toString().equals(Constants.CCM_ALARM_SEVERITY)){
				severity = setCUCMSeverity(vb.getVariable().toString());
			}else if(vb.getOid().toString().equals(Constants.CCM_MALI_CALL_CALLED_PARTY_NAME)){
				message = message.replace("%CcmMaliCallCalledPartyName", vb.getVariable().toString());
			}else if(vb.getOid().toString().equals(Constants.CCM_MALI_CALL_CALLED_PARTY_NUMBER)){
				message = message.replace("%CcmMaliCallCalledPartyNumber", vb.getVariable().toString());
			}else if(vb.getOid().toString().equals(Constants.CCM_MALI_CALL_CALLED_DEVICE_NAME)){
				message = message.replace("%CcmMaliCallCalledDeviceName", vb.getVariable().toString());
			}else if(vb.getOid().toString().equals(Constants.CCM_MALI_CALL_CALLING_PARTY_NAME)){
				message = message.replace("%CcmMaliCallCallingPartyName", vb.getVariable().toString());
			}else if(vb.getOid().toString().equals(Constants.CCM_MALI_CALL_CALLING_PARTY_NUMBER)){
				message = message.replace("%CcmMaliCallCallingPartyNumber", vb.getVariable().toString());
			}else if(vb.getOid().toString().equals(Constants.CCM_MALI_CALL_CALLING_DEVICE_NAME)){
				message = message.replace("%CcmMaliCallCallingDeviceName", vb.getVariable().toString());
			}else if(vb.getOid().toString().equals(Constants.CCM_MALI_CALL_TIME)){
				message = message.replace("%CcmMaliCallTime", vb.getVariable().toString());
			}
		}
		try{
			NimAlarm alarm = null;
			alarm = new NimAlarm(severity, message, Constants.SUBSYSTEM_ID, "supressionId", source ,null, "metricId");
			alarm.send();
			alarm.close();
		}catch(NimException nimException){
			Log.error(nimException.getMessage());
		}
	}

	public void generateQualityReportAlarm(PDU pdu, String source){
		int severity = 0;
		String message = Constants.CCM_QUALITY_REPORT_MESSAGE;
		for(VariableBinding vb: pdu.getVariableBindings()){
			if(vb.getOid().toString().equals(Constants.CCM_ALARM_SEVERITY)){
				severity = setCUCMSeverity(vb.getVariable().toString());
			}else if(vb.getOid().toString().equals(Constants.CCM_QUALITY_REPORT_SOURCE_DEV_NAME)){
				message = message.replace("%CcmQualityRprtSourceDevName", vb.getVariable().toString());
			}else if(vb.getOid().toString().equals(Constants.CCM_QUALITY_REPORT_CLUSTER_ID)){
				message = message.replace("%CcmQualityRprtClusterId", vb.getVariable().toString());
			}else if(vb.getOid().toString().equals(Constants.CCM_QUALITY_REPORT_CATEGORY)){
				message = message.replace("%CcmQualityRprtCategory", vb.getVariable().toString());
			}else if(vb.getOid().toString().equals(Constants.CCM_QUALITY_REPORT_REASON_CODE)){
				message = message.replace("%ccmQualityRprtReasonCode", vb.getVariable().toString());
			}else if(vb.getOid().toString().equals(Constants.CCM_QUALITY_REPORT_TIME)){
				message = message.replace("%CcmQualityRprtTime", vb.getVariable().toString());
			}
		}
		try{
			NimAlarm alarm = null;
			alarm = new NimAlarm(severity, message, Constants.SUBSYSTEM_ID, "supressionId", source ,null, "metricId");
			alarm.send();
			alarm.close();
		}catch(NimException nimException){
			Log.error(nimException.getMessage());
		}
	}

	public void generateTLSConnectionFailureAlarm(PDU pdu, String source){
		int severity = 0;
		String message = Constants.CCM_TLS_CONNECTION_FAILURE_MESSAGE;
		for(VariableBinding vb: pdu.getVariableBindings()){
			if(vb.getOid().toString().equals(Constants.CCM_ALARM_SEVERITY)){
				severity = setCUCMSeverity(vb.getVariable().toString());
			}else if(vb.getOid().toString().equals(Constants.CCM_TLS_DEV_NAME)){
				message = message.replace("%CcmTLSDevName", vb.getVariable().toString());
			}else if(vb.getOid().toString().equals(Constants.CCM_TLS_DEV_INET_ADDRESS)){
				message = message.replace("%CcmTLSDevInetAddress", vb.getVariable().toString());
			}else if(vb.getOid().toString().equals(Constants.CCM_TLS_CONN_FAIL_REASON_CODE)){
				if(vb.getVariable().toString().equals("1")){
					message = message.replace("%CcmTLSConnectionFailReasonCode", Constants.CCM_GATEWAY_FAILED_MESSAGE_1);
				}else if(vb.getVariable().toString().equals("2")){
					message = message.replace("%CcmTLSConnectionFailReasonCode", Constants.CCM_TLS_CONNECTION_FAILURE_MESSAGE_2);
				}else if(vb.getVariable().toString().equals("3")){
					message = message.replace("%CcmTLSConnectionFailReasonCode", Constants.CCM_TLS_CONNECTION_FAILURE_MESSAGE_3);
				}else if(vb.getVariable().toString().equals("4")){
					message = message.replace("%CcmTLSConnectionFailReasonCode", Constants.CCM_TLS_CONNECTION_FAILURE_MESSAGE_4);
				}				
			}else if(vb.getOid().toString().equals(Constants.CCM_TLS_CONN_FAIL_TIME)){
				message = message.replace("%CcmTLSConnFailTime", vb.getVariable().toString());
			}
		}
		try{
			NimAlarm alarm = null;
			alarm = new NimAlarm(severity, message, Constants.SUBSYSTEM_ID, "supressionId", source ,null, "metricId");
			alarm.send();
			alarm.close();
		}catch(NimException nimException){
			Log.error(nimException.getMessage());
		}
	}

	public void generateGatewayFailedReasonAlarm(PDU pdu, String source){
		int severity = 0;
		String message = Constants.CCM_GATEWAY_FAILED_REASON_MESSAGE;
		for(VariableBinding vb: pdu.getVariableBindings()){
			if(vb.getOid().toString().equals(Constants.CCM_ALARM_SEVERITY)){
				severity = setCUCMSeverity(vb.getVariable().toString());
			}else if(vb.getOid().toString().equals(Constants.CCM_GATEWAY_NAME_OID)){
				message = message.replace("%CcmGatewayName", vb.getVariable().toString());
			}else if(vb.getOid().toString().equals(Constants.CCM_GATEWAY_INET_ADDRESS_OID)){
				message = message.replace("%CcmGatewayInetAddress", vb.getVariable().toString());
			}else if(vb.getOid().toString().equals(Constants.CCM_GATEWAY_REG_FAIL_CAUSE_CODE)){
				if(vb.getVariable().toString().equals("0")){
					message = message.replace("%CcmGatewayRegFailCauseCode", Constants.CCM_GATEWAY_FAILED_REASON_MESSAGE_0);
				}else if(vb.getVariable().toString().equals("1")){
					message = message.replace("%CcmGatewayRegFailCauseCode", Constants.CCM_GATEWAY_FAILED_REASON_MESSAGE_1);
				}else if(vb.getVariable().toString().equals("2")){
					message = message.replace("%CcmGatewayRegFailCauseCode", Constants.CCM_GATEWAY_FAILED_REASON_MESSAGE_2);
				}else if(vb.getVariable().toString().equals("3")){
					message = message.replace("%CcmGatewayRegFailCauseCode", Constants.CCM_GATEWAY_FAILED_REASON_MESSAGE_3);
				}else if(vb.getVariable().toString().equals("4")){
					message = message.replace("%CcmGatewayRegFailCauseCode", Constants.CCM_GATEWAY_FAILED_REASON_MESSAGE_4);
				}else if(vb.getVariable().toString().equals("5")){
					message = message.replace("%CcmGatewayRegFailCauseCode", Constants.CCM_GATEWAY_FAILED_REASON_MESSAGE_5);
				}else if(vb.getVariable().toString().equals("6")){
					message = message.replace("%CcmGatewayRegFailCauseCode", Constants.CCM_GATEWAY_FAILED_REASON_MESSAGE_6);
				}else if(vb.getVariable().toString().equals("7")){
					message = message.replace("%CcmGatewayRegFailCauseCode", Constants.CCM_GATEWAY_FAILED_REASON_MESSAGE_7);
				}else if(vb.getVariable().toString().equals("8")){
					message = message.replace("%CcmGatewayRegFailCauseCode", Constants.CCM_GATEWAY_FAILED_REASON_MESSAGE_8);
				}else if(vb.getVariable().toString().equals("9")){
					message = message.replace("%CcmGatewayRegFailCauseCode", Constants.CCM_GATEWAY_FAILED_REASON_MESSAGE_9);
				}else if(vb.getVariable().toString().equals("10")){
					message = message.replace("%CcmGatewayRegFailCauseCode", Constants.CCM_GATEWAY_FAILED_REASON_MESSAGE_10);
				}else if(vb.getVariable().toString().equals("11")){
					message = message.replace("%CcmGatewayRegFailCauseCode", Constants.CCM_GATEWAY_FAILED_REASON_MESSAGE_11);
				}else if(vb.getVariable().toString().equals("12")){
					message = message.replace("%CcmGatewayRegFailCauseCode", Constants.CCM_GATEWAY_FAILED_REASON_MESSAGE_12);
				}else if(vb.getVariable().toString().equals("13")){
					message = message.replace("%CcmGatewayRegFailCauseCode", Constants.CCM_GATEWAY_FAILED_REASON_MESSAGE_13);
				}else if(vb.getVariable().toString().equals("14")){
					message = message.replace("%CcmGatewayRegFailCauseCode", Constants.CCM_GATEWAY_FAILED_REASON_MESSAGE_14);
				}else if(vb.getVariable().toString().equals("15")){
					message = message.replace("%CcmGatewayRegFailCauseCode", Constants.CCM_GATEWAY_FAILED_REASON_MESSAGE_15);
				}else if(vb.getVariable().toString().equals("16")){
					message = message.replace("%CcmGatewayRegFailCauseCode", Constants.CCM_GATEWAY_FAILED_REASON_MESSAGE_16);
				}else if(vb.getVariable().toString().equals("17")){
					message = message.replace("%CcmGatewayRegFailCauseCode", Constants.CCM_GATEWAY_FAILED_REASON_MESSAGE_17);
				}else if(vb.getVariable().toString().equals("18")){
					message = message.replace("%CcmGatewayRegFailCauseCode", Constants.CCM_GATEWAY_FAILED_REASON_MESSAGE_18);
				}else if(vb.getVariable().toString().equals("23")){
					message = message.replace("%CcmGatewayRegFailCauseCode", Constants.CCM_GATEWAY_FAILED_REASON_MESSAGE_23);
				}else if(vb.getVariable().toString().equals("25")){
					message = message.replace("%CcmGatewayRegFailCauseCode", Constants.CCM_GATEWAY_FAILED_REASON_MESSAGE_25);
				}else if(vb.getVariable().toString().equals("26")){
					message = message.replace("%CcmGatewayRegFailCauseCode", Constants.CCM_GATEWAY_FAILED_REASON_MESSAGE_26);
				}else if(vb.getVariable().toString().equals("27")){
					message = message.replace("%CcmGatewayRegFailCauseCode", Constants.CCM_GATEWAY_FAILED_REASON_MESSAGE_27);
				}else if(vb.getVariable().toString().equals("28")){
					message = message.replace("%CcmGatewayRegFailCauseCode", Constants.CCM_GATEWAY_FAILED_REASON_MESSAGE_28);
				}else if(vb.getVariable().toString().equals("29")){
					message = message.replace("%CcmGatewayRegFailCauseCode", Constants.CCM_GATEWAY_FAILED_REASON_MESSAGE_29);
				}else if(vb.getVariable().toString().equals("30")){
					message = message.replace("%CcmGatewayRegFailCauseCode", Constants.CCM_GATEWAY_FAILED_REASON_MESSAGE_30);
				}else if(vb.getVariable().toString().equals("31")){
					message = message.replace("%CcmGatewayRegFailCauseCode", Constants.CCM_GATEWAY_FAILED_REASON_MESSAGE_31);
				}else if(vb.getVariable().toString().equals("32")){
					message = message.replace("%CcmGatewayRegFailCauseCode", Constants.CCM_GATEWAY_FAILED_REASON_MESSAGE_32);
				}else if(vb.getVariable().toString().equals("33")){
					message = message.replace("%CcmGatewayRegFailCauseCode", Constants.CCM_GATEWAY_FAILED_REASON_MESSAGE_33);
				}				
			}else if(vb.getOid().toString().equals(Constants.CCM_TLS_CONN_FAIL_TIME)){
				message = message.replace("%CcmTLSConnFailTime", vb.getVariable().toString());
			}
		}
		try{
			NimAlarm alarm = null;
			alarm = new NimAlarm(severity, message, Constants.SUBSYSTEM_ID, "supressionId", source ,null, "metricId");
			alarm.send();
			alarm.close();
		}catch(NimException nimException){
			Log.error(nimException.getMessage());
		}
	}

	public String getInetAddressType(String typeCode){
		String inetAddressType = "";
		if(typeCode.equals("0")){
			inetAddressType = Constants.UNKNOWN;
		}else if(typeCode.equals("1")){
			inetAddressType = Constants.IPV4;
		}else if(typeCode.equals("2")){
			inetAddressType = Constants.IPV6;
		}else if(typeCode.equals("3")){
			inetAddressType = Constants.IPV4Z;
		}else if(typeCode.equals("4")){
			inetAddressType = Constants.IPV6Z;
		}else if(typeCode.equals("16")){
			inetAddressType = Constants.DNS;
		}
		return inetAddressType;
	}

	public int setCUCMSeverity(String variable){
		int sev=0;
		if(variable.equals("1") || variable.equals("2") || variable.equals("3")){
			sev =5;
		}else if(variable.equals("4")){
			sev =4;
		}else if(variable.equals("5")){
			sev =2;
		}else if(variable.equals("6") || variable.equals("7")){
			sev =1;
		}
		return sev;
	}
}
