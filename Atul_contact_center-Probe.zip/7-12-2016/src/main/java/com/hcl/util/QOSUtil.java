package com.hcl.util;

import java.lang.reflect.Field;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Vector;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.FutureTask;

import org.snmp4j.smi.VariableBinding;

import com.hcl.axl.QOS;
import com.hcl.folder.CCCAComponentTableChild;
import com.hcl.folder.CCCALoggerTableChild;
import com.hcl.folder.CCCARouterTableChild;
import com.hcl.folder.CcmGlobalInfoChild;
import com.hcl.folder.CcmPhoneInfoChild;
import com.hcl.folder.CucmGroupTableChild;
import com.hcl.folder.CucmTableChild;
import com.hcl.folder.GateWayInfoChild;
import com.hcl.folder.GateWayTrunkChild;
import com.hcl.probe.Constants;
import com.hcl.probe.IndexElement;
import com.hcl.probe.OidForm;
import com.hcl.probe.ProbeMain;
import com.hcl.probe.QosForm;
import com.hcl.snmp.SNMPUtils;
import com.hcl.snmp.SnmpCreditionals;
import com.nimsoft.nimbus.NimException;
import com.nimsoft.pf.common.graph.GraphHelper;
import com.nimsoft.pf.common.log.Log;
import com.nimsoft.probe.framework.devkit.InventoryDataset;
import com.nimsoft.probe.framework.devkit.inventory.Folder;
import com.nimsoft.probe.framework.devkit.inventory.typedefs.EntityId;
import com.nimsoft.probe.framework.devkit.inventory.typedefs.MetricDef;
import com.nimsoft.types.CCCAComponentTable;
import com.nimsoft.types.CCCARouterTable;
import com.nimsoft.types.CiscoCallManager;
import com.nimsoft.types.CiscoTomcatJVM;
import com.nimsoft.types.CiscoTomcatWebApplication;
import com.nimsoft.types.DBLocal_DSN;
import com.nimsoft.types.EnterpriseReplicationDBSpaceMonitors;
import com.nimsoft.types.Interface;
import com.nimsoft.types.Memory;
import com.nimsoft.types.MemoryAXL;
import com.nimsoft.types.Partition;
import com.nimsoft.types.Processor;
import com.nimsoft.types.Software;
import com.nimsoft.types.SystemAXL;
import com.nimsoft.types.TCP;
import com.nimsoft.types.UCCEInterface;
import com.nimsoft.types.UCCEMemory;
import com.nimsoft.types.UCCEProcessor;
import com.nimsoft.types.UCCESoftware;
import com.nimsoft.types.UCCXInterface;
import com.nimsoft.types.UCCXMemory;
import com.nimsoft.types.UCCXProcessor;
import com.nimsoft.types.UCCXSoftware;

public class QOSUtil {
	//final static ExecutorService executor = Executors.newFixedThreadPool(10);
	 final NumberFormat formatter = new DecimalFormat(Constants.DECIMAL_FORMAT);
	public static void getQOSForInterface(ConcurrentHashMap<String,ArrayList<QosForm>> qosFormListelement, Folder interfaceFolder, InventoryDataset inventoryDataset, SnmpCreditionals snmpCreditionals) throws NimException, InterruptedException {
		ConcurrentHashMap<String,ArrayList<QosForm>> qosFormLMap=qosFormListelement;
		Set<String> descList=qosFormLMap.keySet();
		for(String description:descList){
			Interface interfaces = Interface.addInstance(inventoryDataset, new EntityId(interfaceFolder, description), description, interfaceFolder);
			ArrayList<QosForm> qosFormList=qosFormLMap.get(description);
			for (QosForm qosForm : qosFormList) {
					MetricDef metric = getMetricDef(qosForm.getElement(), qosForm.getMetricName());
					interfaces.setMetric((MetricDef) metric,Long.parseLong(qosForm.getQos()) );
			}
			
		}
	}
	public static void getQOSForUCCXInterface(ConcurrentHashMap<String,ArrayList<QosForm>> qosFormListelement, Folder interfaceFolder, InventoryDataset inventoryDataset, SnmpCreditionals snmpCreditionals) throws NimException, InterruptedException {
		ConcurrentHashMap<String,ArrayList<QosForm>> qosFormLMap=qosFormListelement;
		Set<String> descList=qosFormLMap.keySet();
		for(String description:descList){
			UCCXInterface uccxInterfaces = UCCXInterface.addInstance(inventoryDataset, new EntityId(interfaceFolder, description), description, interfaceFolder);
			ArrayList<QosForm> qosFormList=qosFormLMap.get(description);
			for (QosForm qosForm : qosFormList) {
					MetricDef metric = getMetricDef(qosForm.getElement(), qosForm.getMetricName());
					uccxInterfaces.setMetric((MetricDef) metric,Long.parseLong(qosForm.getQos()) );
			}
		}
	}
	public static void getQOSForUCCEInterface(ConcurrentHashMap<String,ArrayList<QosForm>> qosFormListelement, Folder interfaceFolder, InventoryDataset inventoryDataset, SnmpCreditionals snmpCreditionals) throws NimException, InterruptedException {
		ConcurrentHashMap<String,ArrayList<QosForm>> qosFormLMap=qosFormListelement;
		Set<String> descList=qosFormLMap.keySet();
		for(String description:descList){
			UCCEInterface uccxInterfaces = UCCEInterface.addInstance(inventoryDataset, new EntityId(interfaceFolder, description), description, interfaceFolder);
			ArrayList<QosForm> qosFormList=qosFormLMap.get(description);
			for (QosForm qosForm : qosFormList) {
					MetricDef metric = getMetricDef(qosForm.getElement(), qosForm.getMetricName());
					uccxInterfaces.setMetric((MetricDef) metric,Long.parseLong(qosForm.getQos()) );
			}
		}
	}
	public static void getQOSForProcess(ConcurrentHashMap<String,ArrayList<QosForm>> qosFormListelement, Folder processFolder, InventoryDataset inventoryDataset, SnmpCreditionals snmpCreditionals) throws NimException, InterruptedException {
		ConcurrentHashMap<String,ArrayList<QosForm>> qosFormLMap=qosFormListelement;
		Set<String> descList=qosFormLMap.keySet();
		for(String description:descList){
			Software process = Software.addInstance(inventoryDataset, new EntityId(processFolder, "Process "+"-"+description), description, processFolder);
			ArrayList<QosForm> qosFormList=qosFormLMap.get(description);
			for (QosForm qosForm : qosFormList) {
					MetricDef metric = getMetricDef(qosForm.getElement(), qosForm.getMetricName());
					process.setMetric((MetricDef) metric,Long.parseLong(qosForm.getQos()) );
			}
			
		}
	}
	public static void getQOSForUCCXProcess(ConcurrentHashMap<String,ArrayList<QosForm>> qosFormListelement, Folder processFolder, InventoryDataset inventoryDataset, SnmpCreditionals snmpCreditionals) throws NimException, InterruptedException {
		ConcurrentHashMap<String,ArrayList<QosForm>> qosFormLMap=qosFormListelement;
		Set<String> descList=qosFormLMap.keySet();
		for(String description:descList){
			UCCXSoftware process = UCCXSoftware.addInstance(inventoryDataset, new EntityId(processFolder, "Process "+"-"+description), description, processFolder);
			ArrayList<QosForm> qosFormList=qosFormLMap.get(description);
			for (QosForm qosForm : qosFormList) {
					MetricDef metric = getMetricDef(qosForm.getElement(), qosForm.getMetricName());
					process.setMetric((MetricDef) metric,Long.parseLong(qosForm.getQos()) );
			}
			
		}
	}
	public static void getQOSForUCCEProcess(ConcurrentHashMap<String,ArrayList<QosForm>> qosFormListelement, Folder processFolder, InventoryDataset inventoryDataset, SnmpCreditionals snmpCreditionals) throws NimException, InterruptedException {
		ConcurrentHashMap<String,ArrayList<QosForm>> qosFormLMap=qosFormListelement;
		Set<String> descList=qosFormLMap.keySet();
		for(String description:descList){
			UCCESoftware process = UCCESoftware.addInstance(inventoryDataset, new EntityId(processFolder, "Process "+"-"+description), description, processFolder);
			ArrayList<QosForm> qosFormList=qosFormLMap.get(description);
			for (QosForm qosForm : qosFormList) {
					MetricDef metric = getMetricDef(qosForm.getElement(), qosForm.getMetricName());
					process.setMetric((MetricDef) metric,Long.parseLong(qosForm.getQos()) );
			}
			
		}
	}
	public static  void getQOSForGateWayInfo(ConcurrentHashMap<String,ArrayList<QosForm>> qosFormListelement, Folder gateWayInfoFolder, InventoryDataset inventoryDataset, SnmpCreditionals snmpCreditionals,GraphHelper graph) throws NimException, InterruptedException {
		
			ConcurrentHashMap<String,ArrayList<QosForm>> qosFormLMap=qosFormListelement;
			Set<String> descList=qosFormLMap.keySet();
			for(String description:descList){
				GateWayInfoChild gateWayInfoChild = GateWayInfoChild.addInstance(inventoryDataset, new EntityId(gateWayInfoFolder,description), description, gateWayInfoFolder);
				gateWayInfoChild.setCcmGateWayInfoConfigDef(ProbeMain.ccmGateWayInfoConfigDef);
				gateWayInfoChild.setGraphHelper(graph);
				Map<String, Object> valuesMap = new ConcurrentHashMap<String, Object>();
				ArrayList<QosForm> qosFormList=qosFormLMap.get(description);
				for (QosForm qosForm : qosFormList) {
					if(qosForm!=null && qosForm.getElement()!="" && qosForm.getMetricName()!=""){
						Log.info("OID NAME for Status =======================    "+qosForm.getOidName()+"         QOS =================    "+qosForm.getQos());
						MetricDef metric = getMetricDef(qosForm.getElement(), qosForm.getMetricName());
						gateWayInfoChild.setMetric((MetricDef) metric,Long.parseLong(qosForm.getQos()) );
					}else{
						Log.info("OID NAME =======================    "+qosForm.getOidName()+"         QOS =================    "+qosForm.getQos());
						valuesMap.put(qosForm.getOidName(),qosForm.getQos());
					}
				}
				gateWayInfoChild.setValuesMap(valuesMap);
			}
		}
	public static void getQOSForProcessors(ConcurrentHashMap<String,ArrayList<QosForm>> qosFormListelement, Folder interfaceFolder, InventoryDataset inventoryDataset, SnmpCreditionals snmpCreditionals) throws NimException, InterruptedException {
		ConcurrentHashMap<String,ArrayList<QosForm>> qosFormLMap=qosFormListelement;
		Set<String> descList=qosFormLMap.keySet();
		for(String description:descList){
			Processor processor = Processor.addInstance(inventoryDataset, new EntityId(interfaceFolder, description), description, interfaceFolder);
			ArrayList<QosForm> qosFormList=qosFormLMap.get(description);
			for (QosForm qosForm : qosFormList) {
					MetricDef metric = getMetricDef(qosForm.getElement(), qosForm.getMetricName());
					processor.setMetric((MetricDef) metric,Long.parseLong(qosForm.getQos()) );
			}
		}
	}
	public static void getQOSForUCCXProcessors(ConcurrentHashMap<String,ArrayList<QosForm>> qosFormListelement, Folder interfaceFolder, InventoryDataset inventoryDataset, SnmpCreditionals snmpCreditionals) throws NimException, InterruptedException {
		ConcurrentHashMap<String,ArrayList<QosForm>> qosFormLMap=qosFormListelement;
		Set<String> descList=qosFormLMap.keySet();
		for(String description:descList){
			UCCXProcessor processor = UCCXProcessor.addInstance(inventoryDataset, new EntityId(interfaceFolder, description), description, interfaceFolder);
			ArrayList<QosForm> qosFormList=qosFormLMap.get(description);
			for (QosForm qosForm : qosFormList) {
					MetricDef metric = getMetricDef(qosForm.getElement(), qosForm.getMetricName());
					processor.setMetric((MetricDef) metric,Long.parseLong(qosForm.getQos()) );
			}
		}
	}
	public static void getQOSForUCCEProcessors(ConcurrentHashMap<String,ArrayList<QosForm>> qosFormListelement, Folder interfaceFolder, InventoryDataset inventoryDataset, SnmpCreditionals snmpCreditionals) throws NimException, InterruptedException {
		ConcurrentHashMap<String,ArrayList<QosForm>> qosFormLMap=qosFormListelement;
		Set<String> descList=qosFormLMap.keySet();
		for(String description:descList){
			UCCEProcessor processor = UCCEProcessor.addInstance(inventoryDataset, new EntityId(interfaceFolder, description), description, interfaceFolder);
			ArrayList<QosForm> qosFormList=qosFormLMap.get(description);
			for (QosForm qosForm : qosFormList) {
					MetricDef metric = getMetricDef(qosForm.getElement(), qosForm.getMetricName());
					processor.setMetric((MetricDef) metric,Long.parseLong(qosForm.getQos()) );
			}
		}
	}
	public static void  getQOSForMemory(ConcurrentHashMap<String,ArrayList<QosForm>> qosFormListelement, Folder interfaceFolder, InventoryDataset inventoryDataset, SnmpCreditionals snmpCreditionals) throws NimException, InterruptedException {
		ConcurrentHashMap<String,ArrayList<QosForm>> qosFormLMap=qosFormListelement;
		Set<String> descList=qosFormLMap.keySet();
		for(String description:descList){
			Memory memory = Memory.addInstance(inventoryDataset, new EntityId(interfaceFolder, description), description, interfaceFolder);
			ArrayList<QosForm> qosFormList=qosFormLMap.get(description);
			for (QosForm qosForm : qosFormList) {
					MetricDef metric = getMetricDef(qosForm.getElement(), qosForm.getMetricName());
					memory.setMetric((MetricDef) metric,Long.parseLong(qosForm.getQos()) );
			}
		}
	}
	public static void  getQOSForUCCXMemory(ConcurrentHashMap<String,ArrayList<QosForm>> qosFormListelement, Folder interfaceFolder, InventoryDataset inventoryDataset, SnmpCreditionals snmpCreditionals) throws NimException, InterruptedException {
		ConcurrentHashMap<String,ArrayList<QosForm>> qosFormLMap=qosFormListelement;
		Set<String> descList=qosFormLMap.keySet();
		for(String description:descList){
			UCCXMemory memory = UCCXMemory.addInstance(inventoryDataset, new EntityId(interfaceFolder, description), description, interfaceFolder);
			ArrayList<QosForm> qosFormList=qosFormLMap.get(description);
			for (QosForm qosForm : qosFormList) {
					MetricDef metric = getMetricDef(qosForm.getElement(), qosForm.getMetricName());
					memory.setMetric((MetricDef) metric,Long.parseLong(qosForm.getQos()) );
			}
		}
	}
	public static void  getQOSForUCCEMemory(ConcurrentHashMap<String,ArrayList<QosForm>> qosFormListelement, Folder interfaceFolder, InventoryDataset inventoryDataset, SnmpCreditionals snmpCreditionals) throws NimException, InterruptedException {
		ConcurrentHashMap<String,ArrayList<QosForm>> qosFormLMap=qosFormListelement;
		Set<String> descList=qosFormLMap.keySet();
		for(String description:descList){
			UCCEMemory memory = UCCEMemory.addInstance(inventoryDataset, new EntityId(interfaceFolder, description), description, interfaceFolder);
			ArrayList<QosForm> qosFormList=qosFormLMap.get(description);
			for (QosForm qosForm : qosFormList) {
					MetricDef metric = getMetricDef(qosForm.getElement(), qosForm.getMetricName());
					memory.setMetric((MetricDef) metric,Long.parseLong(qosForm.getQos()) );
			}
		}
	}
	/*public static void  getQOSForCccaComponentTable(ConcurrentHashMap<String,ArrayList<QosForm>> descQOSFormElementMap, Folder interfaceFolder, InventoryDataset inventoryDataset, SnmpCreditionals snmpCreditionals) throws NimException, InterruptedException {
		ConcurrentHashMap<String,ArrayList<QosForm>> qosFormLMap=descQOSFormElementMap;
		Set<String> descSet=qosFormLMap.keySet();
		for(String description:descSet){
			CCCAComponentTable cccaComponentTable = CCCAComponentTable.addInstance(inventoryDataset, new EntityId(interfaceFolder, description), description, interfaceFolder);
			ArrayList<QosForm> qosFormList=qosFormLMap.get(description);
			for (QosForm qosForm : qosFormList) {
				if(qosForm!=null && qosForm.getElement()!="" && qosForm.getMetricName()!=""){
					MetricDef metric = getMetricDef(qosForm.getElement(), qosForm.getMetricName());
					cccaComponentTable.setMetric((MetricDef) metric,Long.parseLong(qosForm.getQos()) );
				}
			}
		}
	}*/
	
	public static  void getQOSForCccaComponentTable(ConcurrentHashMap<String,ArrayList<QosForm>> descQosMap, Folder folder, InventoryDataset inventoryDataset, SnmpCreditionals snmpCreditionals,GraphHelper graph) throws NimException, InterruptedException {
		ConcurrentHashMap<String,ArrayList<QosForm>> qosFormLMap=descQosMap;
		Set<String> descList=qosFormLMap.keySet();
		for(String description:descList){
			try{
			CCCAComponentTableChild cccaComponentChild = CCCAComponentTableChild.addInstance(inventoryDataset, new EntityId(folder, description), description, folder);
			cccaComponentChild.setComponentTableConfigDef(ProbeMain.cccaComponentTableConfigDef);
			cccaComponentChild.setGraphHelper(graph);
			Map<String, Object> valuesMap = new ConcurrentHashMap<String, Object>();
			ArrayList<QosForm> qosFormList=qosFormLMap.get(description);
			for (QosForm qosForm : qosFormList) {
				if(qosForm!=null && qosForm.getElement()!="" && qosForm.getMetricName()!=""){
					MetricDef metric = QOSUtil.getMetricDef(qosForm.getElement(), qosForm.getMetricName());
					cccaComponentChild.setMetric((MetricDef) metric,Long.parseLong(qosForm.getQos()) );
				}else{
					valuesMap.put(qosForm.getOidName(),qosForm.getQos());
				}
				
			}
			cccaComponentChild.setValuesMap(valuesMap);
		}catch(Exception e){
			Log.info("#############################Exception in getQOSForCCCALoggerTable: "+e);
		}
		}
	}
	
	/*public static void  getQOSForRouterTable(ConcurrentHashMap<String,ArrayList<QosForm>> descQOSFormElementMap, Folder interfaceFolder, InventoryDataset inventoryDataset, SnmpCreditionals snmpCreditionals) throws NimException, InterruptedException {
		ConcurrentHashMap<String,ArrayList<QosForm>> qosFormLMap=descQOSFormElementMap;
		Set<String> descSet=qosFormLMap.keySet();
		for(String description:descSet){
			CCCARouterTable cccaComponentTable = CCCARouterTable.addInstance(inventoryDataset, new EntityId(interfaceFolder, description), description, interfaceFolder);
			ArrayList<QosForm> qosFormList=qosFormLMap.get(description);
			for (QosForm qosForm : qosFormList) {
				if(qosForm!=null && qosForm.getElement()!="" && qosForm.getMetricName()!=""){
					MetricDef metric = getMetricDef(qosForm.getElement(), qosForm.getMetricName());
					cccaComponentTable.setMetric((MetricDef) metric,Long.parseLong(qosForm.getQos()) );
				}
			}
		}
	}*/
	
	public static void getQOSForRouterTable(SnmpCreditionals snmpCreditionals, ConcurrentHashMap<String,ArrayList<QosForm>> pollOidelement, Folder folder, InventoryDataset inventoryDataset, GraphHelper graph){
		ConcurrentHashMap<String,ArrayList<QosForm>> qosFormLMap=pollOidelement;
		Set<String> descList=qosFormLMap.keySet();
		for(String description:descList){
			try{
				CCCARouterTableChild ccmRouterChild = CCCARouterTableChild.addInstance(inventoryDataset, new EntityId(folder, description), description, folder);
				ccmRouterChild.setRouterTableConfigDef(ProbeMain.cccaRouterTableConfigDef);
				ccmRouterChild.setGraphHelper(graph);
				Map<String, Object> valuesMap = new ConcurrentHashMap<String, Object>();
				ArrayList<QosForm> qosFormList=qosFormLMap.get(description);
				for (QosForm qosForm : qosFormList) {
					if(qosForm!=null && qosForm.getElement()!="" && qosForm.getMetricName()!=""){
						MetricDef metric = getMetricDef(qosForm.getElement(), qosForm.getMetricName());
						ccmRouterChild.setMetric((MetricDef) metric,Long.parseLong(qosForm.getQos()) );
					}else{
						if(qosForm.getOidName().equals(Constants.CCCA_ROUTER_SIDE)&&qosForm.getQos().equals("1")){
							valuesMap.put(qosForm.getOidName(),Constants.CCCA_ROUTER_SIDEA_PARSE);
						}else if(qosForm.getOidName().equals(Constants.CCCA_ROUTER_SIDE)&&qosForm.getQos().equals("2")) {
							valuesMap.put(qosForm.getOidName(),Constants.CCCA_ROUTER_SIDEB_PARSE);
						}else{
							valuesMap.put(qosForm.getOidName(),qosForm.getQos());
						}
						
					}
				}
				ccmRouterChild.setValuesMap(valuesMap);
			}catch(Exception e){
				Log.info(e.toString());
			}
			
		}
		
	}
	
	
	public static  void getQOSForCcmGlobalInfo(ConcurrentHashMap<String,ArrayList<QosForm>> descQosMap, Folder folder, InventoryDataset inventoryDataset, SnmpCreditionals snmpCreditionals,GraphHelper graph) throws NimException, InterruptedException {
		ConcurrentHashMap<String,ArrayList<QosForm>> qosFormLMap=descQosMap;
		Set<String> descList=qosFormLMap.keySet();
		for(String description:descList){
			CcmGlobalInfoChild ccmGlobalInfoChild = CcmGlobalInfoChild.addInstance(inventoryDataset, new EntityId(folder, description), description, folder);
			ccmGlobalInfoChild.setCcmGlobalInfoConfigDef(ProbeMain.ccmGlobalInfoConfigDef);
			ccmGlobalInfoChild.setGraphHelper(graph);
			Map<String, Object> valuesMap = new ConcurrentHashMap<String, Object>();
			ArrayList<QosForm> qosFormList=qosFormLMap.get(description);
			for (QosForm qosForm : qosFormList) {
				if(qosForm!=null && qosForm.getElement()!="" && qosForm.getMetricName()!=""){
					MetricDef metric = getMetricDef(qosForm.getElement(), qosForm.getMetricName());
					ccmGlobalInfoChild.setMetric((MetricDef) metric,Long.parseLong(qosForm.getQos()) );
				}else{
					valuesMap.put(qosForm.getOidName(),qosForm.getQos());
				}
			}
			ccmGlobalInfoChild.setValuesMap(valuesMap);
		}
	}
	public static void getQOSForTrunk(ConcurrentHashMap<String, ArrayList<QosForm>> descQosMap,Folder folder,InventoryDataset inventoryDataset,SnmpCreditionals snmpCreditionals,GraphHelper graph) throws NimException, InterruptedException{
		Set<String> descSet=descQosMap.keySet();
		for(String description:descSet){
			//CcmPhoneInfo ccmPhoneInfo = CcmPhoneInfo.addInstance(inventoryDataset, new EntityId(folder, description), description, folder); 
			GateWayTrunkChild gateWayTrunkChild =null;
			gateWayTrunkChild = GateWayTrunkChild.addInstance(inventoryDataset, new EntityId(folder, description), description, folder);
			gateWayTrunkChild.setCcmGlobalTrunkConfigDef(ProbeMain.ccmGlobalTrunkConfigDef);
			gateWayTrunkChild.setGraphHelper(graph);
			Map<String, Object> valuesMap = new ConcurrentHashMap<String, Object>();
			ArrayList<QosForm> qosFormList=descQosMap.get(description);
			for (QosForm qosForm : qosFormList) {
					if(qosForm!=null && qosForm.getElement()!=""&&qosForm.getMetricName()!=""){
						MetricDef metric = getMetricDef(qosForm.getElement(), qosForm.getMetricName());
						gateWayTrunkChild.setMetric((MetricDef) metric,Long.parseLong(qosForm.getQos()) );
					}if(qosForm!=null && qosForm.getElement()==""&&qosForm.getMetricName()==""){
						valuesMap.put(qosForm.getOidName(),qosForm.getQos());
						
					}
			}
			gateWayTrunkChild.setValuesMap(valuesMap);
		}
	}
	public static void getQOSForCucmGroupTable(ConcurrentHashMap<String, ArrayList<QosForm>> descQosMap,Folder folder,InventoryDataset inventoryDataset,SnmpCreditionals snmpCreditionals,GraphHelper graph) throws NimException, InterruptedException{
		Set<String> descSet=descQosMap.keySet();
		for(String description:descSet){
			//CcmPhoneInfo ccmPhoneInfo = CcmPhoneInfo.addInstance(inventoryDataset, new EntityId(folder, description), description, folder); 
			CucmGroupTableChild cucmGroupTableChild =null;
			cucmGroupTableChild = CucmGroupTableChild.addInstance(inventoryDataset, new EntityId(folder, description), description, folder);
			cucmGroupTableChild.setCucmGroupTableConfigDef(ProbeMain.cucmGroupTableConfigDef);
			cucmGroupTableChild.setGraphHelper(graph);
			Map<String, Object> valuesMap = new ConcurrentHashMap<String, Object>();
			ArrayList<QosForm> qosFormList=descQosMap.get(description);
			for (QosForm qosForm : qosFormList) {
					if(qosForm!=null && qosForm.getElement()!=""&&qosForm.getMetricName()!=""){
						MetricDef metric = getMetricDef(qosForm.getElement(), qosForm.getMetricName());
						cucmGroupTableChild.setMetric((MetricDef) metric,Long.parseLong(qosForm.getQos()) );
					}if(qosForm!=null && qosForm.getElement()==""&&qosForm.getMetricName()==""){
						valuesMap.put(qosForm.getOidName(),qosForm.getQos());
						
					}
			}
			cucmGroupTableChild.setValuesMap(valuesMap);
		}
	}
	
	public static void getQOSForCucmTable(ConcurrentHashMap<String, ArrayList<QosForm>> descQosMap,Folder folder,InventoryDataset inventoryDataset,SnmpCreditionals snmpCreditionals,GraphHelper graph) throws NimException, InterruptedException{
		Set<String> descSet=descQosMap.keySet();
		for(String description:descSet){
			//CcmPhoneInfo ccmPhoneInfo = CcmPhoneInfo.addInstance(inventoryDataset, new EntityId(folder, description), description, folder); 
			CucmTableChild cucmTableChild =null;
			cucmTableChild = CucmTableChild.addInstance(inventoryDataset, new EntityId(folder, description), description, folder);
			cucmTableChild.setCucmTableConfigDef(ProbeMain.cucmTableConfigDef);
			cucmTableChild.setGraphHelper(graph);
			Map<String, Object> valuesMap = new ConcurrentHashMap<String, Object>();
			ArrayList<QosForm> qosFormList=descQosMap.get(description);
			for (QosForm qosForm : qosFormList) {
					if(qosForm!=null && qosForm.getElement()!=""&&qosForm.getMetricName()!=""){
						MetricDef metric = getMetricDef(qosForm.getElement(), qosForm.getMetricName());
						cucmTableChild.setMetric((MetricDef) metric,Long.parseLong(qosForm.getQos()) );
					}if(qosForm!=null && qosForm.getElement()==""&&qosForm.getMetricName()==""){
						valuesMap.put(qosForm.getOidName(),qosForm.getQos());
						
					}
			}
			cucmTableChild.setValuesMap(valuesMap);
		}
		
	}
	
	public static void getQosForAxlMetric(Map<String,List<QOS>> axlMap,SnmpCreditionals snmpCreditionals,Folder axlGlobalFolder,InventoryDataset inventoryDataset) throws NimException, InterruptedException{
		Set<String> descList=axlMap.keySet();
		for(String description:descList ){
			if(description.equalsIgnoreCase("TCP")){
			Log.info("Description For TCP ==========================     "+description);
			TCP tcp = TCP.addInstance(inventoryDataset, new EntityId(axlGlobalFolder, description), description, axlGlobalFolder);
			ArrayList<QOS> qosList = (ArrayList<QOS>) axlMap.get(description);
			for (QOS qos : qosList) {
				if(qos.getKey().equalsIgnoreCase("Active Opens")){
					MetricDef metric = getMetricDef("com.nimsoft.types.TCP", "ActiveOpens");
					Log.info("QOS for TCP  ==========================     "+qos.getValue());
					tcp.setMetric((MetricDef) metric,qos.getValue());
				}
			}
		}}
	}
	public static void getCcmPhoneInfo(ConcurrentHashMap<String, ArrayList<QosForm>> descQosMap,Folder folder,InventoryDataset inventoryDataset,SnmpCreditionals snmpCreditionals,GraphHelper graph) throws NimException, InterruptedException{
		Set<String> descSet=descQosMap.keySet();
		for(String description:descSet){
			CcmPhoneInfoChild ccmPhoneInfoChild =null;
			ccmPhoneInfoChild = CcmPhoneInfoChild.addInstance(inventoryDataset, new EntityId(folder, description), description, folder);
			ccmPhoneInfoChild.setCcmPhoneInfoConfigDef(ProbeMain.ccmPhoneInfoConfigDef);
			ccmPhoneInfoChild.setGraphHelper(graph);
			Map<String, Object> valuesMap = new ConcurrentHashMap<String, Object>();
			ArrayList<QosForm> qosFormList=descQosMap.get(description);
			for (QosForm qosForm : qosFormList) {
					if(qosForm!=null && qosForm.getElement()!=""&&qosForm.getMetricName()!=""){
						MetricDef metric = getMetricDef(qosForm.getElement(), qosForm.getMetricName());
						ccmPhoneInfoChild.setMetric((MetricDef) metric,Long.parseLong(qosForm.getQos()) );
					}else{
						valuesMap.put(qosForm.getOidName(),qosForm.getQos());
					}
			}
			ccmPhoneInfoChild.setValuesMap(valuesMap);
		}
	}

	public static ConcurrentHashMap<String,ConcurrentHashMap<String,ConcurrentHashMap<String,ArrayList<QosForm>>>> pollOid(ConcurrentHashMap<String,ConcurrentHashMap<String,IndexElement>> groupSetMaps, final SnmpCreditionals snmpCreditionals){
		final ConcurrentHashMap<String,ConcurrentHashMap<String,ConcurrentHashMap<String,ArrayList<QosForm>>>> pooledValueMap=new ConcurrentHashMap<String,ConcurrentHashMap<String,ConcurrentHashMap<String,ArrayList<QosForm>>>>();
		long starttime = System.currentTimeMillis();
		ExecutorService executor = Executors.newFixedThreadPool(5);
		List<FutureTask<Boolean>> taskList = new ArrayList<FutureTask<Boolean>>();
		final NumberFormat formatter = new DecimalFormat(Constants.DECIMAL_FORMAT);
		final ConcurrentHashMap<String,ConcurrentHashMap<String,IndexElement>> groupSetMap=groupSetMaps;
		Set<String> groupSet=groupSetMap.keySet();
		for(final String group:groupSet){
			if (group.equalsIgnoreCase(Constants.SOFTWARE)) {
				FutureTask<Boolean> pollTask = new FutureTask<Boolean>(new Runnable() {
					@Override
					public void run() {
						try {
							long startTime = System.currentTimeMillis();
							ConcurrentHashMap<String,IndexElement> groupMap=groupSetMap.get(group);
							Set<String> elementSet=groupMap.keySet();
							ConcurrentHashMap<String,ConcurrentHashMap<String,ArrayList<QosForm>>> hhh=new ConcurrentHashMap<String,ConcurrentHashMap<String,ArrayList<QosForm>>>();
							for(String element:elementSet){
								if(element.equalsIgnoreCase(Constants.SOFTWARE)){
									ConcurrentHashMap<String,ArrayList<QosForm>> qosMap=new ConcurrentHashMap<String,ArrayList<QosForm>>();
									IndexElement idx=groupMap.get(element);
									if(idx != null){
										ArrayList<String> indexList=idx.getIndexList();
										ArrayList<String> desc=idx.getDescList();
										ArrayList<OidForm> oidFormList=idx.getOidFormList();
										for (int count = 0; count < indexList.size(); count++) {
											ArrayList<QosForm> qosFormList=new ArrayList<QosForm>();
											for (OidForm oidForm : oidFormList) {
												if (!oidForm.getOidName().equalsIgnoreCase(Constants.HR_SW_RUNINDEX) && !oidForm.getOidName().equalsIgnoreCase(Constants.HR_SW_RUNNAME)) {
													VariableBinding variableBinding = SNMPUtils.poll(snmpCreditionals, oidForm.getOidValue() + "." + indexList.get(count));
													String qos=variableBinding.getVariable().isException() ? Constants.NOT_ACCESSIBLE : variableBinding.getVariable().toString();
													String description=desc.get(count);
													String index= indexList.get(count);
													QosForm qosForm=getQosFormList(oidForm, qos, description,index);
													qosFormList.add(qosForm);
												}
											}
											qosMap.put(desc.get(count), qosFormList);
										}
									} 
									hhh.put(element, qosMap);
								}
							}
							pooledValueMap.put(group, hhh);
							 long endTime = System.currentTimeMillis();
							 long totalTime = endTime - startTime;
							 Log.trace("Contact_center::Execution time for SOFTWARE[" + totalTime + "]ms");
			                 Log.info("Contact_center::Execution time for SOFTWARE[" + formatter.format((endTime - startTime) / 1000d) + "]seconds");
						}catch(Exception e){
							Log.error("Contact_Center Probe::Exception while Data collection for SOFTWARE", e);
						}
					}
				},true);
				taskList.add(pollTask);
				executor.execute(pollTask);
			}
			if (group.equalsIgnoreCase(Constants.UCCX_SOFTWARE)) {
				FutureTask<Boolean> pollTask1 = new FutureTask<Boolean>(new Runnable() {
					@Override
					public void run() {
						try {
							long startTime = System.currentTimeMillis();
							ConcurrentHashMap<String,IndexElement> groupMap=groupSetMap.get(group);
							Set<String> elementSet=groupMap.keySet();
							ConcurrentHashMap<String,ConcurrentHashMap<String,ArrayList<QosForm>>> hhh=new ConcurrentHashMap<String,ConcurrentHashMap<String,ArrayList<QosForm>>>();
							for(String element:elementSet){
								if(element.equalsIgnoreCase(Constants.UCCX_SOFTWARE)){
									ConcurrentHashMap<String,ArrayList<QosForm>> qosMap=new ConcurrentHashMap<String,ArrayList<QosForm>>();
									IndexElement idx=groupMap.get(element);
									if(idx != null){
										ArrayList<String> indexList=idx.getIndexList();
										ArrayList<String> desc=idx.getDescList();
										ArrayList<OidForm> oidFormList=idx.getOidFormList();
										for (int count = 0; count < indexList.size(); count++) {
											ArrayList<QosForm> qosFormList=new ArrayList<QosForm>();
											for (OidForm oidForm : oidFormList) {
												if (!oidForm.getOidName().equalsIgnoreCase(Constants.HR_SW_RUNINDEX) && !oidForm.getOidName().equalsIgnoreCase(Constants.HR_SW_RUNNAME)) {
													VariableBinding variableBinding = SNMPUtils.poll(snmpCreditionals, oidForm.getOidValue() + "." + indexList.get(count));
													String qos=variableBinding.getVariable().isException() ? Constants.NOT_ACCESSIBLE : variableBinding.getVariable().toString();
													String description=desc.get(count);
													String index= indexList.get(count);
													QosForm qosForm=getQosFormList(oidForm, qos, description,index);
													qosFormList.add(qosForm);
												}
											}
											qosMap.put(desc.get(count), qosFormList);
										}
									} 
									hhh.put(element, qosMap);
								}
							}
							pooledValueMap.put(group, hhh);
							 long endTime = System.currentTimeMillis();
							 long totalTime = endTime - startTime;
							 Log.trace("Contact_center::Execution time for SOFTWARE[" + totalTime + "]ms");
			                 Log.info("Contact_center::Execution time for SOFTWARE[" + formatter.format((endTime - startTime) / 1000d) + "]seconds");
						}catch(Exception e){
							Log.error("Contact_Center Probe::Exception while Data collection for SOFTWARE", e);
						}
					}
				},true);
				taskList.add(pollTask1);
				executor.execute(pollTask1);
			}
			if (group.equalsIgnoreCase(Constants.UCCE_SOFTWARE)) {
				FutureTask<Boolean> pollTask2 = new FutureTask<Boolean>(new Runnable() {
					@Override
					public void run() {
						try {
							long startTime = System.currentTimeMillis();
							ConcurrentHashMap<String,IndexElement> groupMap=groupSetMap.get(group);
							Set<String> elementSet=groupMap.keySet();
							ConcurrentHashMap<String,ConcurrentHashMap<String,ArrayList<QosForm>>> hhh=new ConcurrentHashMap<String,ConcurrentHashMap<String,ArrayList<QosForm>>>();
							for(String element:elementSet){
								if(element.equalsIgnoreCase(Constants.UCCE_SOFTWARE)){
									ConcurrentHashMap<String,ArrayList<QosForm>> qosMap=new ConcurrentHashMap<String,ArrayList<QosForm>>();
									IndexElement idx=groupMap.get(element);
									if(idx != null){
										ArrayList<String> indexList=idx.getIndexList();
										ArrayList<String> desc=idx.getDescList();
										ArrayList<OidForm> oidFormList=idx.getOidFormList();
										for (int count = 0; count < indexList.size(); count++) {
											ArrayList<QosForm> qosFormList=new ArrayList<QosForm>();
											for (OidForm oidForm : oidFormList) {
												if (!oidForm.getOidName().equalsIgnoreCase(Constants.HR_SW_RUNINDEX) && !oidForm.getOidName().equalsIgnoreCase(Constants.HR_SW_RUNNAME)) {
													VariableBinding variableBinding = SNMPUtils.poll(snmpCreditionals, oidForm.getOidValue() + "." + indexList.get(count));
													String qos=variableBinding.getVariable().isException() ? Constants.NOT_ACCESSIBLE : variableBinding.getVariable().toString();
													String description=desc.get(count);
													String index= indexList.get(count);
													QosForm qosForm=getQosFormList(oidForm, qos, description,index);
													qosFormList.add(qosForm);
												}
											}
											qosMap.put(desc.get(count), qosFormList);
										}
									} 
									hhh.put(element, qosMap);
								}
							}
							pooledValueMap.put(group, hhh);
							 long endTime = System.currentTimeMillis();
							 long totalTime = endTime - startTime;
							 Log.trace("Contact_center::Execution time for SOFTWARE[" + totalTime + "]ms");
			                 Log.info("Contact_center::Execution time for SOFTWARE[" + formatter.format((endTime - startTime) / 1000d) + "]seconds");
						}catch(Exception e){
							Log.error("Contact_Center Probe::Exception while Data collection for SOFTWARE", e);
						}
					}
				},true);
				taskList.add(pollTask2);
				executor.execute(pollTask2);
			}
			if (group.equalsIgnoreCase(Constants.INTERFACE)) {

				FutureTask<Boolean> pollTask3 = new FutureTask<Boolean>(new Runnable() {
					
					@Override
					public void run() {
						try {
							long startTime = System.currentTimeMillis();
							ConcurrentHashMap<String,IndexElement> groupMap=groupSetMap.get(group);
							Set<String> elementSet=groupMap.keySet();
							ConcurrentHashMap<String,ConcurrentHashMap<String,ArrayList<QosForm>>> hhh=new ConcurrentHashMap<String,ConcurrentHashMap<String,ArrayList<QosForm>>>();
							for(String element:elementSet){
								if(element.equalsIgnoreCase(Constants.INTERFACE)){
									ConcurrentHashMap<String,ArrayList<QosForm>> qosMap=new ConcurrentHashMap<String,ArrayList<QosForm>>();
									IndexElement idx=groupMap.get(element);
									if(idx != null){
										ArrayList<String> indexList=idx.getIndexList();
										ArrayList<String> desc=idx.getDescList();
										ArrayList<OidForm> oidFormList=idx.getOidFormList();
										for (int count = 0; count < indexList.size(); count++) {
											ArrayList<QosForm> qosFormList=new ArrayList<QosForm>();
											for (OidForm oidForm : oidFormList) {
												if (!oidForm.getOidName().equalsIgnoreCase(Constants.IF_INDEX) && !oidForm.getOidName().equalsIgnoreCase(Constants.IF_DESC)) {
													String qos="";
													VariableBinding variableBinding = SNMPUtils.poll(snmpCreditionals, oidForm.getOidValue() + "." + indexList.get(count));
													
													if(!oidForm.getOidName().equalsIgnoreCase(Constants.LAST_CHANGE)){  //For timetick
														 qos=variableBinding.getVariable().isException() ? Constants.ZERO : variableBinding.getVariable().toString();
													}else{
													 qos = variableBinding.getVariable().isException() ? Constants.ZERO : Long.toString(variableBinding.getVariable().toLong());
													}
													 String description=desc.get(count);
													String index= indexList.get(count);
													QosForm qosForm=getQosFormList(oidForm, qos, description,index);
													qosFormList.add(qosForm);
												}
											}
											qosMap.put(desc.get(count), qosFormList);
										}
									} 
									hhh.put(element, qosMap);
								}
							}
							pooledValueMap.put(group, hhh);
							long endTime = System.currentTimeMillis();
							 long totalTime = endTime - startTime;
							 Log.trace("Contact_center::Execution time for INTERFACE[" + totalTime + "]ms");
			                 Log.info("Contact_center::Execution time for INTERFACE[" + formatter.format((endTime - startTime) / 1000d) + "]seconds");

						}catch(Exception e){
							Log.error("Contact_Center Probe::Exception while Data collection for INTERFACE", e);
						}
					}
				},true);
				taskList.add(pollTask3);
				executor.execute(pollTask3);
			}
			
			if (group.equalsIgnoreCase(Constants.UCCX_INTERFACE)) {

				FutureTask<Boolean> pollTask4 = new FutureTask<Boolean>(new Runnable() {
					
					@Override
					public void run() {
						try {
							long startTime = System.currentTimeMillis();
							ConcurrentHashMap<String,IndexElement> groupMap=groupSetMap.get(group);
							Set<String> elementSet=groupMap.keySet();
							ConcurrentHashMap<String,ConcurrentHashMap<String,ArrayList<QosForm>>> hhh=new ConcurrentHashMap<String,ConcurrentHashMap<String,ArrayList<QosForm>>>();
							for(String element:elementSet){
								if(element.equalsIgnoreCase(Constants.UCCX_INTERFACE)){
									ConcurrentHashMap<String,ArrayList<QosForm>> qosMap=new ConcurrentHashMap<String,ArrayList<QosForm>>();
									IndexElement idx=groupMap.get(element);
									if(idx != null){
										ArrayList<String> indexList=idx.getIndexList();
										ArrayList<String> desc=idx.getDescList();
										ArrayList<OidForm> oidFormList=idx.getOidFormList();
										for (int count = 0; count < indexList.size(); count++) {
											ArrayList<QosForm> qosFormList=new ArrayList<QosForm>();
											for (OidForm oidForm : oidFormList) {
												if (!oidForm.getOidName().equalsIgnoreCase(Constants.IF_INDEX) && !oidForm.getOidName().equalsIgnoreCase(Constants.IF_DESC)) {
													String qos="";
													VariableBinding variableBinding = SNMPUtils.poll(snmpCreditionals, oidForm.getOidValue() + "." + indexList.get(count));
													
													if(!oidForm.getOidName().equalsIgnoreCase(Constants.LAST_CHANGE)){  //For timetick
														 qos=variableBinding.getVariable().isException() ? Constants.ZERO : variableBinding.getVariable().toString();
													}else{
													 qos = variableBinding.getVariable().isException() ? Constants.ZERO : Long.toString(variableBinding.getVariable().toLong());
													}
													 String description=desc.get(count);
													String index= indexList.get(count);
													QosForm qosForm=getQosFormList(oidForm, qos, description,index);
													qosFormList.add(qosForm);
												}
											}
											qosMap.put(desc.get(count), qosFormList);
										}
									} 
									hhh.put(element, qosMap);
								}
							}
							pooledValueMap.put(group, hhh);
							long endTime = System.currentTimeMillis();
							 long totalTime = endTime - startTime;
							 Log.trace("Contact_center::Execution time for INTERFACE[" + totalTime + "]ms");
			                 Log.info("Contact_center::Execution time for INTERFACE[" + formatter.format((endTime - startTime) / 1000d) + "]seconds");

						}catch(Exception e){
							Log.error("Contact_Center Probe::Exception while Data collection for INTERFACE", e);
						}
					}
				},true);
				taskList.add(pollTask4);
				executor.execute(pollTask4);
			}
			if (group.equalsIgnoreCase(Constants.UCCE_INTERFACE)) {

				FutureTask<Boolean> pollTask5 = new FutureTask<Boolean>(new Runnable() {
					
					@Override
					public void run() {
						try {
							long startTime = System.currentTimeMillis();
							ConcurrentHashMap<String,IndexElement> groupMap=groupSetMap.get(group);
							Set<String> elementSet=groupMap.keySet();
							ConcurrentHashMap<String,ConcurrentHashMap<String,ArrayList<QosForm>>> hhh=new ConcurrentHashMap<String,ConcurrentHashMap<String,ArrayList<QosForm>>>();
							for(String element:elementSet){
								if(element.equalsIgnoreCase(Constants.UCCE_INTERFACE)){
									ConcurrentHashMap<String,ArrayList<QosForm>> qosMap=new ConcurrentHashMap<String,ArrayList<QosForm>>();
									IndexElement idx=groupMap.get(element);
									if(idx != null){
										ArrayList<String> indexList=idx.getIndexList();
										ArrayList<String> desc=idx.getDescList();
										ArrayList<OidForm> oidFormList=idx.getOidFormList();
										for (int count = 0; count < indexList.size(); count++) {
											ArrayList<QosForm> qosFormList=new ArrayList<QosForm>();
											for (OidForm oidForm : oidFormList) {
												if (!oidForm.getOidName().equalsIgnoreCase(Constants.IF_INDEX) && !oidForm.getOidName().equalsIgnoreCase(Constants.IF_DESC)) {
													String qos="";
													VariableBinding variableBinding = SNMPUtils.poll(snmpCreditionals, oidForm.getOidValue() + "." + indexList.get(count));
													
													if(!oidForm.getOidName().equalsIgnoreCase(Constants.LAST_CHANGE)){  //For timetick
														 qos=variableBinding.getVariable().isException() ? Constants.ZERO : variableBinding.getVariable().toString();
													}else{
													 qos = variableBinding.getVariable().isException() ? Constants.ZERO : Long.toString(variableBinding.getVariable().toLong());
													}
													 String description=desc.get(count);
													String index= indexList.get(count);
													QosForm qosForm=getQosFormList(oidForm, qos, description,index);
													qosFormList.add(qosForm);
												}
											}
											qosMap.put(desc.get(count), qosFormList);
										}
									} 
									hhh.put(element, qosMap);
								}
							}
							pooledValueMap.put(group, hhh);
							long endTime = System.currentTimeMillis();
							 long totalTime = endTime - startTime;
							 Log.trace("Contact_center::Execution time for INTERFACE[" + totalTime + "]ms");
			                 Log.info("Contact_center::Execution time for INTERFACE[" + formatter.format((endTime - startTime) / 1000d) + "]seconds");

						}catch(Exception e){
							Log.error("Contact_Center Probe::Exception while Data collection for INTERFACE", e);
						}
					}
				},true);
				taskList.add(pollTask5);
				executor.execute(pollTask5);
			}
			if (group.equalsIgnoreCase(Constants.GATEWAY_INFO)) {
				FutureTask<Boolean> pollTask6 = new FutureTask<Boolean>(new Runnable() {
					@Override
					public void run() {
						try {
							long startTime = System.currentTimeMillis();
							ConcurrentHashMap<String,IndexElement> groupMap=groupSetMap.get(group);
							Set<String> elementSet=groupMap.keySet();
							ConcurrentHashMap<String,ConcurrentHashMap<String,ArrayList<QosForm>>> hhh=new ConcurrentHashMap<String,ConcurrentHashMap<String,ArrayList<QosForm>>>();
							for(String element:elementSet){
								if(element.equalsIgnoreCase(Constants.GATEWAY_INFO)){
									ConcurrentHashMap<String,ArrayList<QosForm>> qosMap=new ConcurrentHashMap<String,ArrayList<QosForm>>();
									IndexElement idx=groupMap.get(element);
									if(idx != null){
										ArrayList<String> indexList=idx.getIndexList();
										ArrayList<String> desc=idx.getDescList();
										ArrayList<OidForm> oidFormList=idx.getOidFormList();
										for (int count = 0; count < indexList.size(); count++) {
											ArrayList<QosForm> qosFormList=new ArrayList<QosForm>();
											for (OidForm oidForm : oidFormList) {
												if (!oidForm.getOidName().equalsIgnoreCase(Constants.CCM_GATEWAY_NAME)) {
													VariableBinding variableBinding = SNMPUtils.poll(snmpCreditionals, oidForm.getOidValue() + "." + indexList.get(count));
													String qos="";
													if( oidForm != null  && oidForm.getElement()!="" && oidForm.getMetricName()!="" ){
														 qos=variableBinding.getVariable().isException() ? Constants.ZERO : variableBinding.getVariable().toString();
														
													}else{
														 qos=variableBinding.getVariable().isException() ? Constants.NOT_ACCESSIBLE : variableBinding.getVariable().toString();
														}
													String description=desc.get(count);
													String index= indexList.get(count);
													QosForm qosForm=getQosFormList(oidForm, qos, description,index);
													qosFormList.add(qosForm);
												}
											}
											qosMap.put(desc.get(count), qosFormList);
										}
									} 
									hhh.put(element, qosMap);
								}
							}
							pooledValueMap.put(group, hhh);
							long endTime = System.currentTimeMillis();
							 long totalTime = endTime - startTime;
							 Log.trace("Contact_center::Execution time for GATEWAY_INFO[" + totalTime + "]ms");
			                 Log.info("Contact_center::Execution time for GATEWAY_INFO[" + formatter.format((endTime - startTime) / 1000d) + "]seconds");

						}catch(Exception e){
							Log.error("Contact_Center Probe::Exception while Data collection for GATEWAY_INFO", e);
						}
					}
				},true);
				taskList.add(pollTask6);
				executor.execute(pollTask6);
			}
			if (group.equalsIgnoreCase(Constants.H323DEVICE)) {
				FutureTask<Boolean> pollTask7 = new FutureTask<Boolean>(new Runnable() {
					@Override
					public void run() {
						try {
							long startTime = System.currentTimeMillis();
							ConcurrentHashMap<String,IndexElement> groupMap=groupSetMap.get(group);
							Set<String> elementSet=groupMap.keySet();
							ConcurrentHashMap<String,ConcurrentHashMap<String,ArrayList<QosForm>>> hhh=new ConcurrentHashMap<String,ConcurrentHashMap<String,ArrayList<QosForm>>>();
							for(String element:elementSet){
								if(element.equalsIgnoreCase(Constants.H323DEVICE)){
									ConcurrentHashMap<String,ArrayList<QosForm>> qosMap=new ConcurrentHashMap<String,ArrayList<QosForm>>();
									IndexElement idx=groupMap.get(element);
									if(idx != null){
										ArrayList<String> indexList=idx.getIndexList();
										ArrayList<String> desc=idx.getDescList();
										ArrayList<OidForm> oidFormList=idx.getOidFormList();
										for (int count = 0; count < indexList.size(); count++) {
											ArrayList<QosForm> qosFormList=new ArrayList<QosForm>();
											for (OidForm oidForm : oidFormList) {
												if (!oidForm.getOidName().equalsIgnoreCase(Constants.H323DEVICE_NAME)) {
													VariableBinding variableBinding = SNMPUtils.poll(snmpCreditionals, oidForm.getOidValue() + "." + indexList.get(count));
													String qos=variableBinding.getVariable().isException() ? Constants.NOT_ACCESSIBLE : variableBinding.getVariable().toString();
													String description=desc.get(count);
													String index= indexList.get(count);
													QosForm qosForm=getQosFormList(oidForm, qos, description,index);
													qosFormList.add(qosForm);
												}
											}
											qosMap.put(desc.get(count), qosFormList);
										}
									} 
									hhh.put(element, qosMap);
								}
							}
							pooledValueMap.put(group, hhh);
							long endTime = System.currentTimeMillis();
							 long totalTime = endTime - startTime;
							 Log.trace("Contact_center::Execution time for H323DEVICE[" + totalTime + "]ms");
			                 Log.info("Contact_center::Execution time for H323DEVICE[" + formatter.format((endTime - startTime) / 1000d) + "]seconds");

						}catch(Exception e){
							Log.error("Contact_Center Probe::Exception while Data collection for H323DEVICE", e);
						}
					}
				},true);
				taskList.add(pollTask7);
				executor.execute(pollTask7);
			}if (group.equalsIgnoreCase(Constants.SYSTEM_PROPERTY)) {
				FutureTask<Boolean> pollTask8 = new FutureTask<Boolean>(new Runnable() {
					@Override
					public void run() {
						try {
							long startTime = System.currentTimeMillis();
							ConcurrentHashMap<String,IndexElement> groupMap=groupSetMap.get(group);
							Set<String> elementSet=groupMap.keySet();
							ConcurrentHashMap<String,ConcurrentHashMap<String,ArrayList<QosForm>>> hhh=new ConcurrentHashMap<String,ConcurrentHashMap<String,ArrayList<QosForm>>>();
							for(String element:elementSet){
								if(element.equalsIgnoreCase(Constants.SYSTEM_PROPERTY)){
									ConcurrentHashMap<String,ArrayList<QosForm>> qosMap=new ConcurrentHashMap<String,ArrayList<QosForm>>();
									IndexElement idx=groupMap.get(element);
									if(idx != null){
										ArrayList<String> indexList=idx.getIndexList();
										ArrayList<String> desc=idx.getDescList();
										ArrayList<OidForm> oidFormList=idx.getOidFormList();
										for (int count = 0; count < indexList.size(); count++) {
											ArrayList<QosForm> qosFormList=new ArrayList<QosForm>();
											for (OidForm oidForm : oidFormList) {
												VariableBinding variableBinding = SNMPUtils.poll(snmpCreditionals, oidForm.getOidValue());
												String qos=variableBinding.getVariable().isException() ? Constants.NOT_ACCESSIBLE : variableBinding.getVariable().toString();
												String description=desc.get(count);
												String index= indexList.get(count);
												QosForm qosForm=getQosFormList(oidForm, qos, description,index);
												qosFormList.add(qosForm);
											}
											qosMap.put(desc.get(count), qosFormList);
										}
									} 
									hhh.put(element, qosMap);
								}
							}
							pooledValueMap.put(group, hhh);
							long endTime = System.currentTimeMillis();
							 long totalTime = endTime - startTime;
							 Log.trace("Contact_center::Execution time for SYSTEM_PROPERTY[" + totalTime + "]ms");
			                 Log.info("Contact_center::Execution time for SYSTEM_PROPERTY[" + formatter.format((endTime - startTime) / 1000d) + "]seconds");
						}catch(Exception e){
							Log.error("Contact_Center Probe::Exception while Data collection for SYSTEM_PROPERTY", e);
						}
					}
				},true);
				taskList.add(pollTask8);
				executor.execute(pollTask8);
			}
			if (group.equalsIgnoreCase(Constants.HOST_RESOURCE)) {
				FutureTask<Boolean> pollTask9 = new FutureTask<Boolean>(new Runnable() {
					@Override
					public void run() {
						try {
							long startTime = System.currentTimeMillis();
							ConcurrentHashMap<String,IndexElement> groupMap=groupSetMap.get(group);
							Set<String> elementSet=groupMap.keySet();
							ConcurrentHashMap<String,ConcurrentHashMap<String,ArrayList<QosForm>>> hhh=new ConcurrentHashMap<String,ConcurrentHashMap<String,ArrayList<QosForm>>>();
							for(String element:elementSet){
								if(element.equalsIgnoreCase(Constants.PROCESSOR)){
									ConcurrentHashMap<String,ArrayList<QosForm>> qosMap=new ConcurrentHashMap<String,ArrayList<QosForm>>();
									IndexElement idx=groupMap.get(element);
									if(idx != null){
										ArrayList<String> indexList=idx.getIndexList();
										ArrayList<String> desc=idx.getDescList();
										ArrayList<OidForm> oidFormList=idx.getOidFormList();
										for (int count = 0; count < indexList.size(); count++) {
											ArrayList<QosForm> qosFormList=new ArrayList<QosForm>();
											for (OidForm oidForm : oidFormList) {
												VariableBinding variableBinding = SNMPUtils.poll(snmpCreditionals, oidForm.getOidValue() + "." + indexList.get(count));
												String qos=variableBinding.getVariable().isException() ? Constants.ZERO : variableBinding.getVariable().toString();
												String description=desc.get(count);
												String index= indexList.get(count);
												QosForm qosForm=getQosFormList(oidForm, qos, description,index);
												qosFormList.add(qosForm);
											}
											qosMap.put(desc.get(count), qosFormList);
										}
									} 
									hhh.put(element, qosMap);
								}
								if(element.equalsIgnoreCase(Constants.MEMORY)){
									ConcurrentHashMap<String,ArrayList<QosForm>> qosMap=new ConcurrentHashMap<String,ArrayList<QosForm>>();
									IndexElement idx=groupMap.get(element);
									if(idx != null){
										ArrayList<String> indexList=idx.getIndexList();
										ArrayList<String> desc=idx.getDescList();
										ArrayList<OidForm> oidFormList=idx.getOidFormList();
										for (int count = 0; count < indexList.size(); count++) {
											ArrayList<QosForm> qosFormList=new ArrayList<QosForm>();
											for (OidForm oidForm : oidFormList) {
												if (!oidForm.getOidName().equalsIgnoreCase(Constants.HR_STORAGE_INDEX) && !oidForm.getOidName().equalsIgnoreCase(Constants.HR_STORAGE_DESC)) {
													VariableBinding variableBinding = SNMPUtils.poll(snmpCreditionals, oidForm.getOidValue() + "." + indexList.get(count));
													String qos=variableBinding.getVariable().isException() ? Constants.ZERO: variableBinding.getVariable().toString();
													String description=desc.get(count);
													String index= indexList.get(count);
													QosForm qosForm=getQosFormList(oidForm, qos, description,index);
													qosFormList.add(qosForm);
												}
											}
											qosMap.put(desc.get(count), qosFormList);
										}
									} 
									hhh.put(element, qosMap);
								}
							}
							pooledValueMap.put(group, hhh);
							long endTime = System.currentTimeMillis();
							 long totalTime = endTime - startTime;
							 Log.trace("Contact_center::Execution time for HOST_RESOURCE[" + totalTime + "]ms");
			                 Log.info("Contact_center::Execution time for HOST_RESOURCE[" + formatter.format((endTime - startTime) / 1000d) + "]seconds");

						}catch(Exception e){
							Log.error("Contact_Center Probe::Exception while Data collection for HOST_RESOURCE", e);
						}
					}
				},true);
				taskList.add(pollTask9);
				executor.execute(pollTask9);
			}
			if (group.equalsIgnoreCase(Constants.UCCX_HOST_RESOURCE)) {
				FutureTask<Boolean> pollTask10 = new FutureTask<Boolean>(new Runnable() {
					@Override
					public void run() {
						try {
							long startTime = System.currentTimeMillis();
							ConcurrentHashMap<String,IndexElement> groupMap=groupSetMap.get(group);
							Set<String> elementSet=groupMap.keySet();
							ConcurrentHashMap<String,ConcurrentHashMap<String,ArrayList<QosForm>>> hhh=new ConcurrentHashMap<String,ConcurrentHashMap<String,ArrayList<QosForm>>>();
							for(String element:elementSet){
								if(element.equalsIgnoreCase(Constants.UCCX_PROCESSOR)){
									ConcurrentHashMap<String,ArrayList<QosForm>> qosMap=new ConcurrentHashMap<String,ArrayList<QosForm>>();
									IndexElement idx=groupMap.get(element);
									if(idx != null){
										ArrayList<String> indexList=idx.getIndexList();
										ArrayList<String> desc=idx.getDescList();
										ArrayList<OidForm> oidFormList=idx.getOidFormList();
										for (int count = 0; count < indexList.size(); count++) {
											ArrayList<QosForm> qosFormList=new ArrayList<QosForm>();
											for (OidForm oidForm : oidFormList) {
												VariableBinding variableBinding = SNMPUtils.poll(snmpCreditionals, oidForm.getOidValue() + "." + indexList.get(count));
												String qos=variableBinding.getVariable().isException() ? Constants.ZERO : variableBinding.getVariable().toString();
												String description=desc.get(count);
												String index= indexList.get(count);
												QosForm qosForm=getQosFormList(oidForm, qos, description,index);
												qosFormList.add(qosForm);
											}
											qosMap.put(desc.get(count), qosFormList);
										}
									} 
									hhh.put(element, qosMap);
								}
								if(element.equalsIgnoreCase(Constants.UCCX_MEMORY)){
									ConcurrentHashMap<String,ArrayList<QosForm>> qosMap=new ConcurrentHashMap<String,ArrayList<QosForm>>();
									IndexElement idx=groupMap.get(element);
									if(idx != null){
										ArrayList<String> indexList=idx.getIndexList();
										ArrayList<String> desc=idx.getDescList();
										ArrayList<OidForm> oidFormList=idx.getOidFormList();
										for (int count = 0; count < indexList.size(); count++) {
											ArrayList<QosForm> qosFormList=new ArrayList<QosForm>();
											for (OidForm oidForm : oidFormList) {
												if (!oidForm.getOidName().equalsIgnoreCase(Constants.HR_STORAGE_INDEX) && !oidForm.getOidName().equalsIgnoreCase(Constants.HR_STORAGE_DESC)) {
													VariableBinding variableBinding = SNMPUtils.poll(snmpCreditionals, oidForm.getOidValue() + "." + indexList.get(count));
													String qos=variableBinding.getVariable().isException() ? Constants.ZERO: variableBinding.getVariable().toString();
													String description=desc.get(count);
													String index= indexList.get(count);
													QosForm qosForm=getQosFormList(oidForm, qos, description,index);
													qosFormList.add(qosForm);
												}
											}
											qosMap.put(desc.get(count), qosFormList);
										}
									} 
									hhh.put(element, qosMap);
								}
							}
							pooledValueMap.put(group, hhh);
							long endTime = System.currentTimeMillis();
							 long totalTime = endTime - startTime;
							 Log.trace("Contact_center::Execution time for HOST_RESOURCE[" + totalTime + "]ms");
			                 Log.info("Contact_center::Execution time for HOST_RESOURCE[" + formatter.format((endTime - startTime) / 1000d) + "]seconds");

						}catch(Exception e){
							Log.error("Contact_Center Probe::Exception while Data collection for HOST_RESOURCE", e);
						}
					}
				},true);
				taskList.add(pollTask10);
				executor.execute(pollTask10);
			}
			if (group.equalsIgnoreCase(Constants.UCCE_HOST_RESOURCE)) {
				FutureTask<Boolean> pollTask11 = new FutureTask<Boolean>(new Runnable() {
					@Override
					public void run() {
						try {
							long startTime = System.currentTimeMillis();
							ConcurrentHashMap<String,IndexElement> groupMap=groupSetMap.get(group);
							Set<String> elementSet=groupMap.keySet();
							ConcurrentHashMap<String,ConcurrentHashMap<String,ArrayList<QosForm>>> hhh=new ConcurrentHashMap<String,ConcurrentHashMap<String,ArrayList<QosForm>>>();
							for(String element:elementSet){
								if(element.equalsIgnoreCase(Constants.UCCE_PROCESSOR)){
									ConcurrentHashMap<String,ArrayList<QosForm>> qosMap=new ConcurrentHashMap<String,ArrayList<QosForm>>();
									IndexElement idx=groupMap.get(element);
									if(idx != null){
										ArrayList<String> indexList=idx.getIndexList();
										ArrayList<String> desc=idx.getDescList();
										ArrayList<OidForm> oidFormList=idx.getOidFormList();
										for (int count = 0; count < indexList.size(); count++) {
											ArrayList<QosForm> qosFormList=new ArrayList<QosForm>();
											for (OidForm oidForm : oidFormList) {
												VariableBinding variableBinding = SNMPUtils.poll(snmpCreditionals, oidForm.getOidValue() + "." + indexList.get(count));
												String qos=variableBinding.getVariable().isException() ? Constants.ZERO : variableBinding.getVariable().toString();
												String description=desc.get(count);
												String index= indexList.get(count);
												QosForm qosForm=getQosFormList(oidForm, qos, description,index);
												qosFormList.add(qosForm);
											}
											qosMap.put(desc.get(count), qosFormList);
										}
									} 
									hhh.put(element, qosMap);
								}
								if(element.equalsIgnoreCase(Constants.UCCE_MEMORY)){
									ConcurrentHashMap<String,ArrayList<QosForm>> qosMap=new ConcurrentHashMap<String,ArrayList<QosForm>>();
									IndexElement idx=groupMap.get(element);
									if(idx != null){
										ArrayList<String> indexList=idx.getIndexList();
										ArrayList<String> desc=idx.getDescList();
										ArrayList<OidForm> oidFormList=idx.getOidFormList();
										for (int count = 0; count < indexList.size(); count++) {
											ArrayList<QosForm> qosFormList=new ArrayList<QosForm>();
											for (OidForm oidForm : oidFormList) {
												if (!oidForm.getOidName().equalsIgnoreCase(Constants.HR_STORAGE_INDEX) && !oidForm.getOidName().equalsIgnoreCase(Constants.HR_STORAGE_DESC)) {
													VariableBinding variableBinding = SNMPUtils.poll(snmpCreditionals, oidForm.getOidValue() + "." + indexList.get(count));
													String qos=variableBinding.getVariable().isException() ? Constants.ZERO: variableBinding.getVariable().toString();
													String description=desc.get(count);
													String index= indexList.get(count);
													QosForm qosForm=getQosFormList(oidForm, qos, description,index);
													qosFormList.add(qosForm);
												}
											}
											qosMap.put(desc.get(count), qosFormList);
										}
									} 
									hhh.put(element, qosMap);
								}
							}
							pooledValueMap.put(group, hhh);
							long endTime = System.currentTimeMillis();
							 long totalTime = endTime - startTime;
							 Log.trace("Contact_center::Execution time for HOST_RESOURCE[" + totalTime + "]ms");
			                 Log.info("Contact_center::Execution time for HOST_RESOURCE[" + formatter.format((endTime - startTime) / 1000d) + "]seconds");

						}catch(Exception e){
							Log.error("Contact_Center Probe::Exception while Data collection for HOST_RESOURCE", e);
						}
					}
				},true);
				taskList.add(pollTask11);
				executor.execute(pollTask11);
			}if (group.equalsIgnoreCase(Constants.CCM_PHONE_INFO_GROUP)) {
				FutureTask<Boolean> pollTask12 = new FutureTask<Boolean>(new Runnable() {
					@Override
					public void run() {
						try {
							long startTime = System.currentTimeMillis();
							ConcurrentHashMap<String,IndexElement> elementMap=groupSetMap.get(group); //elementMap
							Set<String> elementSet=elementMap.keySet();
							ConcurrentHashMap<String,ConcurrentHashMap<String,ArrayList<QosForm>>> elementQosMap=new ConcurrentHashMap<String,ConcurrentHashMap<String,ArrayList<QosForm>>>();
							for(String element:elementSet){
								if(element.equalsIgnoreCase(Constants.CCM_PHONE_INFO_ELEMENT)){
									ConcurrentHashMap<String,ArrayList<QosForm>> qosMap=new ConcurrentHashMap<String,ArrayList<QosForm>>();
									IndexElement indexElement=elementMap.get(element);
									if(indexElement != null){
										ArrayList<String> indexList=indexElement.getIndexList();
										ArrayList<String> desc=indexElement.getDescList();
										ArrayList<OidForm> oidFormList=indexElement.getOidFormList();
										for (int count = 0; count < indexList.size(); count++) {
											ArrayList<QosForm> qosFormList=new ArrayList<QosForm>();
											for (OidForm oidForm : oidFormList) {
												String qos=null;
												VariableBinding variableBinding = SNMPUtils.poll(snmpCreditionals, oidForm.getOidValue() + "." + indexList.get(count));
												if(oidForm!=null  && oidForm.getElement()!=""&&oidForm.getMetricName()!=""){
												 qos=variableBinding.getVariable().isException() ? Constants.ZERO : variableBinding.getVariable().toString();
												}else{
													qos=variableBinding.getVariable().isException() ? Constants.NOT_ACCESSIBLE : variableBinding.getVariable().toString();
												}
												String description=desc.get(count);
												String index= indexList.get(count);
												QosForm qosForm=getQosFormList(oidForm, qos, description,index);
												qosFormList.add(qosForm);

											}
											qosMap.put(desc.get(count), qosFormList);
										}
									} 
									elementQosMap.put(element, qosMap);
								}
							}
							pooledValueMap.put(group, elementQosMap);
							long endTime = System.currentTimeMillis();
							 long totalTime = endTime - startTime;
							 Log.trace("Contact_center::Execution time for CCM_PHONE_INFO_GROUP[" + totalTime + "]ms");
			                 Log.info("Contact_center::Execution time for CCM_PHONE_INFO_GROUP[" + formatter.format((endTime - startTime) / 1000d) + "]seconds");

						}catch(Exception e){
							Log.error("Contact_Center Probe::Exception while Data collection for CCM_PHONE_INFO_GROUP", e);
						}
					}

				},true);
				taskList.add(pollTask12);
				executor.execute(pollTask12);
			}
			if (group.equalsIgnoreCase(Constants.CCM_GLOBAL_INFO_GROUP)) {
				FutureTask<Boolean> pollTask13 = new FutureTask<Boolean>(new Runnable() {
					@Override
					public void run() {
						try {
							long startTime = System.currentTimeMillis();
							ConcurrentHashMap<String,IndexElement> groupMap=groupSetMap.get(group);
							Set<String> elementSet=groupMap.keySet();
							ConcurrentHashMap<String,ConcurrentHashMap<String,ArrayList<QosForm>>> elementQosMap=new ConcurrentHashMap<String,ConcurrentHashMap<String,ArrayList<QosForm>>>();
							for(String element:elementSet){
								if(element.equalsIgnoreCase(Constants.CCM_GLOBAL_INFO_ELEMENT)){
									ConcurrentHashMap<String,ArrayList<QosForm>> qosMap=new ConcurrentHashMap<String,ArrayList<QosForm>>();
									IndexElement idx=groupMap.get(element);
									if(idx != null){
									ArrayList<String> indexList=idx.getIndexList();
									ArrayList<String> descList=idx.getDescList();
									ArrayList<OidForm> oidFormList=idx.getOidFormList();
									ArrayList<QosForm> qosFormList=new ArrayList<QosForm>();
									try{
									for (int count = 0; count < oidFormList.size(); count++) {   //only scaler
										VariableBinding variableBinding = SNMPUtils.poll(snmpCreditionals, oidFormList.get(count).getOidValue());
										String qos=null;
										if(oidFormList.get(count)!=null  && oidFormList.get(count).getElement()!=""&&oidFormList.get(count).getMetricName()!=""){
											 qos=variableBinding.getVariable().isException() ? Constants.ZERO : variableBinding.getVariable().toString();
										}else{
											 qos=variableBinding.getVariable().isException() ? Constants.NOT_ACCESSIBLE : variableBinding.getVariable().toString();
											}
										
										String description=descList.get(count);
										String index= indexList.get(count);
										QosForm qosForm=getQosFormList(oidFormList.get(count), qos, description,index);
										qosFormList.add(qosForm);
										}
										qosMap.put(descList.get(0), qosFormList);  //only one Description All are scaler values under single Folder
										
									}catch(Exception e){
										Log.info("####Excption:"+e);
									}
									
									} 
									elementQosMap.put(element, qosMap);
								}
							}
							pooledValueMap.put(group, elementQosMap);
							long endTime = System.currentTimeMillis();
							 long totalTime = endTime - startTime;
							 Log.trace("Contact_center::Execution time for CCM_PHONE_INFO_GROUP[" + totalTime + "]ms");
			                 Log.info("Contact_center::Execution time for CCM_PHONE_INFO_GROUP[" + formatter.format((endTime - startTime) / 1000d) + "]seconds");
							
						}catch(Exception e){
							Log.error("Contact_Center Probe::Exception while Data collection for CCM_GLOBAL_INFO_GROUP", e);
						}
					}

				},true);
				taskList.add(pollTask13);
				executor.execute(pollTask13);
			
			}if (group.equalsIgnoreCase(Constants.CUCM_GROUP)) {
				FutureTask<Boolean> pollTask14 = new FutureTask<Boolean>(new Runnable() {
					@Override
					public void run() {
						try {
							ConcurrentHashMap<String,IndexElement> elementMap=groupSetMap.get(group); //elementMap
							Set<String> elementSet=elementMap.keySet();
							ConcurrentHashMap<String,ConcurrentHashMap<String,ArrayList<QosForm>>> elementQosMap=new ConcurrentHashMap<String,ConcurrentHashMap<String,ArrayList<QosForm>>>();
							for(String element:elementSet){
								if(element.equalsIgnoreCase(Constants.CUCM_ELEMENT_1)){
									ConcurrentHashMap<String,ArrayList<QosForm>> qosMap=new ConcurrentHashMap<String,ArrayList<QosForm>>();
									IndexElement indexElement=elementMap.get(element);
									if(indexElement != null){
									ArrayList<String> indexList=indexElement.getIndexList();
									ArrayList<String> desc=indexElement.getDescList();
									Log.info("########################Size desc= "+desc.size());
									Log.info("########################Size indexList= "+indexList.size());
									ArrayList<OidForm> oidFormList=indexElement.getOidFormList();
									for (int count = 0; count < indexList.size(); count++) {
										ArrayList<QosForm> qosFormList=new ArrayList<QosForm>();
										for (OidForm oidForm : oidFormList) {
											String qos=null;
											VariableBinding variableBinding = SNMPUtils.poll(snmpCreditionals, oidForm.getOidValue() + "." + indexList.get(count));
											
											if(oidForm!=null  && oidForm.getElement()!=""&&oidForm.getMetricName()!=""){
			                                    qos=variableBinding.getVariable().isException() ? Constants.ZERO : variableBinding.getVariable().toString();
			                                    }else{
			                                           qos=variableBinding.getVariable().isException() ? Constants.NOT_ACCESSIBLE : variableBinding.getVariable().toString();
			                                    }
											Log.info("########################count= "+count);
											String description=desc.get(count);
											String index= indexList.get(count);
											QosForm qosForm=getQosFormList(oidForm, qos, description,index);
											qosFormList.add(qosForm);
											
										}
										qosMap.put(desc.get(count), qosFormList);
									}
									} 
									elementQosMap.put(element, qosMap);
								}if(element.equalsIgnoreCase(Constants.CUCM_ELEMENT_2)){
									ConcurrentHashMap<String,ArrayList<QosForm>> qosMap=new ConcurrentHashMap<String,ArrayList<QosForm>>();
									IndexElement indexElement=elementMap.get(element);
									if(indexElement != null){
									ArrayList<String> indexList=indexElement.getIndexList();
									ArrayList<String> desc=indexElement.getDescList();
									ArrayList<OidForm> oidFormList=indexElement.getOidFormList();
									for (int count = 0; count < indexList.size(); count++) {
										ArrayList<QosForm> qosFormList=new ArrayList<QosForm>();
										for (OidForm oidForm : oidFormList) {
											String qos=null;
											VariableBinding variableBinding = SNMPUtils.poll(snmpCreditionals, oidForm.getOidValue() + "." + indexList.get(count));
											
											if(oidForm!=null  && oidForm.getElement()!=""&&oidForm.getMetricName()!=""){
			                                    qos=variableBinding.getVariable().isException() ? Constants.ZERO : variableBinding.getVariable().toString();
			                                    }else{
			                                           qos=variableBinding.getVariable().isException() ? Constants.NOT_ACCESSIBLE : variableBinding.getVariable().toString();
			                                    }
											String description=desc.get(count);
											String index= indexList.get(count);
											QosForm qosForm=getQosFormList(oidForm, qos, description,index);
											qosFormList.add(qosForm);
											
										}
										qosMap.put(desc.get(count), qosFormList);
									}
									} 
									elementQosMap.put(element, qosMap);
								}
							}
							pooledValueMap.put(group, elementQosMap);
						
						}catch (Exception e) {
							Log.error("Contact_Center Probe::Exception while Data collection for CUCM_GROUP", e);
						}
						}},true);
				taskList.add(pollTask14);
				executor.execute(pollTask14);
			}if (group.equalsIgnoreCase(Constants.CCM_GATEWAY_TRUNK_GROUP)) {
				FutureTask<Boolean> pollTask15 = new FutureTask<Boolean>(new Runnable() {
					@Override
					public void run() {
						try {

							ConcurrentHashMap<String,IndexElement> elementMap=groupSetMap.get(group); //elementMap
							Set<String> elementSet=elementMap.keySet();
							ConcurrentHashMap<String,ConcurrentHashMap<String,ArrayList<QosForm>>> elementQosMap=new ConcurrentHashMap<String,ConcurrentHashMap<String,ArrayList<QosForm>>>();
							for(String element:elementSet){
								if(element.equalsIgnoreCase(Constants.CCM_GATEWAY_TRUNK_ELEMENT)){
									ConcurrentHashMap<String,ArrayList<QosForm>> qosMap=new ConcurrentHashMap<String,ArrayList<QosForm>>();
									IndexElement indexElement=elementMap.get(element);
									if(indexElement != null){
									ArrayList<String> indexList=indexElement.getIndexList();
									ArrayList<String> desc=indexElement.getDescList();
									ArrayList<OidForm> oidFormList=indexElement.getOidFormList();
									for (int count = 0; count < indexList.size(); count++) {
										ArrayList<QosForm> qosFormList=new ArrayList<QosForm>();
										for (OidForm oidForm : oidFormList) {
											String qos=null;
											VariableBinding variableBinding = SNMPUtils.poll(snmpCreditionals, oidForm.getOidValue() + "." + indexList.get(count));
											
											if(oidForm!=null  && oidForm.getElement()!=""&&oidForm.getMetricName()!=""){
			                                    qos=variableBinding.getVariable().isException() ? Constants.ZERO : variableBinding.getVariable().toString();
			                                    }else{
			                                           qos=variableBinding.getVariable().isException() ? Constants.NOT_ACCESSIBLE : variableBinding.getVariable().toString();
			                                    }
											String description=desc.get(count);
											String index= indexList.get(count);
											QosForm qosForm=getQosFormList(oidForm, qos, description,index);
											qosFormList.add(qosForm);
											
										}
										qosMap.put(desc.get(count), qosFormList);
									}
									} 
									elementQosMap.put(element, qosMap);
								}
							}
							pooledValueMap.put(group, elementQosMap);
						
						}catch (Exception e) {
							Log.error("Contact_Center Probe::Exception while Data collection for CCM_GATEWAY_TRUNK_GROUP", e);
						}
						}},true);
				taskList.add(pollTask15);
				executor.execute(pollTask15);
			}if (group.equalsIgnoreCase(Constants.CCCA_GENERAL_INFO_GROUP)) {
				FutureTask<Boolean> pollTask16 = new FutureTask<Boolean>(new Runnable() {
					@Override
					public void run() {
						try {
							long startTime = System.currentTimeMillis();
							ConcurrentHashMap<String,IndexElement> elementMap=groupSetMap.get(group);
							Set<String> elementSet=elementMap.keySet();
							ConcurrentHashMap<String,ConcurrentHashMap<String,ArrayList<QosForm>>> groupElementQosMap=new ConcurrentHashMap<String,ConcurrentHashMap<String,ArrayList<QosForm>>>();
							for(String element:elementSet){
								if(element.equalsIgnoreCase(Constants.CCCA_GENERAL_INFO_ELEMENT)){
									ConcurrentHashMap<String,ArrayList<QosForm>> qosMap=new ConcurrentHashMap<String,ArrayList<QosForm>>();
									IndexElement idx=elementMap.get(element);
									if(idx != null){
									ArrayList<String> indexList=idx.getIndexList();
									ArrayList<String> descList=idx.getDescList();
									ArrayList<OidForm> oidFormList=idx.getOidFormList();
									ArrayList<QosForm> qosFormList=new ArrayList<QosForm>();
									try{
									for (int count = 0; count < oidFormList.size(); count++) {   //only scaler
										VariableBinding variableBinding = SNMPUtils.poll(snmpCreditionals, oidFormList.get(count).getOidValue());
										String qos=null;
										if(oidFormList.get(count)!=null  && oidFormList.get(count).getElement()!=""&&oidFormList.get(count).getMetricName()!=""){
											 qos=variableBinding.getVariable().isException() ? Constants.ZERO : variableBinding.getVariable().toString();
										}else{
											 qos=variableBinding.getVariable().isException() ? Constants.NOT_ACCESSIBLE : variableBinding.getVariable().toString();
											}
										
										String description=descList.get(count);
										String index= indexList.get(count);
										QosForm qosForm=getQosFormList(oidFormList.get(count), qos, description,index);
										qosFormList.add(qosForm);
										}
										qosMap.put(descList.get(0), qosFormList);  //only one Description All are scaler values under single Folder
										
									}catch(Exception e){
										Log.info("####Excption:"+e);
									}
									
									} 
									groupElementQosMap.put(element, qosMap);
								}
							}
							pooledValueMap.put(group, groupElementQosMap);
							long endTime = System.currentTimeMillis();
							 long totalTime = endTime - startTime;
							 Log.trace("Contact_center::Execution time for CCM_PHONE_INFO_GROUP[" + totalTime + "]ms");
			                 Log.info("Contact_center::Execution time for CCM_PHONE_INFO_GROUP[" + formatter.format((endTime - startTime) / 1000d) + "]seconds");
							
						}catch(Exception e){
							Log.error("Contact_Center Probe::Exception while Data collection for CCM_GLOBAL_INFO_GROUP", e);
						}
					}

				},true);
				taskList.add(pollTask16);
				executor.execute(pollTask16);
			
			}if (group.equalsIgnoreCase(Constants.CCCA_INSTANCE_TABLE_GROUP)) {
				FutureTask<Boolean> pollTask17 = new FutureTask<Boolean>(new Runnable() {
					@Override
					public void run() {
						try {
							long startTime = System.currentTimeMillis();
							ConcurrentHashMap<String,IndexElement> groupMap=groupSetMap.get(group);
							Set<String> elementSet=groupMap.keySet();
							ConcurrentHashMap<String,ConcurrentHashMap<String,ArrayList<QosForm>>> hhh=new ConcurrentHashMap<String,ConcurrentHashMap<String,ArrayList<QosForm>>>();
							for(String element:elementSet){
								if(element.equalsIgnoreCase(Constants.CCCA_INSTANCE_TABLE_ELEMENT)){
									ConcurrentHashMap<String,ArrayList<QosForm>> qosMap=new ConcurrentHashMap<String,ArrayList<QosForm>>();
									IndexElement idx=groupMap.get(element);
									if(idx != null){
										ArrayList<String> indexList=idx.getIndexList();
										ArrayList<String> desc=idx.getDescList();
										ArrayList<OidForm> oidFormList=idx.getOidFormList();
										for (int count = 0; count < indexList.size(); count++) {
											ArrayList<QosForm> qosFormList=new ArrayList<QosForm>();
											for (OidForm oidForm : oidFormList) {  //only single OID to poll and we made des. and qos same.
												//if (!oidForm.getOidName().equalsIgnoreCase(Constants.CCCA_INSTANCE_NAME)) {
													//VariableBinding variableBinding = SNMPUtils.poll(snmpCreditionals, oidForm.getOidValue() + "." + indexList.get(count));
													//String qos=variableBinding.getVariable().isException() ? Constants.NOT_ACCESSIBLE : variableBinding.getVariable().toString();
													String qos=	desc.get(count);
													String description=desc.get(count);
													String index= indexList.get(count);
													QosForm qosForm=getQosFormList(oidForm, qos, description,index);
													qosFormList.add(qosForm);
												//}
											}
											qosMap.put(desc.get(count), qosFormList);
										}
									} 
									hhh.put(element, qosMap);
								}
							}
							pooledValueMap.put(group, hhh);
							long endTime = System.currentTimeMillis();
							 long totalTime = endTime - startTime;
							 Log.trace("Contact_center::Execution time for H323DEVICE[" + totalTime + "]ms");
			                 Log.info("Contact_center::Execution time for H323DEVICE[" + formatter.format((endTime - startTime) / 1000d) + "]seconds");

						}catch(Exception e){
							Log.error("Contact_Center Probe::Exception while Data collection for H323DEVICE", e);
						}
					}
				},true);
				taskList.add(pollTask17);
				executor.execute(pollTask17);
			}if (group.equalsIgnoreCase(Constants.CCCA_COMPONENT_TABLE_GROUP)) {
				FutureTask<Boolean> pollTask18 = new FutureTask<Boolean>(new Runnable() {
					@Override
					public void run() {
						try {
							long startTime = System.currentTimeMillis();
							ConcurrentHashMap<String,IndexElement> groupMap=groupSetMap.get(group);
							Set<String> elementSet=groupMap.keySet();
							ConcurrentHashMap<String,ConcurrentHashMap<String,ArrayList<QosForm>>> hhh=new ConcurrentHashMap<String,ConcurrentHashMap<String,ArrayList<QosForm>>>();
							for(String element:elementSet){
								if(element.equalsIgnoreCase(Constants.CCCA_COMPONENT_TABLE_ELEMENT)){
									ConcurrentHashMap<String,ArrayList<QosForm>> qosMap=new ConcurrentHashMap<String,ArrayList<QosForm>>();
									IndexElement idx=groupMap.get(element);
									if(idx != null){
										ArrayList<String> indexList=idx.getIndexList();
										ArrayList<String> desc=idx.getDescList();
										ArrayList<OidForm> oidFormList=idx.getOidFormList();
										for (int count = 0; count < indexList.size(); count++) {
											ArrayList<QosForm> qosFormList=new ArrayList<QosForm>();
											for (OidForm oidForm : oidFormList) {
												if(oidForm!=null&&!oidForm.getOidName().equalsIgnoreCase(Constants.CCCA_COMPONENT_NAME)){
													String qos=null;
													Log.info("################# index="+indexList.get(count));
													VariableBinding variableBinding = SNMPUtils.poll(snmpCreditionals, oidForm.getOidValue() + "." + indexList.get(count));
													if(oidForm.getElement()!=""&&oidForm.getMetricName()!=""){
				                                    qos=variableBinding.getVariable().isException() ? Constants.ZERO : variableBinding.getVariable().toString();
				                                    }else{
				                                    	qos=variableBinding.getVariable().isException() ? Constants.NOT_ACCESSIBLE : variableBinding.getVariable().toString();
				                                    }
													String description=desc.get(count);
													String index= indexList.get(count);
													QosForm qosForm=getQosFormList(oidForm, qos, description,index);
													qosFormList.add(qosForm);
												}
											}
											qosMap.put(desc.get(count), qosFormList);
										}
									} 
									hhh.put(element, qosMap);
								}
							}
							pooledValueMap.put(group, hhh);
							long endTime = System.currentTimeMillis();
							 long totalTime = endTime - startTime;
							 Log.trace("Contact_center::Execution time for H323DEVICE[" + totalTime + "]ms");
			                 Log.info("Contact_center::Execution time for H323DEVICE[" + formatter.format((endTime - startTime) / 1000d) + "]seconds");

						}catch(Exception e){
							Log.error("Contact_Center Probe::Exception while Data collection for H323DEVICE", e);
						}
					}
				},true);
				taskList.add(pollTask18);
				executor.execute(pollTask18);
			}if (group.equalsIgnoreCase(Constants.CCCA_ROUTER_TABLE_GROUP)) {
				FutureTask<Boolean> pollTask19 = new FutureTask<Boolean>(new Runnable() {
					@Override
					public void run() {
						try {
							long startTime = System.currentTimeMillis();
							ConcurrentHashMap<String,IndexElement> groupMap=groupSetMap.get(group);
							Set<String> elementSet=groupMap.keySet();
							ConcurrentHashMap<String,ConcurrentHashMap<String,ArrayList<QosForm>>> hhh=new ConcurrentHashMap<String,ConcurrentHashMap<String,ArrayList<QosForm>>>();
							for(String element:elementSet){
								if(element.equalsIgnoreCase(Constants.CCCA_ROUTER_TABLE_ELEMENT)){
									ConcurrentHashMap<String,ArrayList<QosForm>> qosMap=new ConcurrentHashMap<String,ArrayList<QosForm>>();
									IndexElement idx=groupMap.get(element);
									if(idx != null){
										ArrayList<String> indexList=idx.getIndexList();
										ArrayList<String> desc=idx.getDescList();
										ArrayList<OidForm> oidFormList=idx.getOidFormList();
										for (int count = 0; count < indexList.size(); count++) {
											ArrayList<QosForm> qosFormList=new ArrayList<QosForm>();
											for (OidForm oidForm : oidFormList) {
												//if(oidForm!=null&&!oidForm.getOidName().equalsIgnoreCase(Constants.CCCA_COMPONENT_NAME)){
													String qos=null;
													Log.info("################# index="+indexList.get(count));
													VariableBinding variableBinding = SNMPUtils.poll(snmpCreditionals, oidForm.getOidValue() + "." + indexList.get(count));
													if(oidForm.getElement()!=""&&oidForm.getMetricName()!=""){
				                                    qos=variableBinding.getVariable().isException() ? Constants.ZERO : variableBinding.getVariable().toString();
				                                    }else{
				                                    	qos=variableBinding.getVariable().isException() ? Constants.NOT_ACCESSIBLE : variableBinding.getVariable().toString();
				                                    }
													String description=desc.get(count);
													String index= indexList.get(count);
													QosForm qosForm=getQosFormList(oidForm, qos, description,index);
													qosFormList.add(qosForm);
												//}
											}
											qosMap.put(desc.get(count), qosFormList);
										}
									} 
									hhh.put(element, qosMap);
								}
							}
							pooledValueMap.put(group, hhh);
							long endTime = System.currentTimeMillis();
							 long totalTime = endTime - startTime;
							 Log.trace("Contact_center::Execution time for H323DEVICE[" + totalTime + "]ms");
			                 Log.info("Contact_center::Execution time for H323DEVICE[" + formatter.format((endTime - startTime) / 1000d) + "]seconds");

						}catch(Exception e){
							Log.error("Contact_Center Probe::Exception while Data collection for H323DEVICE", e);
						}
					}
				},true);
				taskList.add(pollTask19);
				executor.execute(pollTask19);
			}if (group.equalsIgnoreCase(Constants.CCCA_LOGGER_TABLE_GROUP)) {
				FutureTask<Boolean> pollTask20 = new FutureTask<Boolean>(new Runnable() {
					@Override
					public void run() {
						try {
							long startTime = System.currentTimeMillis();
							ConcurrentHashMap<String,IndexElement> groupMap=groupSetMap.get(group);
							Set<String> elementSet=groupMap.keySet();
							ConcurrentHashMap<String,ConcurrentHashMap<String,ArrayList<QosForm>>> hhh=new ConcurrentHashMap<String,ConcurrentHashMap<String,ArrayList<QosForm>>>();
							for(String element:elementSet){
								if(element.equalsIgnoreCase(Constants.CCCA_LOGGER_TABLE_ELEMENT)){
									ConcurrentHashMap<String,ArrayList<QosForm>> qosMap=new ConcurrentHashMap<String,ArrayList<QosForm>>();
									IndexElement idx=groupMap.get(element);
									if(idx != null){
										ArrayList<String> indexList=idx.getIndexList();
										ArrayList<String> desc=idx.getDescList();
										ArrayList<OidForm> oidFormList=idx.getOidFormList();
										for (int count = 0; count < indexList.size(); count++) {
											ArrayList<QosForm> qosFormList=new ArrayList<QosForm>();
											for (OidForm oidForm : oidFormList) {
												//if(oidForm!=null&&!oidForm.getOidName().equalsIgnoreCase(Constants.CCCA_COMPONENT_NAME)){
													String qos=null;
													Log.info("################# index="+indexList.get(count));
													VariableBinding variableBinding = SNMPUtils.poll(snmpCreditionals, oidForm.getOidValue() + "." + indexList.get(count));
													if(oidForm.getElement()!=""&&oidForm.getMetricName()!=""){
				                                    qos=variableBinding.getVariable().isException() ? Constants.ZERO : variableBinding.getVariable().toString();
				                                    }else{
				                                    	qos=variableBinding.getVariable().isException() ? Constants.NOT_ACCESSIBLE : variableBinding.getVariable().toString();
				                                    }
													String description=desc.get(count);
													String index= indexList.get(count);
													QosForm qosForm=getQosFormList(oidForm, qos, description,index);
													qosFormList.add(qosForm);
												//}
											}
											qosMap.put(desc.get(count), qosFormList);
										}
									} 
									hhh.put(element, qosMap);
								}
							}
							pooledValueMap.put(group, hhh);
							long endTime = System.currentTimeMillis();
							 long totalTime = endTime - startTime;
							 Log.trace("Contact_center::Execution time for H323DEVICE[" + totalTime + "]ms");
			                 Log.info("Contact_center::Execution time for H323DEVICE[" + formatter.format((endTime - startTime) / 1000d) + "]seconds");

						}catch(Exception e){
							Log.error("Contact_Center Probe::Exception while Data collection for H323DEVICE", e);
						}
					}
				},true);
				taskList.add(pollTask20);
				executor.execute(pollTask20);
			}if (group.equalsIgnoreCase(Constants.CCCA_DISTAW_TABLE_GROUP)) {
				FutureTask<Boolean> pollTask21 = new FutureTask<Boolean>(new Runnable() {
					@Override
					public void run() {
						try {
							long startTime = System.currentTimeMillis();
							ConcurrentHashMap<String,IndexElement> groupMap=groupSetMap.get(group);
							Set<String> elementSet=groupMap.keySet();
							ConcurrentHashMap<String,ConcurrentHashMap<String,ArrayList<QosForm>>> hhh=new ConcurrentHashMap<String,ConcurrentHashMap<String,ArrayList<QosForm>>>();
							for(String element:elementSet){
								if(element.equalsIgnoreCase(Constants.CCCA_DISTAW_TABLE_ELEMENT)){
									ConcurrentHashMap<String,ArrayList<QosForm>> qosMap=new ConcurrentHashMap<String,ArrayList<QosForm>>();
									IndexElement idx=groupMap.get(element);
									if(idx != null){
										ArrayList<String> indexList=idx.getIndexList();
										ArrayList<String> desc=idx.getDescList();
										ArrayList<OidForm> oidFormList=idx.getOidFormList();
										for (int count = 0; count < indexList.size(); count++) {
											ArrayList<QosForm> qosFormList=new ArrayList<QosForm>();
											for (OidForm oidForm : oidFormList) {
												//if(oidForm!=null&&!oidForm.getOidName().equalsIgnoreCase(Constants.CCCA_COMPONENT_NAME)){
													String qos=null;
													Log.info("################# index="+indexList.get(count));
													VariableBinding variableBinding = SNMPUtils.poll(snmpCreditionals, oidForm.getOidValue() + "." + indexList.get(count));
													if(oidForm.getElement()!=""&&oidForm.getMetricName()!=""){
				                                    qos=variableBinding.getVariable().isException() ? Constants.ZERO : variableBinding.getVariable().toString();
				                                    }else{
				                                    	qos=variableBinding.getVariable().isException() ? Constants.NOT_ACCESSIBLE : variableBinding.getVariable().toString();
				                                    }
													String description=desc.get(count);
													String index= indexList.get(count);
													QosForm qosForm=getQosFormList(oidForm, qos, description,index);
													qosFormList.add(qosForm);
												//}
											}
											qosMap.put(desc.get(count), qosFormList);
										}
									} 
									hhh.put(element, qosMap);
								}
							}
							pooledValueMap.put(group, hhh);
							long endTime = System.currentTimeMillis();
							 long totalTime = endTime - startTime;
							 Log.trace("Contact_center::Execution time for H323DEVICE[" + totalTime + "]ms");
			                 Log.info("Contact_center::Execution time for H323DEVICE[" + formatter.format((endTime - startTime) / 1000d) + "]seconds");

						}catch(Exception e){
							Log.error("Contact_Center Probe::Exception while Data collection for H323DEVICE", e);
						}
					}
				},true);
				taskList.add(pollTask21);
				executor.execute(pollTask21);
			}if (group.equalsIgnoreCase(Constants.CCCA_PG_TABLE_GROUP)) {
				FutureTask<Boolean> pollTask22 = new FutureTask<Boolean>(new Runnable() {
					@Override
					public void run() {
						try {
							long startTime = System.currentTimeMillis();
							ConcurrentHashMap<String,IndexElement> groupMap=groupSetMap.get(group);
							Set<String> elementSet=groupMap.keySet();
							ConcurrentHashMap<String,ConcurrentHashMap<String,ArrayList<QosForm>>> hhh=new ConcurrentHashMap<String,ConcurrentHashMap<String,ArrayList<QosForm>>>();
							for(String element:elementSet){
								if(element.equalsIgnoreCase(Constants.CCCA_PG_TABLE_ELEMENT)){
									ConcurrentHashMap<String,ArrayList<QosForm>> qosMap=new ConcurrentHashMap<String,ArrayList<QosForm>>();
									IndexElement idx=groupMap.get(element);
									if(idx != null){
										ArrayList<String> indexList=idx.getIndexList();
										ArrayList<String> desc=idx.getDescList();
										ArrayList<OidForm> oidFormList=idx.getOidFormList();
										for (int count = 0; count < indexList.size(); count++) {
											ArrayList<QosForm> qosFormList=new ArrayList<QosForm>();
											for (OidForm oidForm : oidFormList) {
												//if(oidForm!=null&&!oidForm.getOidName().equalsIgnoreCase(Constants.CCCA_COMPONENT_NAME)){
													String qos=null;
													Log.info("################# index="+indexList.get(count));
													VariableBinding variableBinding = SNMPUtils.poll(snmpCreditionals, oidForm.getOidValue() + "." + indexList.get(count));
													if(oidForm.getElement()!=""&&oidForm.getMetricName()!=""){
				                                    qos=variableBinding.getVariable().isException() ? Constants.ZERO : variableBinding.getVariable().toString();
				                                    }else{
				                                    	qos=variableBinding.getVariable().isException() ? Constants.NOT_ACCESSIBLE : variableBinding.getVariable().toString();
				                                    }
													String description=desc.get(count);
													String index= indexList.get(count);
													QosForm qosForm=getQosFormList(oidForm, qos, description,index);
													qosFormList.add(qosForm);
												//}
											}
											qosMap.put(desc.get(count), qosFormList);
										}
									} 
									hhh.put(element, qosMap);
								}
							}
							pooledValueMap.put(group, hhh);
							long endTime = System.currentTimeMillis();
							 long totalTime = endTime - startTime;
							 Log.trace("Contact_center::Execution time for H323DEVICE[" + totalTime + "]ms");
			                 Log.info("Contact_center::Execution time for H323DEVICE[" + formatter.format((endTime - startTime) / 1000d) + "]seconds");

						}catch(Exception e){
							Log.error("Contact_Center Probe::Exception while Data collection for H323DEVICE", e);
						}
					}
				},true);
				taskList.add(pollTask22);
				executor.execute(pollTask22);
			}if (group.equalsIgnoreCase(Constants.CCCA_PIM_TABLE_GROUP)) {
				FutureTask<Boolean> pollTask23 = new FutureTask<Boolean>(new Runnable() {
					@Override
					public void run() {
						try {
							long startTime = System.currentTimeMillis();
							ConcurrentHashMap<String,IndexElement> groupMap=groupSetMap.get(group);
							Set<String> elementSet=groupMap.keySet();
							ConcurrentHashMap<String,ConcurrentHashMap<String,ArrayList<QosForm>>> hhh=new ConcurrentHashMap<String,ConcurrentHashMap<String,ArrayList<QosForm>>>();
							for(String element:elementSet){
								if(element.equalsIgnoreCase(Constants.CCCA_PIM_TABLE_ELEMENT)){
									ConcurrentHashMap<String,ArrayList<QosForm>> qosMap=new ConcurrentHashMap<String,ArrayList<QosForm>>();
									IndexElement idx=groupMap.get(element);
									if(idx != null){
										ArrayList<String> indexList=idx.getIndexList();
										ArrayList<String> desc=idx.getDescList();
										ArrayList<OidForm> oidFormList=idx.getOidFormList();
										for (int count = 0; count < indexList.size(); count++) {
											ArrayList<QosForm> qosFormList=new ArrayList<QosForm>();
											for (OidForm oidForm : oidFormList) {
												if(oidForm!=null&&!oidForm.getOidName().equalsIgnoreCase(Constants.CCCA_PIM_PERIPHERAL_NAME)){
													String qos=null;
													Log.info("################# index="+indexList.get(count));
													VariableBinding variableBinding = SNMPUtils.poll(snmpCreditionals, oidForm.getOidValue() + "." + indexList.get(count));
													if(oidForm.getElement()!=""&&oidForm.getMetricName()!=""){
				                                    qos=variableBinding.getVariable().isException() ? Constants.ZERO : variableBinding.getVariable().toString();
				                                    }else{
				                                    	qos=variableBinding.getVariable().isException() ? Constants.NOT_ACCESSIBLE : variableBinding.getVariable().toString();
				                                    }
													String description=desc.get(count);
													String index= indexList.get(count);
													QosForm qosForm=getQosFormList(oidForm, qos, description,index);
													qosFormList.add(qosForm);
												}
											}
											qosMap.put(desc.get(count), qosFormList);
										}
									} 
									hhh.put(element, qosMap);
								}
							}
							pooledValueMap.put(group, hhh);
							long endTime = System.currentTimeMillis();
							 long totalTime = endTime - startTime;
							 Log.trace("Contact_center::Execution time for H323DEVICE[" + totalTime + "]ms");
			                 Log.info("Contact_center::Execution time for H323DEVICE[" + formatter.format((endTime - startTime) / 1000d) + "]seconds");

						}catch(Exception e){
							Log.error("Contact_Center Probe::Exception while Data collection for H323DEVICE", e);
						}
					}
				},true);
				taskList.add(pollTask23);
				executor.execute(pollTask23);
			}if (group.equalsIgnoreCase(Constants.CCCA_CG_TABLE_GROUP)) {
				FutureTask<Boolean> pollTask24 = new FutureTask<Boolean>(new Runnable() {
					@Override
					public void run() {
						try {
							long startTime = System.currentTimeMillis();
							ConcurrentHashMap<String,IndexElement> groupMap=groupSetMap.get(group);
							Set<String> elementSet=groupMap.keySet();
							ConcurrentHashMap<String,ConcurrentHashMap<String,ArrayList<QosForm>>> hhh=new ConcurrentHashMap<String,ConcurrentHashMap<String,ArrayList<QosForm>>>();
							for(String element:elementSet){
								if(element.equalsIgnoreCase(Constants.CCCA_CG_TABLE_ELEMENT)){
									ConcurrentHashMap<String,ArrayList<QosForm>> qosMap=new ConcurrentHashMap<String,ArrayList<QosForm>>();
									IndexElement idx=groupMap.get(element);
									if(idx != null){
										ArrayList<String> indexList=idx.getIndexList();
										ArrayList<String> desc=idx.getDescList();
										ArrayList<OidForm> oidFormList=idx.getOidFormList();
										for (int count = 0; count < indexList.size(); count++) {
											ArrayList<QosForm> qosFormList=new ArrayList<QosForm>();
											for (OidForm oidForm : oidFormList) {
												//if(oidForm!=null&&!oidForm.getOidName().equalsIgnoreCase(Constants.CCCA_PIM_PERIPHERAL_NAME)){
													String qos=null;
													Log.info("################# index="+indexList.get(count));
													VariableBinding variableBinding = SNMPUtils.poll(snmpCreditionals, oidForm.getOidValue() + "." + indexList.get(count));
													if(oidForm.getElement()!=""&&oidForm.getMetricName()!=""){
				                                    qos=variableBinding.getVariable().isException() ? Constants.ZERO : variableBinding.getVariable().toString();
				                                    }else{
				                                    	qos=variableBinding.getVariable().isException() ? Constants.NOT_ACCESSIBLE : variableBinding.getVariable().toString();
				                                    }
													String description=desc.get(count);
													String index= indexList.get(count);
													QosForm qosForm=getQosFormList(oidForm, qos, description,index);
													qosFormList.add(qosForm);
												//}
											}
											qosMap.put(desc.get(count), qosFormList);
										}
									} 
									hhh.put(element, qosMap);
								}
							}
							pooledValueMap.put(group, hhh);
							long endTime = System.currentTimeMillis();
							 long totalTime = endTime - startTime;
							 Log.trace("Contact_center::Execution time for H323DEVICE[" + totalTime + "]ms");
			                 Log.info("Contact_center::Execution time for H323DEVICE[" + formatter.format((endTime - startTime) / 1000d) + "]seconds");

						}catch(Exception e){
							Log.error("Contact_Center Probe::Exception while Data collection for H323DEVICE", e);
						}
					}
				},true);
				taskList.add(pollTask24);
				executor.execute(pollTask24);
			}
		}
		 Log.info("Contact_center Probe::Start to wait for Thread to gets completed");
	        // Wait until all results are available and combine them at the same time
	        for (int j = 0; j < taskList.size(); j++) {
	            Log.info("Contact_center :: Waiting for thread to get completed");
	            FutureTask<Boolean> futureTask = taskList.get(j);
	            try {
	                Log.info("Contact_center :: For the task[" + j + "]result is[" + futureTask.get() + "]");
	            } catch (ExecutionException | InterruptedException e) {
	                Log.fatal("Contact_center ::Exception encountered while waiting for thread to get completed", e);
	            }
	        }
	        executor.shutdownNow();
	        long endtime = System.currentTimeMillis();
			long total=endtime-starttime;
			 Log.info("Contact_center::Execution time for pollOid()=========== ["  +total+ "]ms");
		return pooledValueMap;
	}
	public static  QosForm getQosFormList(OidForm oidForm,String qos,String description,String index){
		QosForm qosForm=new QosForm();
		qosForm.setDescription(description);
		qosForm.setElement(oidForm.getElement());
		qosForm.setMetricName(oidForm.getMetricName());
		qosForm.setQos(qos);
		qosForm.setOidValue(oidForm.getOidValue());
		qosForm.setOidName(oidForm.getOidName());
		qosForm.setIndex(index);
		return qosForm;
	}
	public static MetricDef getMetricDef(String element, String metricName) {
		MetricDef metricDef = null;
		try {
			Class<?> elementClass = Class.forName(element);
			Field field = elementClass.getField(metricName);
			Object metric = field.get(metricDef);
			metricDef = (MetricDef) metric;
		} catch (ClassNotFoundException classNotFoundException) {
			Log.error("ClassNotFoundException in getUpdatedInventory: " + classNotFoundException.getMessage());
		} catch (NoSuchFieldException noSuchFieldException) {
			Log.error("NoSuchFieldException in getUpdatedInventory: " + noSuchFieldException.getMessage());
		} catch (IllegalAccessException illegalAccessException) {
			Log.error("IllegalAccessException in getUpdatedInventory: " + illegalAccessException.getMessage());
		}
		return metricDef;
	}
	public static ConcurrentHashMap<String,ConcurrentHashMap<String,IndexElement>> getOidIndexList(ConcurrentHashMap<String,ConcurrentHashMap<String, ArrayList<OidForm>>>	 oidListMap,final SnmpCreditionals snmpCreditionals){
		long starttime = System.currentTimeMillis();
		ExecutorService executor = Executors.newFixedThreadPool(10);
		List<FutureTask<Boolean>> taskList = new ArrayList<FutureTask<Boolean>>();
//		 final NumberFormat formatter = new DecimalFormat(Constants.DECIMAL_FORMAT);
		final ConcurrentHashMap<String,ConcurrentHashMap<String,IndexElement>> oidIndexMap=new ConcurrentHashMap<String,ConcurrentHashMap<String,IndexElement>>();
		final ConcurrentHashMap<String,ConcurrentHashMap<String, ArrayList<OidForm>>>	 oidListMap1=oidListMap;
		Set<String> groupSet=oidListMap1.keySet();
		for(final String group:groupSet){
			if (group.equalsIgnoreCase(Constants.INTERFACE)) {
				FutureTask<Boolean> pollTask1 = new FutureTask<Boolean>(new Runnable() {
					@Override
					public void run() {
						try {
							ConcurrentHashMap<String, ArrayList<OidForm>> groupList=oidListMap1.get(group);
							Set<String> elementSet = groupList.keySet();
							ConcurrentHashMap<String,IndexElement> indexMap=new ConcurrentHashMap<String,IndexElement>();
							for(String element:elementSet){
								 ArrayList<OidForm> oidFormList=groupList.get(element);
								if(element.equalsIgnoreCase(Constants.INTERFACE)){
									IndexElement indexElement=new IndexElement();
									ArrayList<String> indexList=new ArrayList<String>();
									ArrayList<String> descList=new ArrayList<String>();
									for (OidForm oidForm : oidFormList) {
										if (oidForm.getOidName().equalsIgnoreCase(Constants.IF_INDEX)) {
											Vector<? extends VariableBinding> indexVarBindList = SNMPUtils.getBulk(snmpCreditionals, oidForm.getOidValue());
											if(indexVarBindList != null){
											for (int count = 0; count < indexVarBindList.size(); count++) {
												indexList.add(indexVarBindList.get(count).getVariable().toString());
											}}
										} else if (oidForm.getOidName().equalsIgnoreCase(Constants.IF_DESC)) {
											Vector<? extends VariableBinding> descVarBindList = SNMPUtils.getBulk(snmpCreditionals, oidForm.getOidValue());
											if(descVarBindList != null){
											for (int count = 0; count < descVarBindList.size(); count++)
											{
												descList.add(descVarBindList.get(count).getVariable().toString());	
											}}
										}
									}
									indexElement.setDescList(descList);
									indexElement.setIndexList(indexList);
									indexElement.setOidFormList(oidFormList);
									indexMap.put(element,indexElement);
								}
							}
							oidIndexMap.put(group, indexMap);
						
							
						}catch (Exception e) {
							Log.error("Contact_Center Probe::Exception while Data collection for CCM_GLOBAL_INFO_GROUP", e);
						}
						}},true);
				taskList.add(pollTask1);
				executor.execute(pollTask1);
			}
			if (group.equalsIgnoreCase(Constants.UCCX_INTERFACE)) {
				FutureTask<Boolean> pollTask2 = new FutureTask<Boolean>(new Runnable() {
					@Override
					public void run() {
						try {
							ConcurrentHashMap<String, ArrayList<OidForm>> groupList=oidListMap1.get(group);
							Set<String> elementSet = groupList.keySet();
							ConcurrentHashMap<String,IndexElement> indexMap=new ConcurrentHashMap<String,IndexElement>();
							for(String element:elementSet){
								 ArrayList<OidForm> oidFormList=groupList.get(element);
								if(element.equalsIgnoreCase(Constants.UCCX_INTERFACE)){
									IndexElement indexElement=new IndexElement();
									ArrayList<String> indexList=new ArrayList<String>();
									ArrayList<String> descList=new ArrayList<String>();
									for (OidForm oidForm : oidFormList) {
										if (oidForm.getOidName().equalsIgnoreCase(Constants.IF_INDEX)) {
											Vector<? extends VariableBinding> indexVarBindList = SNMPUtils.getBulk(snmpCreditionals, oidForm.getOidValue());
											if(indexVarBindList != null){
											for (int count = 0; count < indexVarBindList.size(); count++) {
												indexList.add(indexVarBindList.get(count).getVariable().toString());
											}}
										} else if (oidForm.getOidName().equalsIgnoreCase(Constants.IF_DESC)) {
											Vector<? extends VariableBinding> descVarBindList = SNMPUtils.getBulk(snmpCreditionals, oidForm.getOidValue());
											if(descVarBindList != null){
											for (int count = 0; count < descVarBindList.size(); count++)
											{
												descList.add(descVarBindList.get(count).getVariable().toString());	
											}}
										}
									}
									indexElement.setDescList(descList);
									indexElement.setIndexList(indexList);
									indexElement.setOidFormList(oidFormList);
									indexMap.put(element,indexElement);
								}
							}
							oidIndexMap.put(group, indexMap);
						
							
						}catch (Exception e) {
							Log.error("Contact_Center Probe::Exception while Data collection for CCM_GLOBAL_INFO_GROUP", e);
						}
						}},true);
				taskList.add(pollTask2);
				executor.execute(pollTask2);
			}
			if (group.equalsIgnoreCase(Constants.UCCE_INTERFACE)) {
				FutureTask<Boolean> pollTask3 = new FutureTask<Boolean>(new Runnable() {
					@Override
					public void run() {
						try {
							ConcurrentHashMap<String, ArrayList<OidForm>> groupList=oidListMap1.get(group);
							Set<String> elementSet = groupList.keySet();
							ConcurrentHashMap<String,IndexElement> indexMap=new ConcurrentHashMap<String,IndexElement>();
							for(String element:elementSet){
								 ArrayList<OidForm> oidFormList=groupList.get(element);
								if(element.equalsIgnoreCase(Constants.UCCE_INTERFACE)){
									IndexElement indexElement=new IndexElement();
									ArrayList<String> indexList=new ArrayList<String>();
									ArrayList<String> descList=new ArrayList<String>();
									for (OidForm oidForm : oidFormList) {
										if (oidForm.getOidName().equalsIgnoreCase(Constants.IF_INDEX)) {
											Vector<? extends VariableBinding> indexVarBindList = SNMPUtils.getBulk(snmpCreditionals, oidForm.getOidValue());
											if(indexVarBindList != null){
											for (int count = 0; count < indexVarBindList.size(); count++) {
												indexList.add(indexVarBindList.get(count).getVariable().toString());
											}}
										} else if (oidForm.getOidName().equalsIgnoreCase(Constants.IF_DESC)) {
											Vector<? extends VariableBinding> descVarBindList = SNMPUtils.getBulk(snmpCreditionals, oidForm.getOidValue());
											if(descVarBindList != null){
											for (int count = 0; count < descVarBindList.size(); count++)
											{
												descList.add(descVarBindList.get(count).getVariable().toString());	
											}}
										}
									}
									indexElement.setDescList(descList);
									indexElement.setIndexList(indexList);
									indexElement.setOidFormList(oidFormList);
									indexMap.put(element,indexElement);
								}
							}
							oidIndexMap.put(group, indexMap);
						
							
						}catch (Exception e) {
							Log.error("Contact_Center Probe::Exception while Data collection for CCM_GLOBAL_INFO_GROUP", e);
						}
						}},true);
				taskList.add(pollTask3);
				executor.execute(pollTask3);
			}
			if (group.equalsIgnoreCase(Constants.SOFTWARE)) {
				FutureTask<Boolean> pollTask4 = new FutureTask<Boolean>(new Runnable() {
					@Override
					public void run() {
						try {
							ConcurrentHashMap<String, ArrayList<OidForm>> groupList=oidListMap1.get(group);
							Set<String> elementSet = groupList.keySet();
							ConcurrentHashMap<String,IndexElement> indexMap=new ConcurrentHashMap<String,IndexElement>();
							for(String element:elementSet){
								 ArrayList<OidForm> oidFormList=groupList.get(element);
								if(element.equalsIgnoreCase(Constants.SOFTWARE)){
									IndexElement indexElement=new IndexElement();
									ArrayList<String> index=new ArrayList<String>();
									ArrayList<String> desc=new ArrayList<String>();
									for (OidForm oidForm : oidFormList) {
										if (oidForm.getOidName().equalsIgnoreCase(Constants.HR_SW_RUNINDEX)) {
											Vector<? extends VariableBinding> indexVarBindList = SNMPUtils.getBulk(snmpCreditionals, oidForm.getOidValue());
											if(indexVarBindList != null){
											for (int count = 0; count < indexVarBindList.size(); count++) {
												index.add(indexVarBindList.get(count).getVariable().toString());
											}}
										} 
										if (oidForm.getOidName().equalsIgnoreCase(Constants.HR_SW_RUNNAME)) {
											Vector<? extends VariableBinding> descVarBindList = SNMPUtils.getBulk(snmpCreditionals, oidForm.getOidValue());
											if(descVarBindList != null){
											for (int count = 0; count < descVarBindList.size(); count++)
											{
											desc.add(descVarBindList.get(count).getVariable().toString());	
											}}
										}
									}
									indexElement.setDescList(desc);
									indexElement.setIndexList(index);
									indexElement.setOidFormList(oidFormList);
									indexMap.put(element, indexElement);
								}
							}
							oidIndexMap.put(group, indexMap);
						
							
						}catch (Exception e) {
							Log.error("Contact_Center Probe::Exception while Data collection for CCM_GLOBAL_INFO_GROUP", e);
						}
						}},true);
				taskList.add(pollTask4);
				executor.execute(pollTask4);
			}
			if (group.equalsIgnoreCase(Constants.UCCX_SOFTWARE)) {
				FutureTask<Boolean> pollTask5 = new FutureTask<Boolean>(new Runnable() {
					@Override
					public void run() {
						try {
							ConcurrentHashMap<String, ArrayList<OidForm>> groupList=oidListMap1.get(group);
							Set<String> elementSet = groupList.keySet();
							ConcurrentHashMap<String,IndexElement> indexMap=new ConcurrentHashMap<String,IndexElement>();
							for(String element:elementSet){
								 ArrayList<OidForm> oidFormList=groupList.get(element);
								if(element.equalsIgnoreCase(Constants.UCCX_SOFTWARE)){
									IndexElement indexElement=new IndexElement();
									ArrayList<String> index=new ArrayList<String>();
									ArrayList<String> desc=new ArrayList<String>();
									for (OidForm oidForm : oidFormList) {
										if (oidForm.getOidName().equalsIgnoreCase(Constants.HR_SW_RUNINDEX)) {
											Vector<? extends VariableBinding> indexVarBindList = SNMPUtils.getBulk(snmpCreditionals, oidForm.getOidValue());
											if(indexVarBindList != null){
											for (int count = 0; count < indexVarBindList.size(); count++) {
												index.add(indexVarBindList.get(count).getVariable().toString());
											}}
										} 
										if (oidForm.getOidName().equalsIgnoreCase(Constants.HR_SW_RUNNAME)) {
											Vector<? extends VariableBinding> descVarBindList = SNMPUtils.getBulk(snmpCreditionals, oidForm.getOidValue());
											if(descVarBindList != null){
											for (int count = 0; count < descVarBindList.size(); count++)
											{
											desc.add(descVarBindList.get(count).getVariable().toString());	
											}}
										}
									}
									indexElement.setDescList(desc);
									indexElement.setIndexList(index);
									indexElement.setOidFormList(oidFormList);
									indexMap.put(element, indexElement);
								}
							}
							oidIndexMap.put(group, indexMap);
						
							
						}catch (Exception e) {
							Log.error("Contact_Center Probe::Exception while Data collection for CCM_GLOBAL_INFO_GROUP", e);
						}
						}},true);
				taskList.add(pollTask5);
				executor.execute(pollTask5);
			}
			if (group.equalsIgnoreCase(Constants.UCCE_SOFTWARE)) {
				FutureTask<Boolean> pollTask6 = new FutureTask<Boolean>(new Runnable() {
					@Override
					public void run() {
						try {
							ConcurrentHashMap<String, ArrayList<OidForm>> groupList=oidListMap1.get(group);
							Set<String> elementSet = groupList.keySet();
							ConcurrentHashMap<String,IndexElement> indexMap=new ConcurrentHashMap<String,IndexElement>();
							for(String element:elementSet){
								 ArrayList<OidForm> oidFormList=groupList.get(element);
								if(element.equalsIgnoreCase(Constants.UCCE_SOFTWARE)){
									IndexElement indexElement=new IndexElement();
									ArrayList<String> index=new ArrayList<String>();
									ArrayList<String> desc=new ArrayList<String>();
									for (OidForm oidForm : oidFormList) {
										if (oidForm.getOidName().equalsIgnoreCase(Constants.HR_SW_RUNINDEX)) {
											Vector<? extends VariableBinding> indexVarBindList = SNMPUtils.getBulk(snmpCreditionals, oidForm.getOidValue());
											if(indexVarBindList != null){
											for (int count = 0; count < indexVarBindList.size(); count++) {
												index.add(indexVarBindList.get(count).getVariable().toString());
											}}
										} 
										if (oidForm.getOidName().equalsIgnoreCase(Constants.HR_SW_RUNNAME)) {
											Vector<? extends VariableBinding> descVarBindList = SNMPUtils.getBulk(snmpCreditionals, oidForm.getOidValue());
											if(descVarBindList != null){
											for (int count = 0; count < descVarBindList.size(); count++)
											{
											desc.add(descVarBindList.get(count).getVariable().toString());	
											}}
										}
									}
									indexElement.setDescList(desc);
									indexElement.setIndexList(index);
									indexElement.setOidFormList(oidFormList);
									indexMap.put(element, indexElement);
								}
							}
							oidIndexMap.put(group, indexMap);
						
							
						}catch (Exception e) {
							Log.error("Contact_Center Probe::Exception while Data collection for CCM_GLOBAL_INFO_GROUP", e);
						}
						}},true);
				taskList.add(pollTask6);
				executor.execute(pollTask6);
			}if (group.equalsIgnoreCase(Constants.CCM_PHONE_INFO_GROUP)) {
				FutureTask<Boolean> pollTask7 = new FutureTask<Boolean>(new Runnable() {
					@Override
					public void run() {
						try {
							ConcurrentHashMap<String, ArrayList<OidForm>> elementMap=oidListMap1.get(group);  //elementMap
							Set<String> elementSet = elementMap.keySet();
							ConcurrentHashMap<String,IndexElement> indexMap=new ConcurrentHashMap<String,IndexElement>();  //indexElementMap
							for(String element:elementSet){
								 ArrayList<OidForm> oidFormList=elementMap.get(element);
								if(element.equalsIgnoreCase(Constants.CCM_PHONE_INFO_ELEMENT)){
									IndexElement indexElement=new IndexElement();
									ArrayList<String> indexList=new ArrayList<String>();
									ArrayList<String> descList=new ArrayList<String>();
									Vector<? extends VariableBinding> phoneTypeVarBind = null;
									for (OidForm oidForm : oidFormList) {
										if (oidForm.getOidName().equalsIgnoreCase(Constants.CCM_PHONE_TYPE)) {
											phoneTypeVarBind = SNMPUtils.getBulk(snmpCreditionals, oidForm.getOidValue());
											if (phoneTypeVarBind != null && phoneTypeVarBind.size() != 0) {
												for (int count = 0; count < phoneTypeVarBind.size(); count++) {
													indexList.add(phoneTypeVarBind.get(count).getOid().toString().trim().substring(oidForm.getOidValue().trim().length()));
												}
											}
										}else if (oidForm.getOidName().equalsIgnoreCase(Constants.CCM_PHONE_IP_ADDRESS)) {
											Vector<? extends VariableBinding> descVarBindList = SNMPUtils.getBulk(snmpCreditionals, oidForm.getOidValue());
											for (int count = 0; count < indexList.size(); count++)
											{
												descList.add(descVarBindList.get(count).getVariable().toString());	
											}
										}
									}
									
									indexElement.setDescList(descList);
									indexElement.setIndexList(indexList);
									indexElement.setOidFormList(oidFormList);
									indexMap.put(Constants.CCM_PHONE_INFO_ELEMENT,indexElement);
								}
							}
							oidIndexMap.put(Constants.CCM_PHONE_INFO_GROUP, indexMap);
						}catch (Exception e) {
							Log.error("Contact_Center Probe::Exception while Data collection for CCM_GLOBAL_INFO_GROUP", e);
						}
						}},true);
				taskList.add(pollTask7);
				executor.execute(pollTask7);
			}
			if (group.equalsIgnoreCase(Constants.GATEWAY_INFO)) {
				FutureTask<Boolean> pollTask8 = new FutureTask<Boolean>(new Runnable() {
					@Override
					public void run() {
						try {
							ConcurrentHashMap<String, ArrayList<OidForm>> groupList=oidListMap1.get(group);
							Set<String> elementSet = groupList.keySet();
							ConcurrentHashMap<String,IndexElement> indexMap=new ConcurrentHashMap<String,IndexElement>();
							for(String element:elementSet){
								 ArrayList<OidForm> oidFormList=groupList.get(element);
								if(element.equalsIgnoreCase(Constants.GATEWAY_INFO)){
									IndexElement indexElement=new IndexElement();
									ArrayList<String> index=new ArrayList<String>();
									ArrayList<String> desc=new ArrayList<String>();
									for (OidForm oidForm : oidFormList) {
										if (oidForm.getOidName().equalsIgnoreCase(Constants.CCM_GATEWAY_NAME)) {
											Vector<? extends VariableBinding> descVarBindList = SNMPUtils.getBulk(snmpCreditionals, oidForm.getOidValue());
			                                    if (descVarBindList.size() != 0) {
												for (int count = 0; count < descVarBindList.size(); count++) {
													index.add(descVarBindList.get(count).getOid().toString().trim().substring(oidForm.getOidValue().trim().length()+1));
												}
												for (int count = 0; count < descVarBindList.size(); count++) {
													desc.add(descVarBindList.get(count).getVariable().toString());
												}
											}
										}
									}
									indexElement.setDescList(desc);
									indexElement.setIndexList(index);
									indexElement.setOidFormList(oidFormList);
									indexMap.put(element, indexElement);
								}
							}
							oidIndexMap.put(group, indexMap);
						}catch (Exception e) {
							Log.error("Contact_Center Probe::Exception while Data collection for CCM_GLOBAL_INFO_GROUP", e);
						}
						}},true);
				taskList.add(pollTask8);
				executor.execute(pollTask8);
			}
			if (group.equalsIgnoreCase(Constants.H323DEVICE)) {
				FutureTask<Boolean> pollTask9 = new FutureTask<Boolean>(new Runnable() {
					@Override
					public void run() {
						try {
							ConcurrentHashMap<String, ArrayList<OidForm>> groupList=oidListMap1.get(group);
							Set<String> elementSet = groupList.keySet();
							ConcurrentHashMap<String,IndexElement> indexMap=new ConcurrentHashMap<String,IndexElement>();
							for(String element:elementSet){
								 ArrayList<OidForm> oidFormList=groupList.get(element);
								if(element.equalsIgnoreCase(Constants.H323DEVICE)){
									IndexElement indexElement=new IndexElement();
									ArrayList<String> index=new ArrayList<String>();
									ArrayList<String> desc=new ArrayList<String>();
									for (OidForm oidForm : oidFormList) {
										if (oidForm.getOidName().equalsIgnoreCase(Constants.H323DEVICE_NAME)) {
											Vector<? extends VariableBinding> descVarBindList = SNMPUtils.getBulk(snmpCreditionals, oidForm.getOidValue());
			                                 if (descVarBindList.size() != 0) {
												for (int count = 0; count < descVarBindList.size(); count++) {
													index.add(descVarBindList.get(count).getOid().toString().trim().substring(oidForm.getOidValue().trim().length()+1));
												}
												for (int count = 0; count < descVarBindList.size(); count++) {
													desc.add(descVarBindList.get(count).getVariable().toString());
												}
											}
			                                indexElement.setDescList(desc);
			         						indexElement.setIndexList(index);
			         						indexElement.setOidFormList(oidFormList);   
										}
									}
									indexMap.put(element, indexElement);
								}
							}
							oidIndexMap.put(group, indexMap);
						
						}catch (Exception e) {
							Log.error("Contact_Center Probe::Exception while Data collection for CCM_GLOBAL_INFO_GROUP", e);
						}
						}},true);
				taskList.add(pollTask9);
				executor.execute(pollTask9);
			}if (group.equalsIgnoreCase(Constants.SYSTEM_PROPERTY)) {
				FutureTask<Boolean> pollTask10 = new FutureTask<Boolean>(new Runnable() {
					@Override
					public void run() {
						try {
							ConcurrentHashMap<String, ArrayList<OidForm>> groupList=oidListMap1.get(group);
							Set<String> elementSet = groupList.keySet();
							ConcurrentHashMap<String,IndexElement> indexMap=new ConcurrentHashMap<String,IndexElement>();
							for(String element:elementSet){
								 ArrayList<OidForm> oidFormList=groupList.get(element);
								if(element.equalsIgnoreCase(Constants.SYSTEM_PROPERTY)){
									IndexElement indexElement=new IndexElement();
									ArrayList<String> index=new ArrayList<String>();
									ArrayList<String> desc=new ArrayList<String>();
									index.add(Constants.SYSTEM_PROPERTY);
									desc.add(Constants.SYSTEM_PROPERTY);
									indexElement.setDescList(desc);
			 						indexElement.setIndexList(index);
			 						indexElement.setOidFormList(oidFormList);
									indexMap.put(element, indexElement);
								}
							}
							oidIndexMap.put(group, indexMap);
						}catch (Exception e) {
							Log.error("Contact_Center Probe::Exception while Data collection for CCM_GLOBAL_INFO_GROUP", e);
						}
						}},true);
				taskList.add(pollTask10);
				executor.execute(pollTask10);
			}
			if (group.equalsIgnoreCase(Constants.HOST_RESOURCE)) {
				FutureTask<Boolean> pollTask11 = new FutureTask<Boolean>(new Runnable() {
					@Override
					public void run() {
						try {

							ConcurrentHashMap<String, ArrayList<OidForm>> groupList=oidListMap1.get(group);
							Set<String> elementSet = groupList.keySet();
							ConcurrentHashMap<String,IndexElement> indexMap=new ConcurrentHashMap<String,IndexElement>();
							for(String element:elementSet){
								 ArrayList<OidForm> oidFormList=groupList.get(element);
								if(element.equalsIgnoreCase(Constants.PROCESSOR)){
									IndexElement indexElement=new IndexElement();
									ArrayList<String> index=new ArrayList<String>();
									ArrayList<String> desc=new ArrayList<String>();
									for (OidForm oidForm : oidFormList) {
										if (oidForm.getOidName().equalsIgnoreCase(Constants.HR_PROCESS_LOAD)) {
											Vector<? extends VariableBinding> indexVarBindList = SNMPUtils.getBulk(snmpCreditionals, oidForm.getOidValue());
											if(indexVarBindList != null){
											for (int count = 0; count < indexVarBindList.size(); count++) {
												index.add(indexVarBindList.get(count).getVariable().toString());
												desc.add("Processor: " + count);
											}
											}
										} 
									}
									indexElement.setDescList(desc);
									indexElement.setIndexList(index);
									indexElement.setOidFormList(oidFormList);
									indexMap.put(element, indexElement);
								}
								if(element.equalsIgnoreCase(Constants.MEMORY)){
									IndexElement indexElement=new IndexElement();
									ArrayList<String> index=new ArrayList<String>();
									ArrayList<String> desc=new ArrayList<String>();
									for (OidForm oidForm : oidFormList) {
										if (oidForm.getOidName().equalsIgnoreCase(Constants.HR_STORAGE_INDEX)) {
											Vector<? extends VariableBinding> indexVarBindList = SNMPUtils.getBulk(snmpCreditionals, oidForm.getOidValue());
											if(indexVarBindList != null){
											for (int count = 0; count < indexVarBindList.size(); count++) {
												index.add(indexVarBindList.get(count).getVariable().toString());
											}}
										} 
										if (oidForm.getOidName().equalsIgnoreCase(Constants.HR_STORAGE_DESC)) {
											Vector<? extends VariableBinding> descVarBindList = SNMPUtils.getBulk(snmpCreditionals, oidForm.getOidValue());
											if(descVarBindList != null){
											for (int count = 0; count < descVarBindList.size(); count++)
											{
											desc.add(descVarBindList.get(count).getVariable().toString());	
											}}
										}
									}
									indexElement.setDescList(desc);
									indexElement.setIndexList(index);
									indexElement.setOidFormList(oidFormList);
									indexMap.put(element, indexElement);
								}
							}
							oidIndexMap.put(group, indexMap);
							
						}catch (Exception e) {
							Log.error("Contact_Center Probe::Exception while Qos collection for HOST_RESOURCE", e);
						}
						}},true);
				taskList.add(pollTask11);
				executor.execute(pollTask11);
			}
			if (group.equalsIgnoreCase(Constants.UCCX_HOST_RESOURCE)) {
				FutureTask<Boolean> pollTask12 = new FutureTask<Boolean>(new Runnable() {
					@Override
					public void run() {
						try {
							ConcurrentHashMap<String, ArrayList<OidForm>> groupList=oidListMap1.get(group);
							Set<String> elementSet = groupList.keySet();
							ConcurrentHashMap<String,IndexElement> indexMap=new ConcurrentHashMap<String,IndexElement>();
							for(String element:elementSet){
								 ArrayList<OidForm> oidFormList=groupList.get(element);
								if(element.equalsIgnoreCase(Constants.UCCX_PROCESSOR)){
									IndexElement indexElement=new IndexElement();
									ArrayList<String> index=new ArrayList<String>();
									ArrayList<String> desc=new ArrayList<String>();
									for (OidForm oidForm : oidFormList) {
										if (oidForm.getOidName().equalsIgnoreCase(Constants.HR_PROCESS_LOAD)) {
											Vector<? extends VariableBinding> indexVarBindList = SNMPUtils.getBulk(snmpCreditionals, oidForm.getOidValue());
											if(indexVarBindList != null){
											for (int count = 0; count < indexVarBindList.size(); count++) {
												index.add(indexVarBindList.get(count).getVariable().toString());
												desc.add("Processor: " + count);
											}
											}
										} 
									}
									indexElement.setDescList(desc);
									indexElement.setIndexList(index);
									indexElement.setOidFormList(oidFormList);
									indexMap.put(element, indexElement);
								}
								if(element.equalsIgnoreCase(Constants.UCCX_MEMORY)){
									IndexElement indexElement=new IndexElement();
									ArrayList<String> index=new ArrayList<String>();
									ArrayList<String> desc=new ArrayList<String>();
									for (OidForm oidForm : oidFormList) {
										if (oidForm.getOidName().equalsIgnoreCase(Constants.HR_STORAGE_INDEX)) {
											Vector<? extends VariableBinding> indexVarBindList = SNMPUtils.getBulk(snmpCreditionals, oidForm.getOidValue());
											if(indexVarBindList != null){
											for (int count = 0; count < indexVarBindList.size(); count++) {
												index.add(indexVarBindList.get(count).getVariable().toString());
											}}
										} 
										if (oidForm.getOidName().equalsIgnoreCase(Constants.HR_STORAGE_DESC)) {
											Vector<? extends VariableBinding> descVarBindList = SNMPUtils.getBulk(snmpCreditionals, oidForm.getOidValue());
											if(descVarBindList != null){
											for (int count = 0; count < descVarBindList.size(); count++)
											{
											desc.add(descVarBindList.get(count).getVariable().toString());	
											}}
										}
									}
									indexElement.setDescList(desc);
									indexElement.setIndexList(index);
									indexElement.setOidFormList(oidFormList);
									indexMap.put(element, indexElement);
								}
							}
							oidIndexMap.put(group, indexMap);
							
						}catch (Exception e) {
							Log.error("Contact_Center Probe::Exception while Qos collection for HOST_RESOURCE", e);
						}
						}},true);
				taskList.add(pollTask12);
				executor.execute(pollTask12);
			}
			if (group.equalsIgnoreCase(Constants.UCCE_HOST_RESOURCE)) {
				FutureTask<Boolean> pollTask13 = new FutureTask<Boolean>(new Runnable() {
					@Override
					public void run() {
						try {
							ConcurrentHashMap<String, ArrayList<OidForm>> groupList=oidListMap1.get(group);
							Set<String> elementSet = groupList.keySet();
							ConcurrentHashMap<String,IndexElement> indexMap=new ConcurrentHashMap<String,IndexElement>();
							for(String element:elementSet){
								 ArrayList<OidForm> oidFormList=groupList.get(element);
								if(element.equalsIgnoreCase(Constants.UCCE_PROCESSOR)){
									IndexElement indexElement=new IndexElement();
									ArrayList<String> index=new ArrayList<String>();
									ArrayList<String> desc=new ArrayList<String>();
									for (OidForm oidForm : oidFormList) {
										if (oidForm.getOidName().equalsIgnoreCase(Constants.HR_PROCESS_LOAD)) {
											Vector<? extends VariableBinding> indexVarBindList = SNMPUtils.getBulk(snmpCreditionals, oidForm.getOidValue());
											if(indexVarBindList != null){
											for (int count = 0; count < indexVarBindList.size(); count++) {
												index.add(indexVarBindList.get(count).getVariable().toString());
												desc.add("Processor: " + count);
											}
											}
										} 
									}
									indexElement.setDescList(desc);
									indexElement.setIndexList(index);
									indexElement.setOidFormList(oidFormList);
									indexMap.put(element, indexElement);
								}
								if(element.equalsIgnoreCase(Constants.UCCE_MEMORY)){
									IndexElement indexElement=new IndexElement();
									ArrayList<String> index=new ArrayList<String>();
									ArrayList<String> desc=new ArrayList<String>();
									for (OidForm oidForm : oidFormList) {
										if (oidForm.getOidName().equalsIgnoreCase(Constants.HR_STORAGE_INDEX)) {
											Vector<? extends VariableBinding> indexVarBindList = SNMPUtils.getBulk(snmpCreditionals, oidForm.getOidValue());
											if(indexVarBindList != null){
											for (int count = 0; count < indexVarBindList.size(); count++) {
												index.add(indexVarBindList.get(count).getVariable().toString());
											}}
										} 
										if (oidForm.getOidName().equalsIgnoreCase(Constants.HR_STORAGE_DESC)) {
											Vector<? extends VariableBinding> descVarBindList = SNMPUtils.getBulk(snmpCreditionals, oidForm.getOidValue());
											if(descVarBindList != null){
											for (int count = 0; count < descVarBindList.size(); count++)
											{
											desc.add(descVarBindList.get(count).getVariable().toString());	
											}}
										}
									}
									indexElement.setDescList(desc);
									indexElement.setIndexList(index);
									indexElement.setOidFormList(oidFormList);
									indexMap.put(element, indexElement);
								}
							}
							oidIndexMap.put(group, indexMap);
							
						}catch (Exception e) {
							Log.error("Contact_Center Probe::Exception while Qos collection for HOST_RESOURCE", e);
						}
						}},true);
				taskList.add(pollTask13);
				executor.execute(pollTask13);
			}
			if (group.equalsIgnoreCase(Constants.SOFTWARE)) {
				FutureTask<Boolean> pollTask14 = new FutureTask<Boolean>(new Runnable() {
					@Override
					public void run() {
						try {
							ConcurrentHashMap<String, ArrayList<OidForm>> groupList=oidListMap1.get(group);
							Set<String> elementSet = groupList.keySet();
							ConcurrentHashMap<String,IndexElement> indexMap=new ConcurrentHashMap<String,IndexElement>();
							for(String element:elementSet){
								 ArrayList<OidForm> oidFormList=groupList.get(element);
								if(element.equalsIgnoreCase(Constants.SOFTWARE)){
									IndexElement indexElement=new IndexElement();
									ArrayList<String> index=new ArrayList<String>();
									ArrayList<String> desc=new ArrayList<String>();
									for (OidForm oidForm : oidFormList) {
										if (oidForm.getOidName().equalsIgnoreCase(Constants.HR_SW_RUNINDEX)) {
											Vector<? extends VariableBinding> indexVarBindList = SNMPUtils.getBulk(snmpCreditionals, oidForm.getOidValue());
											if(indexVarBindList != null){
											for (int count = 0; count < indexVarBindList.size(); count++) {
												index.add(indexVarBindList.get(count).getVariable().toString());
											}}
										} 
										if (oidForm.getOidName().equalsIgnoreCase(Constants.HR_SW_RUNNAME)) {
											Vector<? extends VariableBinding> descVarBindList = SNMPUtils.getBulk(snmpCreditionals, oidForm.getOidValue());
											if(descVarBindList != null){
											for (int count = 0; count < descVarBindList.size(); count++)
											{
											desc.add(descVarBindList.get(count).getVariable().toString());	
											}}
										}
									}
									indexElement.setDescList(desc);
									indexElement.setIndexList(index);
									indexElement.setOidFormList(oidFormList);
									indexMap.put(element, indexElement);
								}
							}
							oidIndexMap.put(group, indexMap);
						
						}catch (Exception e) {
							Log.error("Contact_Center Probe::Exception while Qos collection for SOFTWARE", e);
						}
						}},true);
				taskList.add(pollTask14);
				executor.execute(pollTask14);
			}
			if (group.equalsIgnoreCase(Constants.GATEWAY_TRUNK)) {
				FutureTask<Boolean> pollTask15 = new FutureTask<Boolean>(new Runnable() {
					@Override
					public void run() {
						try {
							ConcurrentHashMap<String, ArrayList<OidForm>> groupList=oidListMap1.get(group);
							Set<String> elementSet = groupList.keySet();
							ConcurrentHashMap<String,IndexElement> indexMap=new ConcurrentHashMap<String,IndexElement>();
							for(String element:elementSet){
								 ArrayList<OidForm> oidFormList=groupList.get(element);
								if(element.equalsIgnoreCase(Constants.GATEWAY_TRUNK)){
									IndexElement indexElement=new IndexElement();
									ArrayList<String> indexList=new ArrayList<String>();
									ArrayList<String> descList=new ArrayList<String>();
									for (OidForm oidForm : oidFormList) {
										if (oidForm.getOidName().equalsIgnoreCase(Constants.IF_INDEX)) {
											Vector<? extends VariableBinding> indexVarBindList = SNMPUtils.getBulk(snmpCreditionals, oidForm.getOidValue());
											if(indexVarBindList != null){
											for (int count = 0; count < indexVarBindList.size(); count++) {
												indexList.add(indexVarBindList.get(count).getVariable().toString());
											}}
										} else if (oidForm.getOidName().equalsIgnoreCase(Constants.IF_DESC)) {
											Vector<? extends VariableBinding> descVarBindList = SNMPUtils.getBulk(snmpCreditionals, oidForm.getOidValue());
											if(descVarBindList != null){
											for (int count = 0; count < descVarBindList.size(); count++)
											{
												descList.add(descVarBindList.get(count).getVariable().toString());	
											}}
										}
									}
									indexElement.setDescList(descList);
									indexElement.setIndexList(indexList);
									indexElement.setOidFormList(oidFormList);
									indexMap.put(element,indexElement);
								}
							}
							oidIndexMap.put(group, indexMap);
						
						}catch (Exception e) {
							Log.error("Contact_Center Probe::Exception while Qos collection for GATEWAY_TRUNK", e);
						}
						}},true);
				taskList.add(pollTask15);
				executor.execute(pollTask15);
			}
			if (group.equalsIgnoreCase(Constants.CCM_GLOBAL_INFO_GROUP)) {    //For scaler only
				FutureTask<Boolean> pollTask16 = new FutureTask<Boolean>(new Runnable() {
					@Override
					public void run() {
						try {
							ConcurrentHashMap<String, ArrayList<OidForm>> elementMap=oidListMap1.get(group);
							Set<String> elementSet = elementMap.keySet();
							ConcurrentHashMap<String,IndexElement> indexMap=new ConcurrentHashMap<String,IndexElement>();
							for(String element:elementSet){
								 ArrayList<OidForm> oidFormList=elementMap.get(element);
								if(element.equalsIgnoreCase(Constants.CCM_GLOBAL_INFO_ELEMENT)){
									IndexElement indexElement=new IndexElement();
									ArrayList<String> indexList=new ArrayList<String>();
									ArrayList<String> descList=new ArrayList<String>();
									for (@SuppressWarnings("unused") OidForm oidForm : oidFormList) {
										indexList.add("0");           //
										descList.add(Constants.CCM_GLOBAL_INFO_ELEMENT2);
										
									}
									indexElement.setDescList(descList);
			 						indexElement.setIndexList(indexList);
			 						indexElement.setOidFormList(oidFormList);
									indexMap.put(element, indexElement);
								}
							}
							oidIndexMap.put(group, indexMap);
						
						}catch (Exception e) {
							Log.error("Contact_Center Probe::Exception while Qos collection for  CCM_GLOBAL_INFO_GROUP ", e);
						}
						}},true);
				taskList.add(pollTask16);
				executor.execute(pollTask16);
			}
			if (group.equalsIgnoreCase(Constants.CCM_PHONE_INFO_GROUP)) {
				FutureTask<Boolean> pollTask17 = new FutureTask<Boolean>(new Runnable() {
					@Override
					public void run() {
						try {

							ConcurrentHashMap<String, ArrayList<OidForm>> elementMap=oidListMap1.get(group);  //elementMap
							Set<String> elementSet = elementMap.keySet();
							ConcurrentHashMap<String,IndexElement> indexMap=new ConcurrentHashMap<String,IndexElement>();  //indexElementMap
							for(String element:elementSet){
								 ArrayList<OidForm> oidFormList=elementMap.get(element);        //get OidFormList
								if(element.equalsIgnoreCase(Constants.CCM_PHONE_INFO_ELEMENT)){
									IndexElement indexElement=new IndexElement();
									ArrayList<String> indexList=new ArrayList<String>();
									ArrayList<String> descList=new ArrayList<String>();
									Vector<? extends VariableBinding> phoneTypeVarBind = null;
									for (OidForm oidForm : oidFormList) {
										if (oidForm.getOidName().equalsIgnoreCase(Constants.CCM_PHONE_TYPE)) {
											phoneTypeVarBind = SNMPUtils.getBulk(snmpCreditionals, oidForm.getOidValue());
											if (phoneTypeVarBind != null && phoneTypeVarBind.size() != 0) {
												for (int count = 0; count < phoneTypeVarBind.size(); count++) {
													indexList.add(phoneTypeVarBind.get(count).getOid().toString().trim().substring(oidForm.getOidValue().trim().length()));
												}
											}
										}else if (oidForm.getOidName().equalsIgnoreCase(Constants.CCM_PHONE_IP_ADDRESS)) {
											Vector<? extends VariableBinding> descVarBindList = SNMPUtils.getBulk(snmpCreditionals, oidForm.getOidValue());
											if (descVarBindList != null && descVarBindList.size() != 0) {
											for (int count = 0; count < descVarBindList.size(); count++)
											{
												descList.add(descVarBindList.get(count).getVariable().toString());	
											}}
										}
									}
									
									indexElement.setDescList(descList);
									indexElement.setIndexList(indexList);
									indexElement.setOidFormList(oidFormList);
									indexMap.put(Constants.CCM_PHONE_INFO_ELEMENT,indexElement);
								}
							}
							oidIndexMap.put(Constants.CCM_PHONE_INFO_GROUP, indexMap);
						
						}catch (Exception e) {
							Log.error("Contact_Center Probe::Exception while Qos collection for CCM_PHONE_INFO_GROUP", e);
						}
						}},true);
				taskList.add(pollTask17);
				executor.execute(pollTask17);
			}if (group.equalsIgnoreCase(Constants.CUCM_GROUP)) {
				FutureTask<Boolean> pollTask18 = new FutureTask<Boolean>(new Runnable() {
					@Override
					public void run() {
						try {
							ConcurrentHashMap<String, ArrayList<OidForm>> elementMap=oidListMap1.get(group);  //elementMap
							Set<String> elementSet = elementMap.keySet();
							ConcurrentHashMap<String,IndexElement> indexMap=new ConcurrentHashMap<String,IndexElement>();  //indexElementMap
							for(String element:elementSet){
								 ArrayList<OidForm> oidFormList=elementMap.get(element);        //get OidFormList
								if(element.equalsIgnoreCase(Constants.CUCM_ELEMENT_1)){
									IndexElement indexElement=new IndexElement();
									ArrayList<String> indexList=new ArrayList<String>();
									ArrayList<String> descList=new ArrayList<String>();
									Vector<? extends VariableBinding> phoneTypeVarBind = null;
									for (OidForm oidForm : oidFormList) {
										if (oidForm.getOidName().equalsIgnoreCase(Constants.CUCM_GROUP_TFTP_DEFAULT)) {
											phoneTypeVarBind = SNMPUtils.getBulk(snmpCreditionals, oidForm.getOidValue());
											if (phoneTypeVarBind != null && phoneTypeVarBind.size() != 0) {
												for (int count = 0; count < phoneTypeVarBind.size(); count++) {
													indexList.add(phoneTypeVarBind.get(count).getOid().toString().trim().substring(oidForm.getOidValue().trim().length()));
												}
											}
										}else if (oidForm.getOidName().equalsIgnoreCase(Constants.CUCM_GROUP_NAME)) {
											Vector<? extends VariableBinding> descVarBindList = SNMPUtils.getBulk(snmpCreditionals, oidForm.getOidValue());
											if(descVarBindList != null){
												Log.info("#####################descVarBindList size="+descVarBindList.size());
												Log.info("#####################indexList size="+indexList.size());
												for (int count = 0; count < descVarBindList.size(); count++)
												{Log.info("#####################"+count);
												Log.info("#########################"+descVarBindList.get(count).getVariable().toString());
													descList.add(descVarBindList.get(count).getVariable().toString());	
												}
											}
										}
									}
									
									indexElement.setDescList(descList);
									indexElement.setIndexList(indexList);
									indexElement.setOidFormList(oidFormList);
									indexMap.put(element,indexElement);
								}
								if(element.equalsIgnoreCase(Constants.CUCM_ELEMENT_2)){
									IndexElement indexElement=new IndexElement();
									ArrayList<String> indexList=new ArrayList<String>();
									ArrayList<String> descList=new ArrayList<String>();
									Vector<? extends VariableBinding> phoneTypeVarBind = null;
									for (OidForm oidForm : oidFormList) {
										if (oidForm.getOidName().equalsIgnoreCase(Constants.CUCM_NAME)) {
											phoneTypeVarBind = SNMPUtils.getBulk(snmpCreditionals, oidForm.getOidValue());
											if (phoneTypeVarBind != null && phoneTypeVarBind.size() != 0) {
												for (int count = 0; count < phoneTypeVarBind.size(); count++) {
													indexList.add(phoneTypeVarBind.get(count).getOid().toString().trim().substring(oidForm.getOidValue().trim().length()));
												}
											}
										}else if (oidForm.getOidName().equalsIgnoreCase(Constants.CUCM_INET_ADDRESS)) {
											Vector<? extends VariableBinding> descVarBindList = SNMPUtils.getBulk(snmpCreditionals, oidForm.getOidValue());
											if(descVarBindList != null){
												for (int count = 0; count < descVarBindList.size(); count++)
												{
													descList.add(descVarBindList.get(count).getVariable().toString());	
												}
											}
										}
									}
									
									indexElement.setDescList(descList);
									indexElement.setIndexList(indexList);
									indexElement.setOidFormList(oidFormList);
									indexMap.put(element,indexElement);
								}
							}
							oidIndexMap.put(group, indexMap);
						
						}catch (Exception e) {
							Log.error("Contact_Center Probe::Exception while Qos collection for CUCM_GROUP", e);
						}
						}},true);
				taskList.add(pollTask18);
				executor.execute(pollTask18);
			}if (group.equalsIgnoreCase(Constants.CCM_GATEWAY_TRUNK_GROUP)) {
				FutureTask<Boolean> pollTask19 = new FutureTask<Boolean>(new Runnable() {
					@Override
					public void run() {
						try {
                            ConcurrentHashMap<String, ArrayList<OidForm>> elementMap=oidListMap1.get(group);  //elementMap
							Set<String> elementSet = elementMap.keySet();
							ConcurrentHashMap<String,IndexElement> indexMap=new ConcurrentHashMap<String,IndexElement>();  //indexElementMap
							for(String element:elementSet){
								 ArrayList<OidForm> oidFormList=elementMap.get(element);        //get OidFormList
								if(element.equalsIgnoreCase(Constants.CCM_GATEWAY_TRUNK_ELEMENT)){
									IndexElement indexElement=new IndexElement();
									ArrayList<String> indexList=new ArrayList<String>();
									ArrayList<String> descList=new ArrayList<String>();
									Vector<? extends VariableBinding> phoneTypeVarBind = null;
									for (OidForm oidForm : oidFormList) {
										if (oidForm.getOidName().equalsIgnoreCase(Constants.CCM_GATEWAY_TRUNK_TYPE)) {
											phoneTypeVarBind = SNMPUtils.getBulk(snmpCreditionals, oidForm.getOidValue());
											if (phoneTypeVarBind != null && phoneTypeVarBind.size() != 0) {
												for (int count = 0; count < phoneTypeVarBind.size(); count++) {
													indexList.add(phoneTypeVarBind.get(count).getOid().toString().trim().substring(oidForm.getOidValue().trim().length()));
												}
											}
										}else if (oidForm.getOidName().equalsIgnoreCase(Constants.CCM_GATEWAY_TRUNK_NAME)) {
											Vector<? extends VariableBinding> descVarBindList = SNMPUtils.getBulk(snmpCreditionals, oidForm.getOidValue());
											if(descVarBindList != null){
												for (int count = 0; count < descVarBindList.size(); count++)
												{
													descList.add(descVarBindList.get(count).getVariable().toString());	
												}
											}
										}
									}
									
									indexElement.setDescList(descList);
									indexElement.setIndexList(indexList);
									indexElement.setOidFormList(oidFormList);
									indexMap.put(element,indexElement);
								}
							}
							oidIndexMap.put(group, indexMap);
						
						}catch (Exception e) {
							Log.error("Contact_Center Probe::Exception while Qos collection for CCM_GATEWAY_TRUNK_GROUP ", e);
						}
						}},true);
				taskList.add(pollTask19);
				executor.execute(pollTask19);
			}if(group.equalsIgnoreCase(Constants.CCCA_GENERAL_INFO_GROUP)) {    //For scaler only
				FutureTask<Boolean> pollTask20 = new FutureTask<Boolean>(new Runnable() {
					@Override
					public void run() {
						try {
							ConcurrentHashMap<String, ArrayList<OidForm>> elementMap=oidListMap1.get(group);
							Set<String> elementSet = elementMap.keySet();
							ConcurrentHashMap<String,IndexElement> indexMap=new ConcurrentHashMap<String,IndexElement>();
							for(String element:elementSet){
								
								if(element.equalsIgnoreCase(Constants.CCCA_GENERAL_INFO_ELEMENT)){
									 ArrayList<OidForm> oidFormList=elementMap.get(element);
									IndexElement indexElement=new IndexElement();
									ArrayList<String> indexList=new ArrayList<String>();
									ArrayList<String> descList=new ArrayList<String>();
									for (OidForm oidForm : oidFormList) {
										indexList.add("0");           //
										descList.add(Constants.CCCA_GENERAL_INFO_LABLE);
										
									}
									indexElement.setDescList(descList);
			 						indexElement.setIndexList(indexList);
			 						indexElement.setOidFormList(oidFormList);
									indexMap.put(element, indexElement);
								}
							}
							oidIndexMap.put(group, indexMap);
						
						}catch (Exception e) {
							Log.error("Contact_Center Probe::Exception while Qos collection for  CCCA_GENERAL_INFO_GROUP ", e);
						}
						}},true);
				taskList.add(pollTask20);
				executor.execute(pollTask20);
			}if (group.equalsIgnoreCase(Constants.CCCA_INSTANCE_TABLE_GROUP)) {
				FutureTask<Boolean> pollTask21 = new FutureTask<Boolean>(new Runnable() {
					@Override
					public void run() {
						try {
							ConcurrentHashMap<String, ArrayList<OidForm>> groupList=oidListMap1.get(group);
							Set<String> elementSet = groupList.keySet();
							ConcurrentHashMap<String,IndexElement> indexMap=new ConcurrentHashMap<String,IndexElement>();
							for(String element:elementSet){
								 ArrayList<OidForm> oidFormList=groupList.get(element);
								if(element.equalsIgnoreCase(Constants.CCCA_INSTANCE_TABLE_ELEMENT)){
									IndexElement indexElement=new IndexElement();
									ArrayList<String> index=new ArrayList<String>();
									ArrayList<String> desc=new ArrayList<String>();
									for (OidForm oidForm : oidFormList) {
										if (oidForm.getOidName().equalsIgnoreCase(Constants.CCCA_INSTANCE_NAME)) {
											Vector<? extends VariableBinding> descVarBindList = SNMPUtils.getBulk(snmpCreditionals, oidForm.getOidValue());
			                                 if (descVarBindList.size() != 0) {
												for (int count = 0; count < descVarBindList.size(); count++) {
													index.add(descVarBindList.get(count).getOid().toString().trim().substring(oidForm.getOidValue().trim().length()+1));
												}
												for (int count = 0; count < descVarBindList.size(); count++) {
													desc.add(descVarBindList.get(count).getVariable().toString());
												}
											}
			                                indexElement.setDescList(desc);
			         						indexElement.setIndexList(index);
			         						indexElement.setOidFormList(oidFormList);   
										}
									}
									indexMap.put(element, indexElement);
								}
							}
							oidIndexMap.put(group, indexMap);
						
						}catch (Exception e) {
							Log.error("Contact_Center Probe::Exception while Data collection for CCM_GLOBAL_INFO_GROUP", e);
						}
						}},true);
				taskList.add(pollTask21);
				executor.execute(pollTask21);
			}if (group.equalsIgnoreCase(Constants.CCCA_COMPONENT_TABLE_GROUP)) {
				FutureTask<Boolean> pollTask22 = new FutureTask<Boolean>(new Runnable() {
					@Override
					public void run() {
						try {
							ConcurrentHashMap<String, ArrayList<OidForm>> groupList=oidListMap1.get(group);
							Set<String> elementSet = groupList.keySet();
							ConcurrentHashMap<String,IndexElement> indexMap=new ConcurrentHashMap<String,IndexElement>();
							for(String element:elementSet){
								 ArrayList<OidForm> oidFormList=groupList.get(element);
								if(element.equalsIgnoreCase(Constants.CCCA_COMPONENT_TABLE_ELEMENT)){
									IndexElement indexElement=new IndexElement();
									ArrayList<String> index=new ArrayList<String>();
									ArrayList<String> desc=new ArrayList<String>();
									for (OidForm oidForm : oidFormList) {
										if (oidForm.getOidName().equalsIgnoreCase(Constants.CCCA_COMPONENT_NAME)) {
											Vector<? extends VariableBinding> descVarBindList = SNMPUtils.getBulk(snmpCreditionals, oidForm.getOidValue());
			                                 if (descVarBindList.size() != 0) {
												for (int count = 0; count < descVarBindList.size(); count++) {
													index.add(descVarBindList.get(count).getOid().toString().trim().substring(oidForm.getOidValue().trim().length()+1));
												}
												for (int count = 0; count < descVarBindList.size(); count++) {
													desc.add(descVarBindList.get(count).getVariable().toString());
												}
											}
			                                indexElement.setDescList(desc);
			         						indexElement.setIndexList(index);
			         						indexElement.setOidFormList(oidFormList);   
										}
									}
									indexMap.put(element, indexElement);
								}
							}
							oidIndexMap.put(group, indexMap);
						
						}catch (Exception e) {
							Log.error("Contact_Center Probe::Exception while Data collection for CCCA_COMPONENT_TABLE_GROUP", e);
						}
						}},true);
				taskList.add(pollTask22);
				executor.execute(pollTask22);
			}if (group.equalsIgnoreCase(Constants.CCCA_ROUTER_TABLE_GROUP)) {
				FutureTask<Boolean> pollTask23 = new FutureTask<Boolean>(new Runnable() {
					@Override
					public void run() {
						try {
							ConcurrentHashMap<String, ArrayList<OidForm>> groupList=oidListMap1.get(group);
							Set<String> elementSet = groupList.keySet();
							ConcurrentHashMap<String,IndexElement> indexMap=new ConcurrentHashMap<String,IndexElement>();
							for(String element:elementSet){
								 ArrayList<OidForm> oidFormList=groupList.get(element);
								if(element.equalsIgnoreCase(Constants.CCCA_ROUTER_TABLE_ELEMENT)){
									IndexElement indexElement=new IndexElement();
									ArrayList<String> index=new ArrayList<String>();
									ArrayList<String> desc=new ArrayList<String>();
									for (OidForm oidForm : oidFormList) {
										if (oidForm.getOidName().equalsIgnoreCase(Constants.CCCA_ROUTER_SIDE)) {
											Vector<? extends VariableBinding> descVarBindList = SNMPUtils.getBulk(snmpCreditionals, oidForm.getOidValue());
			                                 if (descVarBindList.size() != 0) {
												for (int count = 0; count < descVarBindList.size(); count++) {
													index.add(descVarBindList.get(count).getOid().toString().trim().substring(oidForm.getOidValue().trim().length()+1));
													desc.add("router "+descVarBindList.get(count).getOid().toString().trim().substring(oidForm.getOidValue().trim().length()+1));
												}
												/*for (int count = 0; count < descVarBindList.size(); count++) {
													desc.add(descVarBindList.get(count).getVariable().toString());
												}*/
											}
			                                indexElement.setDescList(desc);
			         						indexElement.setIndexList(index);
			         						indexElement.setOidFormList(oidFormList);   
										}
									}
									indexMap.put(element, indexElement);
								}
							}
							oidIndexMap.put(group, indexMap);
						
						}catch (Exception e) {
							Log.error("Contact_Center Probe::Exception while Data collection for CCCA_COMPONENT_TABLE_GROUP", e);
						}
						}},true);
				taskList.add(pollTask23);
				executor.execute(pollTask23);
			}if (group.equalsIgnoreCase(Constants.CCCA_LOGGER_TABLE_GROUP)) {
				FutureTask<Boolean> pollTask24 = new FutureTask<Boolean>(new Runnable() {
					@Override
					public void run() {
						try {
							ConcurrentHashMap<String, ArrayList<OidForm>> groupList=oidListMap1.get(group);
							Set<String> elementSet = groupList.keySet();
							ConcurrentHashMap<String,IndexElement> indexMap=new ConcurrentHashMap<String,IndexElement>();
							for(String element:elementSet){
								 ArrayList<OidForm> oidFormList=groupList.get(element);
								if(element.equalsIgnoreCase(Constants.CCCA_LOGGER_TABLE_ELEMENT)){
									IndexElement indexElement=new IndexElement();
									ArrayList<String> index=new ArrayList<String>();
									ArrayList<String> desc=new ArrayList<String>();
									for (OidForm oidForm : oidFormList) {
										if (oidForm.getOidName().equalsIgnoreCase(Constants.CCCA_LOGGER_ROUTER_SIDEA_NAME)) {
											Vector<? extends VariableBinding> descVarBindList = SNMPUtils.getBulk(snmpCreditionals, oidForm.getOidValue());
			                                 if (descVarBindList.size() != 0) {
												for (int count = 0; count < descVarBindList.size(); count++) {
													index.add(descVarBindList.get(count).getOid().toString().trim().substring(oidForm.getOidValue().trim().length()+1));
													desc.add("Logger_router "+descVarBindList.get(count).getOid().toString().trim().substring(oidForm.getOidValue().trim().length()+1));
												}
												/*for (int count = 0; count < descVarBindList.size(); count++) {
													desc.add(descVarBindList.get(count).getVariable().toString());
												}*/
											}
			                                indexElement.setDescList(desc);
			         						indexElement.setIndexList(index);
			         						indexElement.setOidFormList(oidFormList);   
										}
									}
									indexMap.put(element, indexElement);
								}
							}
							oidIndexMap.put(group, indexMap);
						
						}catch (Exception e) {
							Log.error("Contact_Center Probe::Exception while Data collection for CCCA_COMPONENT_TABLE_GROUP", e);
						}
						}},true);
				taskList.add(pollTask24);
				executor.execute(pollTask24);
			}if (group.equalsIgnoreCase(Constants.CCCA_DISTAW_TABLE_GROUP)) {
				FutureTask<Boolean> pollTask25 = new FutureTask<Boolean>(new Runnable() {
					@Override
					public void run() {
						try {
							ConcurrentHashMap<String, ArrayList<OidForm>> groupList=oidListMap1.get(group);
							Set<String> elementSet = groupList.keySet();
							ConcurrentHashMap<String,IndexElement> indexMap=new ConcurrentHashMap<String,IndexElement>();
							for(String element:elementSet){
								 ArrayList<OidForm> oidFormList=groupList.get(element);
								if(element.equalsIgnoreCase(Constants.CCCA_DISTAW_TABLE_ELEMENT)){
									IndexElement indexElement=new IndexElement();
									ArrayList<String> index=new ArrayList<String>();
									ArrayList<String> desc=new ArrayList<String>();
									for (OidForm oidForm : oidFormList) {
										if (oidForm.getOidName().equalsIgnoreCase(Constants.CCCA_DISTAW_ADMIN_SITE_NAME)) {
											Vector<? extends VariableBinding> descVarBindList = SNMPUtils.getBulk(snmpCreditionals, oidForm.getOidValue());
			                                 if (descVarBindList.size() != 0) {
												for (int count = 0; count < descVarBindList.size(); count++) {
													index.add(descVarBindList.get(count).getOid().toString().trim().substring(oidForm.getOidValue().trim().length()+1));
													desc.add("Dist "+descVarBindList.get(count).getOid().toString().trim().substring(oidForm.getOidValue().trim().length()+1));
												}
												/*for (int count = 0; count < descVarBindList.size(); count++) {
													desc.add(descVarBindList.get(count).getVariable().toString());
												}*/
											}
			                                indexElement.setDescList(desc);
			         						indexElement.setIndexList(index);
			         						indexElement.setOidFormList(oidFormList);   
										}
									}
									indexMap.put(element, indexElement);
								}
							}
							oidIndexMap.put(group, indexMap);
						
						}catch (Exception e) {
							Log.error("Contact_Center Probe::Exception while Data collection for CCCA_COMPONENT_TABLE_GROUP", e);
						}
						}},true);
				taskList.add(pollTask25);
				executor.execute(pollTask25);
			}if (group.equalsIgnoreCase(Constants.CCCA_PG_TABLE_GROUP)) {
				FutureTask<Boolean> pollTask26 = new FutureTask<Boolean>(new Runnable() {
					@Override
					public void run() {
						try {
							ConcurrentHashMap<String, ArrayList<OidForm>> groupList=oidListMap1.get(group);
							Set<String> elementSet = groupList.keySet();
							ConcurrentHashMap<String,IndexElement> indexMap=new ConcurrentHashMap<String,IndexElement>();
							for(String element:elementSet){
								 ArrayList<OidForm> oidFormList=groupList.get(element);
								if(element.equalsIgnoreCase(Constants.CCCA_PG_TABLE_ELEMENT)){
									IndexElement indexElement=new IndexElement();
									ArrayList<String> index=new ArrayList<String>();
									ArrayList<String> desc=new ArrayList<String>();
									for (OidForm oidForm : oidFormList) {
										if (oidForm.getOidName().equalsIgnoreCase(Constants.CCCA_PG_ROUTER_SIDEA_NAME)) {
											Vector<? extends VariableBinding> descVarBindList = SNMPUtils.getBulk(snmpCreditionals, oidForm.getOidValue());
			                                 if (descVarBindList.size() != 0) {
												for (int count = 0; count < descVarBindList.size(); count++) {
													index.add(descVarBindList.get(count).getOid().toString().trim().substring(oidForm.getOidValue().trim().length()+1));
													desc.add("Pg "+descVarBindList.get(count).getOid().toString().trim().substring(oidForm.getOidValue().trim().length()+1));
												}
												/*for (int count = 0; count < descVarBindList.size(); count++) {
													desc.add(descVarBindList.get(count).getVariable().toString());
												}*/
											}
			                                indexElement.setDescList(desc);
			         						indexElement.setIndexList(index);
			         						indexElement.setOidFormList(oidFormList);   
										}
									}
									indexMap.put(element, indexElement);
								}
							}
							oidIndexMap.put(group, indexMap);
						
						}catch (Exception e) {
							Log.error("Contact_Center Probe::Exception while Data collection for CCCA_COMPONENT_TABLE_GROUP", e);
						}
						}},true);
				taskList.add(pollTask26);
				executor.execute(pollTask26);
			}if (group.equalsIgnoreCase(Constants.CCCA_PIM_TABLE_GROUP)) {
				FutureTask<Boolean> pollTask27 = new FutureTask<Boolean>(new Runnable() {
					@Override
					public void run() {
						try {
							ConcurrentHashMap<String, ArrayList<OidForm>> groupList=oidListMap1.get(group);
							Set<String> elementSet = groupList.keySet();
							ConcurrentHashMap<String,IndexElement> indexMap=new ConcurrentHashMap<String,IndexElement>();
							for(String element:elementSet){
								 ArrayList<OidForm> oidFormList=groupList.get(element);
								if(element.equalsIgnoreCase(Constants.CCCA_PIM_TABLE_ELEMENT)){
									IndexElement indexElement=new IndexElement();
									ArrayList<String> index=new ArrayList<String>();
									ArrayList<String> desc=new ArrayList<String>();
									for (OidForm oidForm : oidFormList) {
										if (oidForm.getOidName().equalsIgnoreCase(Constants.CCCA_PIM_PERIPHERAL_NAME)) {
											Vector<? extends VariableBinding> descVarBindList = SNMPUtils.getBulk(snmpCreditionals, oidForm.getOidValue());
			                                 if (descVarBindList.size() != 0) {
												for (int count = 0; count < descVarBindList.size(); count++) {
													index.add(descVarBindList.get(count).getOid().toString().trim().substring(oidForm.getOidValue().trim().length()+1));
													desc.add(descVarBindList.get(count).getVariable().toString());
												}
												/*for (int count = 0; count < descVarBindList.size(); count++) {
													desc.add(descVarBindList.get(count).getVariable().toString());
												}*/
											}
			                                indexElement.setDescList(desc);
			         						indexElement.setIndexList(index);
			         						indexElement.setOidFormList(oidFormList);   
										}
									}
									indexMap.put(element, indexElement);
								}
							}
							oidIndexMap.put(group, indexMap);
						
						}catch (Exception e) {
							Log.error("Contact_Center Probe::Exception while Data collection for CCCA_COMPONENT_TABLE_GROUP", e);
						}
						}},true);
				taskList.add(pollTask27);
				executor.execute(pollTask27);
			}if (group.equalsIgnoreCase(Constants.CCCA_CG_TABLE_GROUP)) {
				FutureTask<Boolean> pollTask28 = new FutureTask<Boolean>(new Runnable() {
					@Override
					public void run() {
						try {
							ConcurrentHashMap<String, ArrayList<OidForm>> groupList=oidListMap1.get(group);
							Set<String> elementSet = groupList.keySet();
							ConcurrentHashMap<String,IndexElement> indexMap=new ConcurrentHashMap<String,IndexElement>();
							for(String element:elementSet){
								 ArrayList<OidForm> oidFormList=groupList.get(element);
								if(element.equalsIgnoreCase(Constants.CCCA_CG_TABLE_ELEMENT)){
									IndexElement indexElement=new IndexElement();
									ArrayList<String> index=new ArrayList<String>();
									ArrayList<String> desc=new ArrayList<String>();
									for (OidForm oidForm : oidFormList) {
										if (oidForm.getOidName().equalsIgnoreCase(Constants.CCCA_CG_NUMBER)) {
											Vector<? extends VariableBinding> descVarBindList = SNMPUtils.getBulk(snmpCreditionals, oidForm.getOidValue());
			                                 if (descVarBindList.size() != 0) {
												for (int count = 0; count < descVarBindList.size(); count++) {
													index.add(descVarBindList.get(count).getOid().toString().trim().substring(oidForm.getOidValue().trim().length()+1));
													desc.add("CG "+descVarBindList.get(count).getOid().toString().trim().substring(oidForm.getOidValue().trim().length()+1));
												}
												/*for (int count = 0; count < descVarBindList.size(); count++) {
													desc.add(descVarBindList.get(count).getVariable().toString());
												}*/
											}
			                                indexElement.setDescList(desc);
			         						indexElement.setIndexList(index);
			         						indexElement.setOidFormList(oidFormList);   
										}
									}
									indexMap.put(element, indexElement);
								}
							}
							oidIndexMap.put(group, indexMap);
						
						}catch (Exception e) {
							Log.error("Contact_Center Probe::Exception while Data collection for CCCA_COMPONENT_TABLE_GROUP", e);
						}
						}},true);
				taskList.add(pollTask28);
				executor.execute(pollTask28);
			}
		}
		 for (int j = 0; j < taskList.size(); j++) {
	            Log.info("Contact_center :: Waiting for thread to get completed");
	            FutureTask<Boolean> futureTask = taskList.get(j);
	            try {
	                Log.info("Contact_center :: For the task[" + j + "]result is[" + futureTask.get() + "]");
	            } catch (ExecutionException | InterruptedException e) {
	                Log.fatal("Contact_center ::Exception encountered while waiting for thread to get completed", e);
	            }
	        }
		 executor.shutdownNow();
		long endtime = System.currentTimeMillis();
		long total=endtime-starttime;
		 Log.info("Contact_center::Execution time for getOidIndexList()=========== ["  +total+ "]ms");
	return 	oidIndexMap;
	}
	
	public static void setQosForAxlCiscoTomcatJVM(Map<String,List<QOS>> axlMap,SnmpCreditionals snmpCreditionals,Folder axlGlobalFolder,InventoryDataset inventoryDataset) throws NimException, InterruptedException{
		final Set<String> descList=axlMap.keySet();
		for(final String description:descList ){
			Log.info("Description For Cisco Tomcat JVM ==========================     "+description);
			final CiscoTomcatJVM ciscoTomcatJVM = CiscoTomcatJVM.addInstance(inventoryDataset, new EntityId(axlGlobalFolder, description), description, axlGlobalFolder);
			final List<QOS> qosList =  axlMap.get(description);
			for (final QOS qos : qosList) {
				if(qos.getKey().equalsIgnoreCase(Constants.K_BYTES_MEMORY_FREE)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_TOMCAT_JVM, Constants.K_BYTES_MEMORY_FREE);
					Log.info("QOS for Cisco Tomcat JVM  ==========================     "+qos.getValue());
					ciscoTomcatJVM.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.K_BYTES_MEMORY_MAX)){
					MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_TOMCAT_JVM, Constants.K_BYTES_MEMORY_MAX);
					Log.info("QOS for Cisco Tomcat JVM  ==========================     "+qos.getValue());
					ciscoTomcatJVM.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.K_BYTES_MEMORY_TOTAL)){
					MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_TOMCAT_JVM, Constants.K_BYTES_MEMORY_TOTAL);
					Log.info("QOS for Cisco Tomcat JVM  ==========================     "+qos.getValue());
					ciscoTomcatJVM.setMetric((MetricDef) metric,qos.getValue());
				}
			}
		}
	}
	public static void setQosForAxlCiscoTomcatWebApplication(Map<String,List<QOS>> axlMap,SnmpCreditionals snmpCreditionals,Folder axlGlobalFolder,InventoryDataset inventoryDataset) throws NimException, InterruptedException{
		final Set<String> descList=axlMap.keySet();
		for(final String description:descList ){
			Log.info("Description For Cisco Tomcat Web Application ==========================     "+description);
			final CiscoTomcatWebApplication ciscoTomcatWebApplication = CiscoTomcatWebApplication.addInstance(inventoryDataset, new EntityId(axlGlobalFolder, description), description, axlGlobalFolder);
			final List<QOS> qosList = axlMap.get(description);
			for (final QOS qos : qosList) {
				if(qos.getKey().equalsIgnoreCase(Constants.ERRORS)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_TOMCAT_WEB_APPLICATION, Constants.ERRORS);
					Log.info("QOS for Cisco Tomcat Web Application  ==========================     "+qos.getValue());
					ciscoTomcatWebApplication.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.REQUESTS)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_TOMCAT_WEB_APPLICATION, Constants.REQUESTS);
					Log.info("QOS for Cisco Tomcat Web Application  ==========================     "+qos.getValue());
					ciscoTomcatWebApplication.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.SESSION_ACTIVE)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_TOMCAT_WEB_APPLICATION, Constants.SESSION_ACTIVE);
					Log.info("QOS for Cisco Tomcat Web Application  ==========================     "+qos.getValue());
					ciscoTomcatWebApplication.setMetric((MetricDef) metric,qos.getValue());
				}
			}
		}
	}

	public static void setQosForAxlEnterpriseReplicationDBSpaceMonitors(Map<String,List<QOS>> axlMap,SnmpCreditionals snmpCreditionals,Folder axlGlobalFolder,InventoryDataset inventoryDataset) throws NimException, InterruptedException{
		final Set<String> descList=axlMap.keySet();
		for(final String description:descList ){
			Log.info("Description For Enterprise Replication DBSpace Monitors ==========================     "+description);
			final EnterpriseReplicationDBSpaceMonitors enterpriseReplicationDBSpaceMonitors = EnterpriseReplicationDBSpaceMonitors.addInstance(inventoryDataset, new EntityId(axlGlobalFolder, description), description, axlGlobalFolder);
			final List<QOS> qosList = axlMap.get(description);
			for (final QOS qos : qosList) {
				if(qos.getKey().equalsIgnoreCase(Constants.ER_DB_SPACE_USED)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_REPLICATION_DBSPACE_MONITORS, Constants.ER_DB_SPACE_USED);
					Log.info("QOS for Enterprise Replication DBSpace Monitors  ==========================     "+qos.getValue());
					enterpriseReplicationDBSpaceMonitors.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.ER_SB_DB_SPACE_USED)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_REPLICATION_DBSPACE_MONITORS, Constants.ER_SB_DB_SPACE_USED);
					Log.info("QOS for Enterprise Replication DBSpace Monitors  ==========================     "+qos.getValue());
					enterpriseReplicationDBSpaceMonitors.setMetric((MetricDef) metric,qos.getValue());
				}
			}
		}
	}
	public static void setQosForAxlDBLocalDSN(Map<String,List<QOS>> axlMap,SnmpCreditionals snmpCreditionals,Folder axlGlobalFolder,InventoryDataset inventoryDataset) throws NimException, InterruptedException{
		final Set<String> descList=axlMap.keySet();
		for(final String description:descList ){
			Log.info("Description For DB Local_DSN ==========================     "+description);
			final DBLocal_DSN dbLocal_DSN = DBLocal_DSN.addInstance(inventoryDataset, new EntityId(axlGlobalFolder, description), description, axlGlobalFolder);
			final List<QOS> qosList = axlMap.get(description);
			for (final QOS qos : qosList) {
				if(qos.getKey().equalsIgnoreCase(Constants.CN_DB_SPACE_USED)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.DB_LOCAL_DSN, Constants.CN_DB_SPACE_USED);
					Log.info("QOS for DB Local_DSN  ==========================     "+qos.getValue());
					dbLocal_DSN.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.CCM_DB_SPACE_USED)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.DB_LOCAL_DSN, Constants.CCM_DB_SPACE_USED);
					Log.info("QOS for DB Local_DSN  ==========================     "+qos.getValue());
					dbLocal_DSN.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.CCM_TEMP_SPACE_USED)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.DB_LOCAL_DSN, Constants.CCM_TEMP_SPACE_USED);
					Log.info("QOS for DB Local_DSN  ==========================     "+qos.getValue());
					dbLocal_DSN.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.DATABASE_CONNECTIONS_ACTIVE)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.DB_LOCAL_DSN, Constants.DATABASE_CONNECTIONS_ACTIVE);
					Log.info("QOS for DB Local_DSN  ==========================     "+qos.getValue());
					dbLocal_DSN.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.LOCAL_DSN)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.DB_LOCAL_DSN, Constants.LOCAL_DSN);
					Log.info("QOS for DB Local_DSN  ==========================     "+qos.getValue());
					dbLocal_DSN.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.ROOT_DB_SPACE_USED)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.DB_LOCAL_DSN, Constants.ROOT_DB_SPACE_USED);
					Log.info("QOS for DB Local_DSN  ==========================     "+qos.getValue());
					dbLocal_DSN.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.SHARED_MEMORY_FREE)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.DB_LOCAL_DSN, Constants.SHARED_MEMORY_FREE);
					Log.info("QOS for DB Local_DSN  ==========================     "+qos.getValue());
					dbLocal_DSN.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.SHARED_MEMORY_USED)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.DB_LOCAL_DSN, Constants.SHARED_MEMORY_USED);
					Log.info("QOS for DB Local_DSN  ==========================     "+qos.getValue());
					dbLocal_DSN.setMetric((MetricDef) metric,qos.getValue());
				}
			}
		}
	}
	public static void setQosForAxlMemory(Map<String,List<QOS>> axlMap,SnmpCreditionals snmpCreditionals,Folder axlGlobalFolder,InventoryDataset inventoryDataset) throws NimException, InterruptedException{
		final Set<String> descList=axlMap.keySet();
		for(final String description:descList ){
			Log.info("Description For Memory ==========================     "+description);
			final MemoryAXL memory = MemoryAXL.addInstance(inventoryDataset, new EntityId(axlGlobalFolder, description), description, axlGlobalFolder);
			final List<QOS> qosList = axlMap.get(description);
			for (final QOS qos : qosList) {
				if(qos.getKey().equalsIgnoreCase(Constants.MEMORY_USED_DESCRIPTION)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.MEMORY_AXL, Constants.MEMORY_USED);
					Log.info("QOS for Memory  ==========================     "+qos.getValue());
					memory.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.PAGE_USED_DESCRIPTION)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.MEMORY_AXL, Constants.PAGE_USED);
					Log.info("QOS for Memory  ==========================     "+qos.getValue());
					memory.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.VM_USED_DESCRIPTION)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.MEMORY_AXL, Constants.VM_USED);
					Log.info("QOS for Memory  ==========================     "+qos.getValue());
					memory.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.BUFFERS_K_BYTES_DESCRIPTION)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.MEMORY_AXL, Constants.BUFFERS_K_BYTES);
					Log.info("QOS for Memory  ==========================     "+qos.getValue());
					memory.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.CACHED_K_BYTES_DESCRIPTION)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.MEMORY_AXL, Constants.CACHED_K_BYTES);
					Log.info("QOS for Memory  ==========================     "+qos.getValue());
					memory.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.FREE_K_BYTES_DESCRIPTION)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.MEMORY_AXL, Constants.FREE_K_BYTES);
					Log.info("QOS for Memory  ==========================     "+qos.getValue());
					memory.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.FREE_SWAP_K_BYTES_DESCRIPTION)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.MEMORY_AXL, Constants.FREE_SWAP_K_BYTES);
					Log.info("QOS for Memory  ==========================     "+qos.getValue());
					memory.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.HIGH_FREE)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.MEMORY_AXL, Constants.HIGH_FREE);
					Log.info("QOS for Memory  ==========================     "+qos.getValue());
					memory.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.HIGH_TOTAL)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.MEMORY_AXL, Constants.HIGH_TOTAL);
					Log.info("QOS for Memory  ==========================     "+qos.getValue());
					memory.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.LOW_FREE_DESCRIPTION)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.MEMORY_AXL, Constants.LOW_FREE);
					Log.info("QOS for Memory  ==========================     "+qos.getValue());
					memory.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.LOW_TOTAL_DESCRIPTION)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.MEMORY_AXL, Constants.LOW_TOTAL);
					Log.info("QOS for Memory  ==========================     "+qos.getValue());
					memory.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.PAGE_FAULTS_PER_SEC_DESCRIPTION)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.MEMORY_AXL, Constants.PAGE_FAULTS_PER_SEC);
					Log.info("QOS for Memory  ==========================     "+qos.getValue());
					memory.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.PAGE_MAJOR_FAULTS_PER_SEC_DESCRIPTION)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.MEMORY_AXL, Constants.PAGE_MAJOR_FAULTS_PER_SEC);
					Log.info("QOS for Memory  ==========================     "+qos.getValue());
					memory.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.PAGES)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.MEMORY_AXL, Constants.PAGES);
					Log.info("QOS for Memory  ==========================     "+qos.getValue());
					memory.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.PAGES_INPUT_DESCRIPTION)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.MEMORY_AXL, Constants.PAGES_INPUT);
					Log.info("QOS for Memory  ==========================     "+qos.getValue());
					memory.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.PAGES_INPUT_PER_SEC_DESCRIPTION)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.MEMORY_AXL, Constants.PAGES_INPUT_PER_SEC);
					Log.info("QOS for Memory  ==========================     "+qos.getValue());
					memory.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.PAGES_OUTPUT_DESCRIPTION)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.MEMORY_AXL, Constants.PAGES_OUTPUT);
					Log.info("QOS for Memory  ==========================     "+qos.getValue());
					memory.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.PAGES_OUTPUT_PER_SEC_DESCRIPTION)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.MEMORY_AXL, Constants.PAGES_OUTPUT_PER_SEC);
					Log.info("QOS for Memory  ==========================     "+qos.getValue());
					memory.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.SHARED_K_BYTES_DESCRIPTION)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.MEMORY_AXL, Constants.SHARED_K_BYTES);
					Log.info("QOS for Memory  ==========================     "+qos.getValue());
					memory.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.SLAB_CACHE)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.MEMORY_AXL, Constants.SLAB_CACHE);
					Log.info("QOS for Memory  ==========================     "+qos.getValue());
					memory.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.SWAP_CACHED)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.MEMORY_AXL, Constants.SWAP_CACHED);
					Log.info("QOS for Memory  ==========================     "+qos.getValue());
					memory.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.TOTAL_K_BYTES_DESCRIPTION)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.MEMORY_AXL, Constants.TOTAL_K_BYTES);
					Log.info("QOS for Memory  ==========================     "+qos.getValue());
					memory.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.TOTAL_SWAP_K_BYTES_DESCRIPTION)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.MEMORY_AXL, Constants.TOTAL_SWAP_K_BYTES);
					Log.info("QOS for Memory  ==========================     "+qos.getValue());
					memory.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.TOTAL_VM_K_BYTES_DESCRIPTION)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.MEMORY_AXL, Constants.TOTAL_VM_K_BYTES);
					Log.info("QOS for Memory  ==========================     "+qos.getValue());
					memory.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.USED_K_BYTES_DESCRIPTION)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.MEMORY_AXL, Constants.USED_K_BYTES);
					Log.info("QOS for Memory  ==========================     "+qos.getValue());
					memory.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.USED_SWAP_K_BYTES_DESCRIPTION)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.MEMORY_AXL, Constants.USED_SWAP_K_BYTES);
					Log.info("QOS for Memory  ==========================     "+qos.getValue());
					memory.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.USED_VM_K_BYTES_DESCRIPTION)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.MEMORY_AXL, Constants.USED_VM_K_BYTES);
					Log.info("QOS for Memory  ==========================     "+qos.getValue());
					memory.setMetric((MetricDef) metric,qos.getValue());
				}
			}
		}
	}
	public static void setQosForAxlPartition(Map<String,List<QOS>> axlMap,SnmpCreditionals snmpCreditionals,Folder axlGlobalFolder,InventoryDataset inventoryDataset) throws NimException, InterruptedException{
		final Set<String> descList=axlMap.keySet();
		for(final String description:descList ){
			Log.info("Description For Partition ==========================     "+description);
			final Partition partition = Partition.addInstance(inventoryDataset, new EntityId(axlGlobalFolder, description), description, axlGlobalFolder);
			final List<QOS> qosList = axlMap.get(description);
			for (final QOS qos : qosList) {
				if(qos.getKey().equalsIgnoreCase(Constants.CPU_TIME_DESCRIPTION)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.PARTITION, Constants.CPU_TIME);
					Log.info("QOS for Partition  ==========================     "+qos.getValue());
					partition.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.USED_DESCRIPTION)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.PARTITION, Constants.USED);
					Log.info("QOS for Partition  ==========================     "+qos.getValue());
					partition.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.WAIT_IN_READ_DESCRIPTION)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.PARTITION, Constants.WAIT_IN_READ);
					Log.info("QOS for Partition  ==========================     "+qos.getValue());
					partition.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.WAIT_IN_WRITE_DESCRIPTION)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.PARTITION, Constants.WAIT_IN_WRITE);
					Log.info("QOS for Partition  ==========================     "+qos.getValue());
					partition.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.AWAIT_READ_TIME_DESCRIPTION)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.PARTITION, Constants.AWAIT_READ_TIME);
					Log.info("QOS for Partition  ==========================     "+qos.getValue());
					partition.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.AWAIT_TIME_DESCRIPTION)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.PARTITION, Constants.AWAIT_TIME);
					Log.info("QOS for Partition  ==========================     "+qos.getValue());
					partition.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.AWAIT_WRITE_TIME_DESCRIPTION)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.PARTITION, Constants.AWAIT_WRITE_TIME);
					Log.info("QOS for Partition  ==========================     "+qos.getValue());
					partition.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.QUEUE_LENGTH_DESCRIPTION)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.PARTITION, Constants.QUEUE_LENGTH);
					Log.info("QOS for Partition  ==========================     "+qos.getValue());
					partition.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.READ_BYTES_PER_SEC_DESCRIPTION)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.PARTITION, Constants.READ_BYTES_PER_SEC);
					Log.info("QOS for Partition  ==========================     "+qos.getValue());
					partition.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.TOTAL_M_BYTES_DESCRIPTION)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.PARTITION, Constants.TOTAL_M_BYTES);
					Log.info("QOS for Partition  ==========================     "+qos.getValue());
					partition.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.USED_M_BYTES_DESCRIPTION)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.PARTITION, Constants.USED_M_BYTES);
					Log.info("QOS for Partition  ==========================     "+qos.getValue());
					partition.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.WRITE_BYTES_PER_SEC_DESCRIPTION)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.PARTITION, Constants.WRITE_BYTES_PER_SEC);
					Log.info("QOS for Partition  ==========================     "+qos.getValue());
					partition.setMetric((MetricDef) metric,qos.getValue());
				}
			}
		}
	}
	public static void setQosForAxlSystem(Map<String,List<QOS>> axlMap,SnmpCreditionals snmpCreditionals,Folder axlGlobalFolder,InventoryDataset inventoryDataset) throws NimException, InterruptedException{
		final Set<String> descList=axlMap.keySet();
		for(final String description:descList ){
			Log.info("Description For System ==========================     "+description);
			final SystemAXL system = SystemAXL.addInstance(inventoryDataset, new EntityId(axlGlobalFolder, description), description, axlGlobalFolder);
			final List<QOS> qosList = axlMap.get(description);
			for (final QOS qos : qosList) {
				if(qos.getKey().equalsIgnoreCase(Constants.ALLOCATED_FDS_DESCRIPTION)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.SYSTEM_AXL, Constants.ALLOCATED_FDS);
					Log.info("QOS for System  ==========================     "+qos.getValue());
					system.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.BEING_USED_FDS_DESCRIPTION)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.SYSTEM_AXL, Constants.BEING_USED_FDS);
					Log.info("QOS for System  ==========================     "+qos.getValue());
					system.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.FREED_FDS_DESCRIPTION)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.SYSTEM_AXL, Constants.FREED_FDS);
					Log.info("QOS for System  ==========================     "+qos.getValue());
					system.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.IO_AWAIT)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.SYSTEM_AXL, Constants.IO_AWAIT);
					Log.info("QOS for System  ==========================     "+qos.getValue());
					system.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.IO_CPU_UTIL)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.SYSTEM_AXL, Constants.IO_CPU_UTIL);
					Log.info("QOS for System  ==========================     "+qos.getValue());
					system.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.IO_K_BYTES_READ_PER_SECOND)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.SYSTEM_AXL, Constants.IO_K_BYTES_READ_PER_SECOND);
					Log.info("QOS for System  ==========================     "+qos.getValue());
					system.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.IO_K_BYTES_WRITTEN_PER_SECOND)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.SYSTEM_AXL, Constants.IO_K_BYTES_WRITTEN_PER_SECOND);
					Log.info("QOS for System  ==========================     "+qos.getValue());
					system.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.IO_PER_SECOND)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.SYSTEM_AXL, Constants.IO_PER_SECOND);
					Log.info("QOS for System  ==========================     "+qos.getValue());
					system.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.IO_READ_REQ_MERGED_PER_SECOND)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.SYSTEM_AXL, Constants.IO_READ_REQ_MERGED_PER_SECOND);
					Log.info("QOS for System  ==========================     "+qos.getValue());
					system.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.IO_READ_REQ_PER_SECOND)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.SYSTEM_AXL, Constants.IO_READ_REQ_PER_SECOND);
					Log.info("QOS for System  ==========================     "+qos.getValue());
					system.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.IO_REQ_QUEUE_SIZE_AVG)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.SYSTEM_AXL, Constants.IO_REQ_QUEUE_SIZE_AVG);
					Log.info("QOS for System  ==========================     "+qos.getValue());
					system.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.IO_SECTORS_READ_PER_SECOND)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.SYSTEM_AXL, Constants.IO_SECTORS_READ_PER_SECOND);
					Log.info("QOS for System  ==========================     "+qos.getValue());
					system.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.IO_SECTORS_REQ_SIZE_AVG)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.SYSTEM_AXL, Constants.IO_SECTORS_REQ_SIZE_AVG);
					Log.info("QOS for System  ==========================     "+qos.getValue());
					system.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.IO_SECTORS_WRITTEN_PER_SECOND)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.SYSTEM_AXL, Constants.IO_SECTORS_WRITTEN_PER_SECOND);
					Log.info("QOS for System  ==========================     "+qos.getValue());
					system.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.IO_SERVICE_TIME)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.SYSTEM_AXL, Constants.IO_SERVICE_TIME);
					Log.info("QOS for System  ==========================     "+qos.getValue());
					system.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.IO_WRITE_REQ_MERGED_PER_SECOND)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.SYSTEM_AXL, Constants.IO_WRITE_REQ_MERGED_PER_SECOND);
					Log.info("QOS for System  ==========================     "+qos.getValue());
					system.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.IO_WRITE_REQ_PER_SECOND)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.SYSTEM_AXL, Constants.IO_WRITE_REQ_PER_SECOND);
					Log.info("QOS for System  ==========================     "+qos.getValue());
					system.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.MAX_FDS_DESCRIPTION)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.SYSTEM_AXL, Constants.MAX_FDS);
					Log.info("QOS for System  ==========================     "+qos.getValue());
					system.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.TOTAL_CPU_TIME_DESCRIPTION)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.SYSTEM_AXL, Constants.TOTAL_CPU_TIME);
					Log.info("QOS for System  ==========================     "+qos.getValue());
					system.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.TOTAL_PROCESSED_DESCRIPTION)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.SYSTEM_AXL, Constants.TOTAL_PROCESSED);
					Log.info("QOS for System  ==========================     "+qos.getValue());
					system.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.TOTAL_THREADS)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.SYSTEM_AXL, Constants.TOTAL_THREADS);
					Log.info("QOS for System  ==========================     "+qos.getValue());
					system.setMetric((MetricDef) metric,qos.getValue());
				}
			}
		}
	}
	public static void setQosForAxlTCP(Map<String,List<QOS>> axlMap,SnmpCreditionals snmpCreditionals,Folder axlGlobalFolder,InventoryDataset inventoryDataset) throws NimException, InterruptedException{
		final Set<String> descList=axlMap.keySet();
		for(final String description:descList ){
			Log.info("Description For TCP ==========================     "+description);
			final TCP tcp = TCP.addInstance(inventoryDataset, new EntityId(axlGlobalFolder, description), description, axlGlobalFolder);
			final List<QOS> qosList = axlMap.get(description);
			for (final QOS qos : qosList) {
				if(qos.getKey().equalsIgnoreCase(Constants.ACTIVE_OPENS_DESCRIPTION)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.TCP, Constants.ACTIVE_OPENS);
					Log.info("QOS for TCP  ==========================     "+qos.getValue());
					tcp.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.CURR_ESTAB_DESCRIPTION)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.TCP, Constants.CURR_ESTAB);
					Log.info("QOS for TCP  ==========================     "+qos.getValue());
					tcp.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.ESTAB_RESETS_DESCRIPTION)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.TCP, Constants.ESTAB_RESETS);
					Log.info("QOS for TCP  ==========================     "+qos.getValue());
					tcp.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.IN_SEGS_DESCRIPTION)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.TCP, Constants.IN_SEGS);
					Log.info("QOS for TCP  ==========================     "+qos.getValue());
					tcp.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.IN_OUT_SEGS_DESCRIPTION)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.TCP, Constants.IN_OUT_SEGS);
					Log.info("QOS for TCP  ==========================     "+qos.getValue());
					tcp.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.OUT_SEGS_DESCRIPTION)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.TCP, Constants.OUT_SEGS);
					Log.info("QOS for TCP  ==========================     "+qos.getValue());
					tcp.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.PASSIVE_OPENS_DESCRIPTION)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.TCP, Constants.PASSIVE_OPENS);
					Log.info("QOS for TCP  ==========================     "+qos.getValue());
					tcp.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.RETRANS_SEGS_DESCRIPTION)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.TCP, Constants.RETRANS_SEGS);
					Log.info("QOS for TCP  ==========================     "+qos.getValue());
					tcp.setMetric((MetricDef) metric,qos.getValue());
				}
			}
		}
	}
	public static void setQosForAxlThread(Map<String,List<QOS>> axlMap,SnmpCreditionals snmpCreditionals,Folder axlGlobalFolder,InventoryDataset inventoryDataset) throws NimException, InterruptedException{
		final Set<String> descList=axlMap.keySet();
		for(final String description:descList ){
			Log.info("Description For Thread ==========================     "+description);
			final EnterpriseReplicationDBSpaceMonitors enterpriseReplicationDBSpaceMonitors = EnterpriseReplicationDBSpaceMonitors.addInstance(inventoryDataset, new EntityId(axlGlobalFolder, description), description, axlGlobalFolder);
			final List<QOS> qosList = axlMap.get(description);
			for (final QOS qos : qosList) {
				if(qos.getKey().equalsIgnoreCase(Constants.CPU_TIME)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.THREAD, Constants.CPU_TIME);
					Log.info("QOS for Thread  ==========================     "+qos.getValue());
					enterpriseReplicationDBSpaceMonitors.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.PID)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.THREAD, Constants.PID);
					Log.info("QOS for Thread  ==========================     "+qos.getValue());
					enterpriseReplicationDBSpaceMonitors.setMetric((MetricDef) metric,qos.getValue());
				}
			}
		}
	}
	public static void setQosForAxlCiscoCallManager(Map<String,List<QOS>> axlMap,SnmpCreditionals snmpCreditionals,Folder axlGlobalFolder,InventoryDataset inventoryDataset) throws NimException, InterruptedException{
		final Set<String> descList=axlMap.keySet();
		for(final String description:descList ){
			Log.info("Description For Cisco CallManager ==========================     "+description);
			final CiscoCallManager ciscoCallManager = CiscoCallManager.addInstance(inventoryDataset, new EntityId(axlGlobalFolder, description), description, axlGlobalFolder);
			final List<QOS> qosList = axlMap.get(description);
			for (final QOS qos : qosList) {
				if(qos.getKey().equalsIgnoreCase(Constants.ANNUCIATOR_OUT_OF_RESOURCES)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.ANNUCIATOR_OUT_OF_RESOURCES);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.ANNUCIATOR_RESOURCE_ACTIVE)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.ANNUCIATOR_RESOURCE_ACTIVE);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.ANNUCIATOR_RESOURCE_AVAILABLE)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.ANNUCIATOR_RESOURCE_AVAILABLE);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.ANNUCIATOR_RESOURCE_TOTAL)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.ANNUCIATOR_RESOURCE_TOTAL);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.AUTHENTICATED_CALLS_ACTIVE)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.AUTHENTICATED_CALLS_ACTIVE);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.AUTHENTICATED_CALLS_COMPLETED)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.AUTHENTICATED_CALLS_COMPLETED);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.AUTHENTICATED_PARTIALLY_REGISTERED_PHONE)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.AUTHENTICATED_PARTIALLY_REGISTERED_PHONE);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.AUTHENTICATED_REGISTERED_PHONES)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.AUTHENTICATED_REGISTERED_PHONES);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.BRI_CHANNELS_ACTIVE)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.BRI_CHANNELS_ACTIVE);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.BRI_SPANS_IN_SERVICE)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.BRI_SPANS_IN_SERVICE);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.CALL_MANAGER_HEART_BEAT)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.CALL_MANAGER_HEART_BEAT);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.CALLS_ACTIVE)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.CALLS_ACTIVE);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.CALLS_ATTEMPTED)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.CALLS_ATTEMPTED);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.CALLS_COMPLETED)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.CALLS_COMPLETED);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.CALLS_IN_PROGRESS)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.CALLS_IN_PROGRESS);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.CUMULATIVE_ALLOCATED_RESOURCE_CANNOT_OPEN_PORT)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.CUMULATIVE_ALLOCATED_RESOURCE_CANNOT_OPEN_PORT);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.ENCRYPTED_CALLS_ACTIVE)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.ENCRYPTED_CALLS_ACTIVE);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.ENCRYPTED_CALLS_COMPLETED)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.ENCRYPTED_CALLS_COMPLETED);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.ENCRYPTED_PARTIALLY_REGISTERED_PHONES)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.ENCRYPTED_PARTIALLY_REGISTERED_PHONES);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.ENCRYPTED_REGISTERED_PHONES)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.ENCRYPTED_REGISTERED_PHONES);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.EXTERNAL_CALL_CONTROL_ENABLED_CALLS_ATTEMPTED)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.EXTERNAL_CALL_CONTROL_ENABLED_CALLS_ATTEMPTED);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.EXTERNAL_CALL_CONTROL_ENABLED_CALLS_COMPLTED)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.EXTERNAL_CALL_CONTROL_ENABLED_CALLS_COMPLTED);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.EXTERNAL_CALL_CONTROL_ENABLED_FAILURE_TREATMENT_APPLIED)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.EXTERNAL_CALL_CONTROL_ENABLED_FAILURE_TREATMENT_APPLIED);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.FXO_PORTS_ACTIVE)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.FXO_PORTS_ACTIVE);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.FXO_PORTS_IN_SERVICE)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.FXO_PORTS_IN_SERVICE);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.FXS_PORTS_ACTIVE)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.FXS_PORTS_ACTIVE);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.FXS_PORTS_IN_SERVICE)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.FXS_PORTS_IN_SERVICE);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.HW_CONFERENCE_ACTIVE)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.HW_CONFERENCE_ACTIVE);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.HW_CONFERENCE_COMPLETED)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.HW_CONFERENCE_COMPLETED);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.HW_CONFERENCE_OUT_OF_RESOURCES)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.HW_CONFERENCE_OUT_OF_RESOURCES);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.HW_CONFERENCE_RESOURCE_ACTIVE)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.HW_CONFERENCE_RESOURCE_ACTIVE);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.HW_CONFERENCE_RESOURCE_AVAILABLE)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.HW_CONFERENCE_RESOURCE_AVAILABLE);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.HW_CONFERENCE_RESOURCE_TOTAL)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.HW_CONFERENCE_RESOURCE_TOTAL);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.HUNT_LISTS_IN_SERVICE)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.HUNT_LISTS_IN_SERVICE);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.INITIALIZATION_STATE)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.INITIALIZATION_STATE);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.LOCATION_OUT_OF_RESOURCES)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.LOCATION_OUT_OF_RESOURCES);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.MCU_CONFERENCE_ACTIVE)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.MCU_CONFERENCE_ACTIVE);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.MCU_CONFERENCE_COMPLETED)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.MCU_CONFERENCE_COMPLETED);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.MCU_HTTP_CONNECTION_ERRORS)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.MCU_HTTP_CONNECTION_ERRORS);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.MCU_HTTP_NON_200_OK_RESPONSE)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.MCU_HTTP_NON_200_OK_RESPONSE);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.MCU_OUT_OR_RESOURCES)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.MCU_OUT_OR_RESOURCES);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.MOH_MULTICAST_RESOURCE_ACTIVE)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.MOH_MULTICAST_RESOURCE_ACTIVE);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.MOH_MULTICAST_RESOURCE_AVAILABLE)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.MOH_MULTICAST_RESOURCE_AVAILABLE);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.MOH_OUT_OF_RESOURCES)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.MOH_OUT_OF_RESOURCES);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.MOH_TOTAL_MULTICAST_RESOURCES)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.MOH_TOTAL_MULTICAST_RESOURCES);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.MOH_TOTAL_UNICAST_RESOURCES)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.MOH_TOTAL_UNICAST_RESOURCES);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.MOH_UNICAST_RESOURCE_ACTIVE)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.MOH_UNICAST_RESOURCE_ACTIVE);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.MOH_UNICAST_RESOURCE_AVAILABLE)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.MOH_UNICAST_RESOURCE_AVAILABLE);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.MTP_OUT_OF_RESOURCES)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.MTP_OUT_OF_RESOURCES);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.MTP_REQUESTS_THROTTLED)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.MTP_REQUESTS_THROTTLED);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.MTP_RESOURCE_ACTIVE)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.MTP_RESOURCE_ACTIVE);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.MTP_RESOURCE_AVAILABLE)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.MTP_RESOURCE_AVAILABLE);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.MTP_RESOURCE_TOTAL)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.MTP_RESOURCE_TOTAL);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.PRI_CHANNELS_ACTIVE)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.PRI_CHANNELS_ACTIVE);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.PRI_SPANS_IN_SERVICE)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.PRI_SPANS_IN_SERVICE);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.PARTIALLY_REGISTERED_PHONE)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.PARTIALLY_REGISTERED_PHONE);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.REGISTERED_ANALOG_ACCESS)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.REGISTERED_ANALOG_ACCESS);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.REGISTERED_HARDWARE_PHONES)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.REGISTERED_HARDWARE_PHONES);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.REGISTERED_MGCP_GATEWAY)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.REGISTERED_MGCP_GATEWAY);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.REGISTERED_OTHER_STATION_DEVICES)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.REGISTERED_OTHER_STATION_DEVICES);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.SIP_LINE_SERVER_AUTHORIZATION_CHALLENGES)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.SIP_LINE_SERVER_AUTHORIZATION_CHALLENGES);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.SIP_LINE_SERVER_AUTHORIZATION_FAILURES)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.SIP_LINE_SERVER_AUTHORIZATION_FAILURES);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.SIP_TRUNK_APPLICATION_AUTHORIZATION_FAILURES)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.SIP_TRUNK_APPLICATION_AUTHORIZATION_FAILURES);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.SIP_TRUNK_APPLICATION_AUTHORIZATIONS)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.SIP_TRUNK_APPLICATION_AUTHORIZATIONS);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.SIP_TRUNK_AUTHORIZATION_FAILURES)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.SIP_TRUNK_AUTHORIZATION_FAILURES);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.SIP_TRUNK_AUTHORIZATIONS)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.SIP_TRUNK_AUTHORIZATIONS);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.SIP_TRUNK_SERVER_AUTHENTICATION_CHALLENGES)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.SIP_TRUNK_SERVER_AUTHENTICATION_CHALLENGES);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.SIP_TRUNK_SERVER_AUTHENTICATION_FAILURES)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.SIP_TRUNK_SERVER_AUTHENTICATION_FAILURES);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.SW_CONFERENCE_ACTIVE)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.SW_CONFERENCE_ACTIVE);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.SW_CONFERENCE_COMPLETED)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.SW_CONFERENCE_COMPLETED);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.SW_CONFERENCE_OUT_OF_RESOURCES)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.SW_CONFERENCE_OUT_OF_RESOURCES);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.SW_CONFERENCE_RESOURCE_ACTIVE)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.SW_CONFERENCE_RESOURCE_ACTIVE);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.SW_CONFERENCE_RESOURCE_AVAILABLE)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.SW_CONFERENCE_RESOURCE_AVAILABLE);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.SW_CONFERENCE_RESOURCE_TOTAL)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.SW_CONFERENCE_RESOURCE_TOTAL);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.SYSTEM_CALLS_ATTEMPTED)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.SYSTEM_CALLS_ATTEMPTED);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.T1_CHANNELS_ACTIVE)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.T1_CHANNELS_ACTIVE);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.T1_SPANS_IN_SERVICE)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.T1_SPANS_IN_SERVICE);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.TLS_CONNECTED_SIP_TRUNKS)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.TLS_CONNECTED_SIP_TRUNKS);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.TLS_CONNECTED_WSM)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.TLS_CONNECTED_WSM);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.TRANSCODER_OUT_OF_RESOURCES)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.TRANSCODER_OUT_OF_RESOURCES);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.TRANSCODER_REQUESTS_THROTTLED)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.TRANSCODER_REQUESTS_THROTTLED);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.TRANSCODER_RESOURCE_ACTIVE)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.TRANSCODER_RESOURCE_ACTIVE);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.TRANSCODER_RESOURCE_AVAILABLE)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.TRANSCODER_RESOURCE_AVAILABLE);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.TRANSCODER_RESOURCE_TOTAL)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.TRANSCODER_RESOURCE_TOTAL);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.VCB_CONFERENCES_ACTIVE)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.VCB_CONFERENCES_ACTIVE);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.VCB_CONFERENCES_AVAILABLE)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.VCB_CONFERENCES_AVAILABLE);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.VCB_CONFERENCES_COMPLETED)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.VCB_CONFERENCES_COMPLETED);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.VCB_CONFERENCES_TOTAL)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.VCB_CONFERENCES_TOTAL);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.VCB_OUT_OF_CONFERENCES)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.VCB_OUT_OF_CONFERENCES);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.VCB_OUT_OF_RESOURCES)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.VCB_OUT_OF_RESOURCES);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.VCB_RESOURCE_ACTIVE)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.VCB_RESOURCE_ACTIVE);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.VCB_RESOURCE_AVAILABLE)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.VCB_RESOURCE_AVAILABLE);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.VCB_RESOURCE_TOTAL)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.VCB_RESOURCE_TOTAL);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.VIDEO_CALLS_ACTIVE)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.VIDEO_CALLS_ACTIVE);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.VIDEO_CALLS_COMPLETED)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.VIDEO_CALLS_COMPLETED);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.VIDEO_OUT_OF_RESOURCES)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_CALLMANAGER, Constants.VIDEO_OUT_OF_RESOURCES);
					Log.info("QOS for Cisco CallManager  ==========================     "+qos.getValue());
					ciscoCallManager.setMetric((MetricDef) metric,qos.getValue());
				}
			}
		}
	}
	public static void setQosForAxlCiscoH323(Map<String,List<QOS>> axlMap,SnmpCreditionals snmpCreditionals,Folder axlGlobalFolder,InventoryDataset inventoryDataset) throws NimException, InterruptedException{
		final Set<String> descList=axlMap.keySet();
		for(final String description:descList ){
			Log.info("Description For Cisco H323 ==========================     "+description);
			final EnterpriseReplicationDBSpaceMonitors enterpriseReplicationDBSpaceMonitors = EnterpriseReplicationDBSpaceMonitors.addInstance(inventoryDataset, new EntityId(axlGlobalFolder, description), description, axlGlobalFolder);
			final List<QOS> qosList = axlMap.get(description);
			for (final QOS qos : qosList) {
				if(qos.getKey().equalsIgnoreCase(Constants.CALLS_ACTIVE)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_H323, Constants.CALLS_ACTIVE);
					Log.info("QOS for Cisco H323  ==========================     "+qos.getValue());
					enterpriseReplicationDBSpaceMonitors.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.CALLS_ATTEMPTED)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_H323, Constants.CALLS_ATTEMPTED);
					Log.info("QOS for Cisco H323  ==========================     "+qos.getValue());
					enterpriseReplicationDBSpaceMonitors.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.CALLS_COMPLETED)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_H323, Constants.CALLS_COMPLETED);
					Log.info("QOS for Cisco H323  ==========================     "+qos.getValue());
					enterpriseReplicationDBSpaceMonitors.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.CALLS_IN_PROGRESS)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_H323, Constants.CALLS_IN_PROGRESS);
					Log.info("QOS for Cisco H323  ==========================     "+qos.getValue());
					enterpriseReplicationDBSpaceMonitors.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.CALLS_REJECTED_DUE_TO_ICT_CALL_THROTTLING)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_H323, Constants.CALLS_REJECTED_DUE_TO_ICT_CALL_THROTTLING);
					Log.info("QOS for Cisco H323  ==========================     "+qos.getValue());
					enterpriseReplicationDBSpaceMonitors.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.VIDEO_CALLS_ACTIVE)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_H323, Constants.VIDEO_CALLS_ACTIVE);
					Log.info("QOS for Cisco H323  ==========================     "+qos.getValue());
					enterpriseReplicationDBSpaceMonitors.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.VIDEO_CALLS_COMPLETED)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_H323, Constants.VIDEO_CALLS_COMPLETED);
					Log.info("QOS for Cisco H323  ==========================     "+qos.getValue());
					enterpriseReplicationDBSpaceMonitors.setMetric((MetricDef) metric,qos.getValue());
				}
			}
		}
	}
	public static void setQosForAxlCiscoMGCPFXODevice(Map<String,List<QOS>> axlMap,SnmpCreditionals snmpCreditionals,Folder axlGlobalFolder,InventoryDataset inventoryDataset) throws NimException, InterruptedException{
		final Set<String> descList=axlMap.keySet();
		for(final String description:descList ){
			Log.info("Description For Cisco MGCP FXO Device ==========================     "+description);
			final EnterpriseReplicationDBSpaceMonitors enterpriseReplicationDBSpaceMonitors = EnterpriseReplicationDBSpaceMonitors.addInstance(inventoryDataset, new EntityId(axlGlobalFolder, description), description, axlGlobalFolder);
			final List<QOS> qosList = axlMap.get(description);
			for (final QOS qos : qosList) {
				if(qos.getKey().equalsIgnoreCase(Constants.CALLS_COMPLETED)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_MGCP_FXO_DEVICE, Constants.CALLS_COMPLETED);
					Log.info("QOS for Cisco MGCP FXO Device  ==========================     "+qos.getValue());
					enterpriseReplicationDBSpaceMonitors.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.OUTBOUND_BUSY_ATTEMPTS)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_MGCP_FXO_DEVICE, Constants.OUTBOUND_BUSY_ATTEMPTS);
					Log.info("QOS for Cisco MGCP FXO Device  ==========================     "+qos.getValue());
					enterpriseReplicationDBSpaceMonitors.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.PORT_STATUS)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_MGCP_FXO_DEVICE, Constants.PORT_STATUS);
					Log.info("QOS for Cisco MGCP FXO Device  ==========================     "+qos.getValue());
					enterpriseReplicationDBSpaceMonitors.setMetric((MetricDef) metric,qos.getValue());
				}
			}
		}
	}
	public static void setQosForAxlCiscoMGCPFXSDevice(Map<String,List<QOS>> axlMap,SnmpCreditionals snmpCreditionals,Folder axlGlobalFolder,InventoryDataset inventoryDataset) throws NimException, InterruptedException{
		final Set<String> descList=axlMap.keySet();
		for(final String description:descList ){
			Log.info("Description For Cisco MGCP FXS Device ==========================     "+description);
			final EnterpriseReplicationDBSpaceMonitors enterpriseReplicationDBSpaceMonitors = EnterpriseReplicationDBSpaceMonitors.addInstance(inventoryDataset, new EntityId(axlGlobalFolder, description), description, axlGlobalFolder);
			final List<QOS> qosList = axlMap.get(description);
			for (final QOS qos : qosList) {
				if(qos.getKey().equalsIgnoreCase(Constants.CALLS_COMPLETED)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_MGCP_FXS_DEVICE, Constants.CALLS_COMPLETED);
					Log.info("QOS for Cisco MGCP FXS Device  ==========================     "+qos.getValue());
					enterpriseReplicationDBSpaceMonitors.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.OUTBOUND_BUSY_ATTEMPTS)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_MGCP_FXS_DEVICE, Constants.OUTBOUND_BUSY_ATTEMPTS);
					Log.info("QOS for Cisco MGCP FXS Device  ==========================     "+qos.getValue());
					enterpriseReplicationDBSpaceMonitors.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.PORT_STATUS)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_MGCP_FXS_DEVICE, Constants.PORT_STATUS);
					Log.info("QOS for Cisco MGCP FXS Device  ==========================     "+qos.getValue());
					enterpriseReplicationDBSpaceMonitors.setMetric((MetricDef) metric,qos.getValue());
				}
			}
		}
	}
	public static void setQosForAxlCiscoMGCPGateways(Map<String,List<QOS>> axlMap,SnmpCreditionals snmpCreditionals,Folder axlGlobalFolder,InventoryDataset inventoryDataset) throws NimException, InterruptedException{
		final Set<String> descList=axlMap.keySet();
		for(final String description:descList ){
			Log.info("Description For Cisco MGCP Gateways ==========================     "+description);
			final EnterpriseReplicationDBSpaceMonitors enterpriseReplicationDBSpaceMonitors = EnterpriseReplicationDBSpaceMonitors.addInstance(inventoryDataset, new EntityId(axlGlobalFolder, description), description, axlGlobalFolder);
			final List<QOS> qosList = axlMap.get(description);
			for (final QOS qos : qosList) {
				if(qos.getKey().equalsIgnoreCase(Constants.BRI_CHANNELS_ACTIVE)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_MGCP_GATEWAYS, Constants.BRI_CHANNELS_ACTIVE);
					Log.info("QOS for Cisco MGCP Gateways  ==========================     "+qos.getValue());
					enterpriseReplicationDBSpaceMonitors.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.BRI_SPANS_IN_SERVICE)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_MGCP_GATEWAYS, Constants.OUTBOUND_BUSY_ATTEMPTS);
					Log.info("QOS for Cisco MGCP Gateways  ==========================     "+qos.getValue());
					enterpriseReplicationDBSpaceMonitors.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.FXO_PORTS_ACTIVE)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_MGCP_GATEWAYS, Constants.FXO_PORTS_ACTIVE);
					Log.info("QOS for Cisco MGCP Gateways  ==========================     "+qos.getValue());
					enterpriseReplicationDBSpaceMonitors.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.FXO_PORTS_IN_SERVICE)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_MGCP_GATEWAYS, Constants.FXO_PORTS_IN_SERVICE);
					Log.info("QOS for Cisco MGCP Gateways  ==========================     "+qos.getValue());
					enterpriseReplicationDBSpaceMonitors.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.FXS_PORTS_ACTIVE)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_MGCP_GATEWAYS, Constants.FXS_PORTS_ACTIVE);
					Log.info("QOS for Cisco MGCP Gateways  ==========================     "+qos.getValue());
					enterpriseReplicationDBSpaceMonitors.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.FXS_PORTS_IN_SERVICE)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_MGCP_GATEWAYS, Constants.FXS_PORTS_IN_SERVICE);
					Log.info("QOS for Cisco MGCP Gateways  ==========================     "+qos.getValue());
					enterpriseReplicationDBSpaceMonitors.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.PORT_STATUS)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_MGCP_GATEWAYS, Constants.PORT_STATUS);
					Log.info("QOS for Cisco MGCP Gateways  ==========================     "+qos.getValue());
					enterpriseReplicationDBSpaceMonitors.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.PRI_CHANNELS_ACTIVE)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_MGCP_GATEWAYS, Constants.PRI_CHANNELS_ACTIVE);
					Log.info("QOS for Cisco MGCP Gateways  ==========================     "+qos.getValue());
					enterpriseReplicationDBSpaceMonitors.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.PRI_SPANS_IN_SERVICE)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_MGCP_GATEWAYS, Constants.PRI_SPANS_IN_SERVICE);
					Log.info("QOS for Cisco MGCP Gateways  ==========================     "+qos.getValue());
					enterpriseReplicationDBSpaceMonitors.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.T1_CHANNELS_ACTIVE)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_MGCP_GATEWAYS, Constants.T1_CHANNELS_ACTIVE);
					Log.info("QOS for Cisco MGCP Gateways  ==========================     "+qos.getValue());
					enterpriseReplicationDBSpaceMonitors.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.T1_SPANS_IN_SERVICE)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_MGCP_GATEWAYS, Constants.T1_SPANS_IN_SERVICE);
					Log.info("QOS for Cisco MGCP Gateways  ==========================     "+qos.getValue());
					enterpriseReplicationDBSpaceMonitors.setMetric((MetricDef) metric,qos.getValue());
				}
			}
		}
	}
	public static void setQosForAxlCiscoMTPDevice(Map<String,List<QOS>> axlMap,SnmpCreditionals snmpCreditionals,Folder axlGlobalFolder,InventoryDataset inventoryDataset) throws NimException, InterruptedException{
		final Set<String> descList=axlMap.keySet();
		for(final String description:descList ){
			Log.info("Description For Cisco MTP Device ==========================     "+description);
			final EnterpriseReplicationDBSpaceMonitors enterpriseReplicationDBSpaceMonitors = EnterpriseReplicationDBSpaceMonitors.addInstance(inventoryDataset, new EntityId(axlGlobalFolder, description), description, axlGlobalFolder);
			final List<QOS> qosList = axlMap.get(description);
			for (final QOS qos : qosList) {
				if(qos.getKey().equalsIgnoreCase(Constants.OUT_OF_RESOURCES)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_MTP_DEVICE, Constants.OUT_OF_RESOURCES);
					Log.info("QOS for Cisco MTP Device  ==========================     "+qos.getValue());
					enterpriseReplicationDBSpaceMonitors.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.RESOURCE_ACTIVE)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_MTP_DEVICE, Constants.RESOURCE_ACTIVE);
					Log.info("QOS for Cisco MTP Device  ==========================     "+qos.getValue());
					enterpriseReplicationDBSpaceMonitors.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.RESOURCE_AVAILABLE)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_MTP_DEVICE, Constants.RESOURCE_AVAILABLE);
					Log.info("QOS for Cisco MTP Device  ==========================     "+qos.getValue());
					enterpriseReplicationDBSpaceMonitors.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.RESOURCE_TOTAL)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_MTP_DEVICE, Constants.RESOURCE_TOTAL);
					Log.info("QOS for Cisco MTP Device  ==========================     "+qos.getValue());
					enterpriseReplicationDBSpaceMonitors.setMetric((MetricDef) metric,qos.getValue());
				}
			}
		}
	}
	public static void setQosForAxlCiscoPhones(Map<String,List<QOS>> axlMap,SnmpCreditionals snmpCreditionals,Folder axlGlobalFolder,InventoryDataset inventoryDataset) throws NimException, InterruptedException{
		final Set<String> descList=axlMap.keySet();
		for(final String description:descList ){
			Log.info("Description For Cisco Phones ==========================     "+description);
			final EnterpriseReplicationDBSpaceMonitors enterpriseReplicationDBSpaceMonitors = EnterpriseReplicationDBSpaceMonitors.addInstance(inventoryDataset, new EntityId(axlGlobalFolder, description), description, axlGlobalFolder);
			final List<QOS> qosList = axlMap.get(description);
			for (final QOS qos : qosList) {
				if(qos.getKey().equalsIgnoreCase(Constants.CALLS_ATTEMPTED)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_PHONES, Constants.CALLS_ATTEMPTED);
					Log.info("QOS for Cisco Phones  ==========================     "+qos.getValue());
					enterpriseReplicationDBSpaceMonitors.setMetric((MetricDef) metric,qos.getValue());
				}
			}
		}
	}
	public static void setQosForAxlCiscoSIP(Map<String,List<QOS>> axlMap,SnmpCreditionals snmpCreditionals,Folder axlGlobalFolder,InventoryDataset inventoryDataset) throws NimException, InterruptedException{
		final Set<String> descList=axlMap.keySet();
		for(final String description:descList ){
			Log.info("Description For Cisco SIP ==========================     "+description);
			final EnterpriseReplicationDBSpaceMonitors enterpriseReplicationDBSpaceMonitors = EnterpriseReplicationDBSpaceMonitors.addInstance(inventoryDataset, new EntityId(axlGlobalFolder, description), description, axlGlobalFolder);
			final List<QOS> qosList = axlMap.get(description);
			for (final QOS qos : qosList) {
				if(qos.getKey().equalsIgnoreCase(Constants.CALLS_ACTIVE)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_SIP, Constants.CALLS_ACTIVE);
					Log.info("QOS for Cisco SIP  ==========================     "+qos.getValue());
					enterpriseReplicationDBSpaceMonitors.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.CALLS_ATTEMPTED)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_SIP, Constants.CALLS_ATTEMPTED);
					Log.info("QOS for Cisco SIP  ==========================     "+qos.getValue());
					enterpriseReplicationDBSpaceMonitors.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.CALLS_COMPLETED)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_SIP, Constants.CALLS_COMPLETED);
					Log.info("QOS for Cisco SIP  ==========================     "+qos.getValue());
					enterpriseReplicationDBSpaceMonitors.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.CALLS_IN_PROGRESS)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_SIP, Constants.CALLS_IN_PROGRESS);
					Log.info("QOS for Cisco SIP  ==========================     "+qos.getValue());
					enterpriseReplicationDBSpaceMonitors.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.VIDEO_CALLS_ACTIVE)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_SIP, Constants.VIDEO_CALLS_ACTIVE);
					Log.info("QOS for Cisco SIP  ==========================     "+qos.getValue());
					enterpriseReplicationDBSpaceMonitors.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.VIDEO_CALLS_COMPLETED)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_SIP, Constants.VIDEO_CALLS_COMPLETED);
					Log.info("QOS for Cisco SIP  ==========================     "+qos.getValue());
					enterpriseReplicationDBSpaceMonitors.setMetric((MetricDef) metric,qos.getValue());
				}
			}
		}
	}
	public static void setQosForAxlCiscoTFTP(Map<String,List<QOS>> axlMap,SnmpCreditionals snmpCreditionals,Folder axlGlobalFolder,InventoryDataset inventoryDataset) throws NimException, InterruptedException{
		final Set<String> descList=axlMap.keySet();
		for(final String description:descList ){
			Log.info("Description For Cisco TFTP ==========================     "+description);
			final TCP tcp = TCP.addInstance(inventoryDataset, new EntityId(axlGlobalFolder, description), description, axlGlobalFolder);
			final List<QOS> qosList = axlMap.get(description);
			for (final QOS qos : qosList) {
				if(qos.getKey().equalsIgnoreCase(Constants.BUILD_ABORT_COUNT)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_TFTP, Constants.BUILD_ABORT_COUNT);
					Log.info("QOS for Cisco TFTP  ==========================     "+qos.getValue());
					tcp.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.BUILD_COUNT)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_TFTP, Constants.BUILD_COUNT);
					Log.info("QOS for Cisco TFTP  ==========================     "+qos.getValue());
					tcp.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.BUILD_DEVICE_COUNT)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_TFTP, Constants.BUILD_DEVICE_COUNT);
					Log.info("QOS for Cisco TFTP  ==========================     "+qos.getValue());
					tcp.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.BUILD_DIAL_RULE_COUNT)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_TFTP, Constants.BUILD_DIAL_RULE_COUNT);
					Log.info("QOS for Cisco TFTP  ==========================     "+qos.getValue());
					tcp.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.BUILD_DURATION)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_TFTP, Constants.BUILD_DURATION);
					Log.info("QOS for Cisco TFTP  ==========================     "+qos.getValue());
					tcp.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.BUILD_FEATURE_POLICY_COUNT)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_TFTP, Constants.BUILD_FEATURE_POLICY_COUNT);
					Log.info("QOS for Cisco TFTP  ==========================     "+qos.getValue());
					tcp.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.BUILD_SIGN_COUNT)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_TFTP, Constants.BUILD_SIGN_COUNT);
					Log.info("QOS for Cisco TFTP  ==========================     "+qos.getValue());
					tcp.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.BUILD_SOFT_KEY_COUNT)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_TFTP, Constants.BUILD_SOFT_KEY_COUNT);
					Log.info("QOS for Cisco TFTP  ==========================     "+qos.getValue());
					tcp.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.BUILD_UNIT_COUNT)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_TFTP, Constants.BUILD_UNIT_COUNT);
					Log.info("QOS for Cisco TFTP  ==========================     "+qos.getValue());
					tcp.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.CHANGE_NOTIFICATIONS)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_TFTP, Constants.CHANGE_NOTIFICATIONS);
					Log.info("QOS for Cisco TFTP  ==========================     "+qos.getValue());
					tcp.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.DEVICE_CHANGE_NOTIFICATIONS)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_TFTP, Constants.DEVICE_CHANGE_NOTIFICATIONS);
					Log.info("QOS for Cisco TFTP  ==========================     "+qos.getValue());
					tcp.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.DIAL_RULE_CHANGE_NOTIFICATIONS)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_TFTP, Constants.DIAL_RULE_CHANGE_NOTIFICATIONS);
					Log.info("QOS for Cisco TFTP  ==========================     "+qos.getValue());
					tcp.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.ENCRYPT_COUNT)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_TFTP, Constants.ENCRYPT_COUNT);
					Log.info("QOS for Cisco TFTP  ==========================     "+qos.getValue());
					tcp.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.FEATURE_POLICY_CHANGE_NOTIFICATIONS)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_TFTP, Constants.FEATURE_POLICY_CHANGE_NOTIFICATIONS);
					Log.info("QOS for Cisco TFTP  ==========================     "+qos.getValue());
					tcp.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.GK_FOUND_COUNT)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_TFTP, Constants.GK_FOUND_COUNT);
					Log.info("QOS for Cisco TFTP  ==========================     "+qos.getValue());
					tcp.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.GK_NOT_FOUND_COUNT)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_TFTP, Constants.GK_NOT_FOUND_COUNT);
					Log.info("QOS for Cisco TFTP  ==========================     "+qos.getValue());
					tcp.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.HEART_BEAT)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_TFTP, Constants.HEART_BEAT);
					Log.info("QOS for Cisco TFTP  ==========================     "+qos.getValue());
					tcp.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.HTTP_CONNECT_REQUESTS)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_TFTP, Constants.HTTP_CONNECT_REQUESTS);
					Log.info("QOS for Cisco TFTP  ==========================     "+qos.getValue());
					tcp.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.HTTP_REQUESTS)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_TFTP, Constants.HTTP_REQUESTS);
					Log.info("QOS for Cisco TFTP  ==========================     "+qos.getValue());
					tcp.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.HTTP_REQUESTS_ABORTED)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_TFTP, Constants.HTTP_REQUESTS_ABORTED);
					Log.info("QOS for Cisco TFTP  ==========================     "+qos.getValue());
					tcp.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.HTTP_REQUESTS_NOT_FOUND)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_TFTP, Constants.HTTP_REQUESTS_NOT_FOUND);
					Log.info("QOS for Cisco TFTP  ==========================     "+qos.getValue());
					tcp.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.HTTP_REQUESTS_OVERFLOW)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_TFTP, Constants.HTTP_REQUESTS_OVERFLOW);
					Log.info("QOS for Cisco TFTP  ==========================     "+qos.getValue());
					tcp.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.HTTP_REQUESTS_PROCESSED)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_TFTP, Constants.HTTP_REQUESTS_PROCESSED);
					Log.info("QOS for Cisco TFTP  ==========================     "+qos.getValue());
					tcp.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.HTTP_SERVED_FROM_DISK)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_TFTP, Constants.HTTP_SERVED_FROM_DISK);
					Log.info("QOS for Cisco TFTP  ==========================     "+qos.getValue());
					tcp.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.LD_FOUND_COUNT)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_TFTP, Constants.LD_FOUND_COUNT);
					Log.info("QOS for Cisco TFTP  ==========================     "+qos.getValue());
					tcp.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.LD_NOT_FOUND_COUNT)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_TFTP, Constants.LD_NOT_FOUND_COUNT);
					Log.info("QOS for Cisco TFTP  ==========================     "+qos.getValue());
					tcp.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.MAX_SERVING_COUNT)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_TFTP, Constants.MAX_SERVING_COUNT);
					Log.info("QOS for Cisco TFTP  ==========================     "+qos.getValue());
					tcp.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.REQUESTS)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_TFTP, Constants.REQUESTS);
					Log.info("QOS for Cisco TFTP  ==========================     "+qos.getValue());
					tcp.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.REQUESTS_ABORTED)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_TFTP, Constants.REQUESTS_ABORTED);
					Log.info("QOS for Cisco TFTP  ==========================     "+qos.getValue());
					tcp.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.REQUESTS_IN_PROGRESS)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_TFTP, Constants.REQUESTS_IN_PROGRESS);
					Log.info("QOS for Cisco TFTP  ==========================     "+qos.getValue());
					tcp.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.REQUESTS_NOT_FOUND)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_TFTP, Constants.REQUESTS_NOT_FOUND);
					Log.info("QOS for Cisco TFTP  ==========================     "+qos.getValue());
					tcp.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.REQUESTS_OVERFLOW)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_TFTP, Constants.REQUESTS_OVERFLOW);
					Log.info("QOS for Cisco TFTP  ==========================     "+qos.getValue());
					tcp.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.REQUESTS_PROCESSED)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_TFTP, Constants.REQUESTS_PROCESSED);
					Log.info("QOS for Cisco TFTP  ==========================     "+qos.getValue());
					tcp.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.SEP_FOUND_COUNT)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_TFTP, Constants.SEP_FOUND_COUNT);
					Log.info("QOS for Cisco TFTP  ==========================     "+qos.getValue());
					tcp.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.SEP_NOT_FOUND_COUNT)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_TFTP, Constants.SEP_NOT_FOUND_COUNT);
					Log.info("QOS for Cisco TFTP  ==========================     "+qos.getValue());
					tcp.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.SIP_FOUND_COUNT)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_TFTP, Constants.SIP_FOUND_COUNT);
					Log.info("QOS for Cisco TFTP  ==========================     "+qos.getValue());
					tcp.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.SIP_NOT_FOUND_COUNT)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_TFTP, Constants.SIP_NOT_FOUND_COUNT);
					Log.info("QOS for Cisco TFTP  ==========================     "+qos.getValue());
					tcp.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.SEGMENTS_ACKNOWLEDGED)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_TFTP, Constants.SEGMENTS_ACKNOWLEDGED);
					Log.info("QOS for Cisco TFTP  ==========================     "+qos.getValue());
					tcp.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.SEGMENTS_FROM_DISK)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_TFTP, Constants.SEGMENTS_FROM_DISK);
					Log.info("QOS for Cisco TFTP  ==========================     "+qos.getValue());
					tcp.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.SEGMENTS_SENT)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_TFTP, Constants.SEGMENTS_SENT);
					Log.info("QOS for Cisco TFTP  ==========================     "+qos.getValue());
					tcp.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.SOFTKEY_CHANGE_NOTIFICATIONS)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_TFTP, Constants.SOFTKEY_CHANGE_NOTIFICATIONS);
					Log.info("QOS for Cisco TFTP  ==========================     "+qos.getValue());
					tcp.setMetric((MetricDef) metric,qos.getValue());
				}else if(qos.getKey().equalsIgnoreCase(Constants.UNIT_CHANGE_NOTIFICATIONS)){
					final MetricDef metric = getMetricDef(Constants.PACKAGE_COM_NIMSOFT_TYPES+Constants.CISCO_TFTP, Constants.UNIT_CHANGE_NOTIFICATIONS);
					Log.info("QOS for Cisco TFTP  ==========================     "+qos.getValue());
					tcp.setMetric((MetricDef) metric,qos.getValue());
				}
			}
		}
	}

}
