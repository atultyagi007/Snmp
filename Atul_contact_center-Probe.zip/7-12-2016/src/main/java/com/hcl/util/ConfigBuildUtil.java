package com.hcl.util;

import java.util.ArrayList;
import java.util.Map;
import java.util.Set;
import java.util.Vector;
import java.util.concurrent.ConcurrentHashMap;

import org.snmp4j.smi.VariableBinding;

import com.hcl.folder.CCCADistAWTableChild;
import com.hcl.folder.CCCAGeneralInfo; 
import com.hcl.folder.CCCACgTable;
import com.hcl.folder.CCCAInstanceTable;
import com.hcl.folder.CCCALoggerTableChild;
import com.hcl.folder.CCCAPgTableChild;
import com.hcl.folder.CCCAPimTableChild;
import com.hcl.folder.CcmGlobalInfoChild;
import com.hcl.folder.CucmGroupFolder;
import com.hcl.folder.CucmTableChild;
import com.hcl.folder.H323DeviceInfoFolder;
import com.hcl.folder.SystemGlobalFolder;
import com.hcl.probe.Constants;
import com.hcl.probe.OidForm;
import com.hcl.probe.ProbeMain;
import com.hcl.probe.QosForm;
import com.hcl.snmp.SNMPUtils;
import com.hcl.snmp.SnmpCreditionals;
import com.nimsoft.ids.ctd.base.CtdElement;
import com.nimsoft.ids.ctd.base.CtdPropertyDefinition;
import com.nimsoft.ids.ctd.ui.definitions.CtdStringDefinition;
import com.nimsoft.nimbus.NimException;
import com.nimsoft.pf.common.CtdBuilderUtils;
import com.nimsoft.pf.common.graph.GraphHelper;
import com.nimsoft.pf.common.log.Log;
import com.nimsoft.probe.framework.devkit.InventoryDataset;
import com.nimsoft.probe.framework.devkit.inventory.Folder;
import com.nimsoft.probe.framework.devkit.inventory.typedefs.EntityId;
import com.nimsoft.probe.framework.devkit.inventory.typedefs.MetricDef;
import com.nimsoft.types.CCCAPimTable;
import com.nimsoft.types.CCCARouterTable;


public class ConfigBuildUtil {

	public static void buildSystemPropertyConfig(GraphHelper graph) {

		CtdStringDefinition sysObjId = CtdBuilderUtils.buildStringDef(Constants.SYSTEM_OBJECT_ID, Constants.LABEL_SYSTEM_OBJECT_ID);		
		sysObjId.setReadOnly(true);
		sysObjId.setDefaultValue(Constants.NOT_ACCESSIBLE);

		CtdStringDefinition sysDesc = CtdBuilderUtils.buildStringDef(Constants.SYSTEM_DESCRIPTION, Constants.LABEL_DESCRIPTION);		
		sysDesc.setReadOnly(true);
		sysDesc.setDefaultValue(Constants.NOT_ACCESSIBLE);

		CtdStringDefinition sysUpTime = CtdBuilderUtils.buildStringDef(Constants.SYSTEM_UP_TIME, Constants.LABEL_SYSTEM_UP_TIME);		
		sysUpTime.setReadOnly(true);
		sysUpTime.setDefaultValue(Constants.NOT_ACCESSIBLE);		

		CtdStringDefinition sysContact = CtdBuilderUtils.buildStringDef(Constants.SYSTEM_CONTACT, Constants.LABEL_SYSTEM_CONTACT);		
		sysContact.setReadOnly(true);
		sysContact.setDefaultValue(Constants.NOT_ACCESSIBLE);		

		CtdStringDefinition sysName = CtdBuilderUtils.buildStringDef(Constants.SYSTEM_NAME, Constants.LABEL_NAME);		
		sysName.setReadOnly(true);
		sysName.setDefaultValue(Constants.NOT_ACCESSIBLE);

		CtdStringDefinition sysLocation = CtdBuilderUtils.buildStringDef(Constants.SYSTEM_LOCATION, Constants.LABEL_LOCATION);		
		sysLocation.setReadOnly(true);
		sysLocation.setDefaultValue(Constants.NOT_ACCESSIBLE);

		CtdStringDefinition sysServices = CtdBuilderUtils.buildStringDef(Constants.SYSTEM_SERVICES, Constants.LABEL_SYSTEM_SERVICES);		
		sysServices.setReadOnly(true);
		sysServices.setDefaultValue(Constants.NOT_ACCESSIBLE);

		final CtdPropertyDefinition<?>[] propertyDefs = {sysObjId, sysDesc, sysUpTime, sysContact, sysName, sysLocation, sysServices};
		ProbeMain.sysGlobalConfigDef = CtdBuilderUtils.buildConfigDef(Constants.LABEL_SYSTEM_PROPERTY, Constants.SYSTEM_PROPERTY, Constants.SYSTEM_PROPERTY, propertyDefs);		
		graph.addConfigDefinition(ProbeMain.sysGlobalConfigDef);
	}
	
	
	public static void buildCucmGroupTableConfig(GraphHelper graph) {

		CtdStringDefinition cucmGroupName = CtdBuilderUtils.buildStringDef(Constants.CUCM_GROUP_NAME, Constants.LABEL_CUCM_GROUP_NAME);		
		cucmGroupName.setReadOnly(true);
		cucmGroupName.setDefaultValue(Constants.NOT_ACCESSIBLE);
		
		final CtdPropertyDefinition<?>[] propertyDefs = {cucmGroupName};
		ProbeMain.cucmGroupTableConfigDef = CtdBuilderUtils.buildConfigDef(Constants.CUCM_ELEMENT_1, Constants.CUCM_ELEMENT_1, Constants.CUCM_ELEMENT_1, propertyDefs);
		graph.addConfigDefinition(ProbeMain.cucmGroupTableConfigDef);
	}

	public static void buildCucmTableConfig(GraphHelper graph) {

		CtdStringDefinition cucmName = CtdBuilderUtils.buildStringDef(Constants.CUCM_NAME, Constants.LABEL_NAME);
		cucmName.setReadOnly(true);
		cucmName.setDefaultValue(Constants.NOT_ACCESSIBLE);

		CtdStringDefinition cucmDescription = CtdBuilderUtils.buildStringDef(Constants.CUCM_DESCRIPTION, Constants.LABEL_DESCRIPTION);		
		cucmDescription.setReadOnly(true);
		cucmDescription.setDefaultValue(Constants.NOT_ACCESSIBLE);

		CtdStringDefinition cucmVersion = CtdBuilderUtils.buildStringDef(Constants.CUCM_VERSION, Constants.LABEL_VERSION);		
		cucmVersion.setReadOnly(true);
		cucmVersion.setDefaultValue(Constants.NOT_ACCESSIBLE);

		CtdStringDefinition cucmInetAddress = CtdBuilderUtils.buildStringDef(Constants.CUCM_INET_ADDRESS, Constants.LABEL_INET_ADDRESS);		
		cucmInetAddress.setReadOnly(true);
		cucmInetAddress.setDefaultValue(Constants.NOT_ACCESSIBLE);

		CtdStringDefinition cucmInetClusterId = CtdBuilderUtils.buildStringDef(Constants.CUCM_CLUSTER_ID, Constants.LABEL_CLUSTER_ID);		
		cucmInetClusterId.setReadOnly(true);
		cucmInetClusterId.setDefaultValue(Constants.NOT_ACCESSIBLE);

		CtdStringDefinition cucmInetAddress2 = CtdBuilderUtils.buildStringDef(Constants.CUCM_INET_ADDRESS2, Constants.LABEL_INET_ADDRESS2);		
		cucmInetAddress2.setReadOnly(true);
		cucmInetAddress2.setDefaultValue(Constants.NOT_ACCESSIBLE);

		final CtdPropertyDefinition<?>[] propertyDefs = {cucmName, cucmDescription, cucmVersion, cucmInetAddress, cucmInetClusterId, cucmInetAddress2};
		ProbeMain.cucmTableConfigDef = CtdBuilderUtils.buildConfigDef(Constants.CUCM_ELEMENT_2, Constants.CUCM_ELEMENT_2, Constants.CUCM_ELEMENT_2, propertyDefs);
		graph.addConfigDefinition(ProbeMain.cucmTableConfigDef);
	}	


	public static void buildH323DeviceConfig(GraphHelper graph) {
		
		CtdStringDefinition h323DeviceName = CtdBuilderUtils.buildStringDef(Constants.H323DEVICE_NAME, Constants.LABEL_NAME);		
		h323DeviceName.setReadOnly(true);
		h323DeviceName.setDefaultValue(Constants.NOT_ACCESSIBLE);

		CtdStringDefinition h323DeviceIndex = CtdBuilderUtils.buildStringDef(Constants.H323DEVICE_INDEX, Constants.LABEL_INDEX);		
		h323DeviceIndex.setReadOnly(true);
		h323DeviceIndex.setDefaultValue(Constants.NOT_ACCESSIBLE);
		
		CtdStringDefinition h323DeviceProductId = CtdBuilderUtils.buildStringDef(Constants.H323DEVICE_PRODUCT_ID, Constants.LABLE_PRODUCT_ID);		
		h323DeviceProductId.setReadOnly(true);
		h323DeviceProductId.setDefaultValue(Constants.NOT_ACCESSIBLE);
		
		CtdStringDefinition h323DeviceDescription = CtdBuilderUtils.buildStringDef(Constants.H323DEVICE_DESCRIPTION, Constants.LABEL_DESCRIPTION);		
		h323DeviceDescription.setReadOnly(true);
		h323DeviceDescription.setDefaultValue(Constants.NOT_ACCESSIBLE);
		
		CtdStringDefinition h323DeviceInetAddressType = CtdBuilderUtils.buildStringDef(Constants.H323DEVICE_INET_ADDRESS_TYPE, Constants.LABLE_INET_ADDRESS_TYPE);		
		h323DeviceInetAddressType.setReadOnly(true);
		h323DeviceInetAddressType.setDefaultValue(Constants.NOT_ACCESSIBLE);
		
		CtdStringDefinition h323DeviceInetAddress = CtdBuilderUtils.buildStringDef(Constants.H323DEVICE_INET_ADDRESS, Constants.LABLE_INET_ADDRESS);		
		h323DeviceInetAddress.setReadOnly(true);
		h323DeviceInetAddress.setDefaultValue(Constants.NOT_ACCESSIBLE);
		
		final CtdPropertyDefinition<?>[] propertyDefs = {h323DeviceName, h323DeviceIndex,h323DeviceProductId,h323DeviceDescription,h323DeviceInetAddressType,h323DeviceInetAddress};
		ProbeMain.h323DeviceConfigDef = CtdBuilderUtils.buildConfigDef(Constants.LABLE_H323DEVICE1,Constants.H323DEVICE,Constants.H323DEVICE,propertyDefs);
		graph.addConfigDefinition(ProbeMain.h323DeviceConfigDef);
	}
	
public static void buildCCCAGeneralInfoConfig(GraphHelper graph) {
		
		CtdStringDefinition cccaName = CtdBuilderUtils.buildStringDef(Constants.CCCA_NAME, Constants.CCCA_NAME_LABLE);		
		cccaName.setReadOnly(true);
		cccaName.setDefaultValue(Constants.NOT_ACCESSIBLE);

		CtdStringDefinition cccaDescription = CtdBuilderUtils.buildStringDef(Constants.CCCA_DESCRIPITION, Constants.CCCA_DESCRIPITION_LABLE);		
		cccaDescription.setReadOnly(true);
		cccaDescription.setDefaultValue(Constants.NOT_ACCESSIBLE);
		
		CtdStringDefinition cccaVersion = CtdBuilderUtils.buildStringDef(Constants.CCCA_VERSION, Constants.CCCA_VERSION_LABLE);		
		cccaVersion.setReadOnly(true);
		cccaVersion.setDefaultValue(Constants.NOT_ACCESSIBLE);
		
		final CtdPropertyDefinition<?>[] propertyDefs = {cccaName, cccaDescription,cccaVersion};
		ProbeMain.cccaGeneralInfoConfigDef = CtdBuilderUtils.buildConfigDef(Constants.CCCA_GENERAL_INFO_LABLE,Constants.CCCA_GENERAL_INFO_ELEMENT,Constants.CCCA_GENERAL_INFO_ELEMENT,propertyDefs);
		graph.addConfigDefinition(ProbeMain.cccaGeneralInfoConfigDef);
	}
	public static void buildCCCAInstanceTableConfig(GraphHelper graph) {
		
		final CtdStringDefinition cccaInstanceName = CtdBuilderUtils.buildStringDef(Constants.CCCA_INSTANCE_NAME, Constants.CCCA_INSTANCE_NAME_LABLE);		
		cccaInstanceName.setReadOnly(true);
		cccaInstanceName.setDefaultValue(Constants.NOT_ACCESSIBLE);
		
		final CtdPropertyDefinition<?>[] propertyDefs = {cccaInstanceName};
		ProbeMain.cccaInstanceTableConfigDef = CtdBuilderUtils.buildConfigDef(Constants.CCCA_INSTANCE_TABLE_ELEMENT,Constants.CCCA_INSTANCE_TABLE_ELEMENT,Constants.CCCA_INSTANCE_TABLE_ELEMENT,propertyDefs);
		graph.addConfigDefinition(ProbeMain.cccaInstanceTableConfigDef);
	}
	
	public static void buildCCCACgTableConfig(GraphHelper graph) {
		
		final CtdStringDefinition cccaGatwayNumber = CtdBuilderUtils.buildStringDef(Constants.CCCA_CG_NUMBER, Constants.CCCA_CG_NUMBER_LABLE);		
		cccaGatwayNumber.setReadOnly(true);
		cccaGatwayNumber.setDefaultValue(Constants.NOT_ACCESSIBLE);
		final CtdStringDefinition cccaGatwaySide = CtdBuilderUtils.buildStringDef(Constants.CCCA_CG_SIDE, Constants.CCCA_CG_SIDE_LABLE);		
		cccaGatwaySide.setReadOnly(true);
		cccaGatwaySide.setDefaultValue(Constants.NOT_ACCESSIBLE);
		
		final CtdPropertyDefinition<?>[] propertyDefs = {cccaGatwayNumber,cccaGatwaySide};
		ProbeMain.cccaCgTableConfigDef = CtdBuilderUtils.buildConfigDef(Constants.CCCA_CG_TABLE_LABLE,Constants.CCCA_CG_TABLE_ELEMENT,Constants.CCCA_CG_TABLE_ELEMENT,propertyDefs);
		graph.addConfigDefinition(ProbeMain.cccaCgTableConfigDef);
	}
	
public static void buildCCCALoggerTableConfig(GraphHelper graph) {
		
		final CtdStringDefinition cccaLoggerRouterSideAName = CtdBuilderUtils.buildStringDef(Constants.CCCA_LOGGER_ROUTER_SIDEA_NAME, Constants.CCCA_LOGGER_ROUTER_SIDEA_NAME_LABLE);		
		cccaLoggerRouterSideAName.setReadOnly(true);
		cccaLoggerRouterSideAName.setDefaultValue(Constants.NOT_ACCESSIBLE);
		final CtdStringDefinition cccaLoggerRouterSideBName = CtdBuilderUtils.buildStringDef(Constants.CCCA_LOGGER_ROUTER_SIDEB_NAME, Constants.CCCA_LOGGER_ROUTER_SIDEB_NAME_LABLE);		
		cccaLoggerRouterSideBName.setReadOnly(true);
		cccaLoggerRouterSideBName.setDefaultValue(Constants.NOT_ACCESSIBLE);
		
		final CtdStringDefinition cccaLoggerSide = CtdBuilderUtils.buildStringDef(Constants.CCCA_LOGGER_SIDE, Constants.CCCA_LOGGER_SIDE_LABLE);		
		cccaLoggerSide.setReadOnly(true);
		cccaLoggerSide.setDefaultValue(Constants.NOT_ACCESSIBLE);
		final CtdStringDefinition cccaLoggerType = CtdBuilderUtils.buildStringDef(Constants.CCCA_LOGGER_TYPE, Constants.CCCA_LOGGER_TYPE_LABLE);		
		cccaLoggerType.setReadOnly(true);
		cccaLoggerType.setDefaultValue(Constants.NOT_ACCESSIBLE);
		
		final CtdPropertyDefinition<?>[] propertyDefs = {cccaLoggerRouterSideAName,cccaLoggerRouterSideBName,cccaLoggerSide,cccaLoggerType};
		ProbeMain.cccaLoggerTableConfigDef= CtdBuilderUtils.buildConfigDef(Constants.CCCA_LOGGER_TABLE_LABLE,Constants.CCCA_LOGGER_TABLE_ELEMENT,Constants.CCCA_LOGGER_TABLE_ELEMENT,propertyDefs);
		graph.addConfigDefinition(ProbeMain.cccaLoggerTableConfigDef);
	}
	

public static void buildcccaRouterTableConfig(GraphHelper graph) {
	
	final CtdStringDefinition cccaRouterSide = CtdBuilderUtils.buildStringDef(Constants.CCCA_ROUTER_SIDE, Constants.CCCA_ROUTER_SIDE_LABLE);		
	cccaRouterSide.setReadOnly(true);
	cccaRouterSide.setDefaultValue(Constants.NOT_ACCESSIBLE);
	
	
	final CtdPropertyDefinition<?>[] propertyDefs = {cccaRouterSide};
	ProbeMain.cccaRouterTableConfigDef= CtdBuilderUtils.buildConfigDef(Constants.CCCA_ROUTER_TABLE_LABLE,Constants.CCCA_ROUTER_TABLE_ELEMENT,Constants.CCCA_ROUTER_TABLE_ELEMENT,propertyDefs);
	graph.addConfigDefinition(ProbeMain.cccaRouterTableConfigDef);
}

	public static void buildcccaComponentTableConfig(GraphHelper graph) {
		
		final CtdStringDefinition cccaComponenttype = CtdBuilderUtils.buildStringDef(Constants.CCCA_COMPONENT_TYPE, Constants.CCCA_COMPONENT_TYPE_LABLE);		
		cccaComponenttype.setReadOnly(true);
		cccaComponenttype.setDefaultValue(Constants.NOT_ACCESSIBLE);
		
		
		final CtdPropertyDefinition<?>[] propertyDefs = {cccaComponenttype};
		ProbeMain.cccaComponentTableConfigDef= CtdBuilderUtils.buildConfigDef(Constants.CCCA_COMPONENT_TABLE_LABLE,Constants.CCCA_COMPONENT_TABLE_ELEMENT,Constants.CCCA_COMPONENT_TABLE_ELEMENT,propertyDefs);
		graph.addConfigDefinition(ProbeMain.cccaComponentTableConfigDef);
	}
	public static void buildCCCADistAwTableConfig(GraphHelper graph) {
		
		final CtdStringDefinition cccaDistAwAdminSiteName = CtdBuilderUtils.buildStringDef(Constants.CCCA_DISTAW_ADMIN_SITE_NAME, Constants.CCCA_DISTAW_ADMIN_SITE_NAME_LABLE);		
		cccaDistAwAdminSiteName.setReadOnly(true);
		cccaDistAwAdminSiteName.setDefaultValue(Constants.NOT_ACCESSIBLE);
		final CtdStringDefinition cccaDistAwRouterSideAName = CtdBuilderUtils.buildStringDef(Constants.CCCA_DISTAW_ROUTER_SIDEA_NAME, Constants.CCCA_DISTAW_ROUTER_SIDEA_NAME_LABLE);		
		cccaDistAwRouterSideAName.setReadOnly(true);
		cccaDistAwRouterSideAName.setDefaultValue(Constants.NOT_ACCESSIBLE);
		final CtdStringDefinition cccaDistAwRouterSideBName = CtdBuilderUtils.buildStringDef(Constants.CCCA_DISTAW_ROUTER_SIDEB_NAME, Constants.CCCA_DISTAW_ROUTER_SIDEB_NAME_LABLE);		
		cccaDistAwRouterSideBName.setReadOnly(true);
		cccaDistAwRouterSideBName.setDefaultValue(Constants.NOT_ACCESSIBLE);
		final CtdStringDefinition cccaDistAwLoggerSideAName = CtdBuilderUtils.buildStringDef(Constants.CCCA_DISTAW_LOGGER_SIDEA_NAME, Constants.CCCA_DISTAW_LOGGER_SIDEA_NAME_LABLE);		
		cccaDistAwLoggerSideAName.setReadOnly(true);
		cccaDistAwLoggerSideAName.setDefaultValue(Constants.NOT_ACCESSIBLE);
		final CtdStringDefinition cccaDistAwLoggerSideBName = CtdBuilderUtils.buildStringDef(Constants.CCCA_DISTAW_LOGGER_SIDEB_NAME, Constants.CCCA_DISTAW_LOGGER_SIDEB_NAME_LABLE);		
		cccaDistAwLoggerSideBName.setReadOnly(true);
		cccaDistAwLoggerSideBName.setDefaultValue(Constants.NOT_ACCESSIBLE);
		final CtdStringDefinition cccaDistAwSide = CtdBuilderUtils.buildStringDef(Constants.CCCA_DISTAW_SIDE, Constants.CCCA_DISTAW_SIDE_LABLE);		
		cccaDistAwSide.setReadOnly(true);
		cccaDistAwSide.setDefaultValue(Constants.NOT_ACCESSIBLE);
		final CtdStringDefinition cccaDistAwType = CtdBuilderUtils.buildStringDef(Constants.CCCA_DISTAW_TYPE, Constants.CCCA_DISTAW_TYPE_LABLE);		
		cccaDistAwType.setReadOnly(true);
		cccaDistAwType.setDefaultValue(Constants.NOT_ACCESSIBLE);
		
		final CtdPropertyDefinition<?>[] propertyDefs = {cccaDistAwSide,cccaDistAwType,cccaDistAwAdminSiteName,cccaDistAwRouterSideAName,cccaDistAwRouterSideBName,cccaDistAwLoggerSideAName,cccaDistAwLoggerSideBName};
		ProbeMain.cccaDistAWTableConfigDef= CtdBuilderUtils.buildConfigDef(Constants.CCCA_DISTAW_TABLE_LABLE,Constants.CCCA_DISTAW_TABLE_ELEMENT,Constants.CCCA_DISTAW_TABLE_ELEMENT,propertyDefs);
		graph.addConfigDefinition(ProbeMain.cccaDistAWTableConfigDef);
	}
	public static void buildCCCAPgTableConfig(GraphHelper graph) {
		
		final CtdStringDefinition cccaPgRouterSideAName = CtdBuilderUtils.buildStringDef(Constants.CCCA_PG_ROUTER_SIDEA_NAME, Constants.CCCA_PG_ROUTER_SIDEA_NAME_LABLE);		
		cccaPgRouterSideAName.setReadOnly(true);
		cccaPgRouterSideAName.setDefaultValue(Constants.NOT_ACCESSIBLE);
		final CtdStringDefinition cccaPgRouterSideBName = CtdBuilderUtils.buildStringDef(Constants.CCCA_PG_ROUTER_SIDEB_NAME, Constants.CCCA_PG_ROUTER_SIDEB_NAME_LABLE);		
		cccaPgRouterSideBName.setReadOnly(true);
		cccaPgRouterSideBName.setDefaultValue(Constants.NOT_ACCESSIBLE);
		
		final CtdPropertyDefinition<?>[] propertyDefs = {cccaPgRouterSideAName,cccaPgRouterSideBName};
		ProbeMain.cccaPgTableConfigDef= CtdBuilderUtils.buildConfigDef(Constants.CCCA_PG_TABLE_LABLE,Constants.CCCA_PG_TABLE_ELEMENT,Constants.CCCA_PG_TABLE_ELEMENT,propertyDefs);
		graph.addConfigDefinition(ProbeMain.cccaPgTableConfigDef);
	}
	
public static void buildCCCAPimTableConfig(GraphHelper graph) {
		
		final CtdStringDefinition cccaPimPeripheralType = CtdBuilderUtils.buildStringDef(Constants.CCCA_PIM_PERIPHERAL_TYPE, Constants.CCCA_PIM_PERIPHERAL_LABLE);		
		cccaPimPeripheralType.setReadOnly(true);
		cccaPimPeripheralType.setDefaultValue(Constants.NOT_ACCESSIBLE);
		
		
		final CtdPropertyDefinition<?>[] propertyDefs = {cccaPimPeripheralType};
		ProbeMain.cccaPimTableConfigDef= CtdBuilderUtils.buildConfigDef(Constants.CCCA_PIM_TABLE_LABLE,Constants.CCCA_PIM_TABLE_ELEMENT,Constants.CCCA_PIM_TABLE_ELEMENT,propertyDefs);
		graph.addConfigDefinition(ProbeMain.cccaPimTableConfigDef);
	}
	
	public static void buildCcmPhoneInfoConfig(GraphHelper graph) {

		CtdStringDefinition ccmPhonePhysicalAddress = CtdBuilderUtils.buildStringDef(Constants.CCM_PHONE_PHYSICAL_ADDRESS,Constants.LABLE_CCM_PHONE_PHYSICAL_ADDRESS);
		ccmPhonePhysicalAddress.setReadOnly(true);
		ccmPhonePhysicalAddress.setDefaultValue(Constants.NOT_ACCESSIBLE);
		
		CtdStringDefinition ccmPhoneIpAddress = CtdBuilderUtils.buildStringDef(Constants.CCM_PHONE_IP_ADDRESS,Constants.LABLE_CCM_PHONE_IP_ADDRESS);
		ccmPhoneIpAddress.setReadOnly(true);
		ccmPhoneIpAddress.setDefaultValue(Constants.NOT_ACCESSIBLE);

		CtdStringDefinition ccmPhoneE911Location = CtdBuilderUtils.buildStringDef(Constants.CCM_PHONE_E911_LOCATION,Constants.LABLE_CCM_PHONE_E911_LOCATION);
		ccmPhoneE911Location.setReadOnly(true);
		ccmPhoneE911Location.setDefaultValue(Constants.NOT_ACCESSIBLE);
		
		CtdStringDefinition ccmPhoneName = CtdBuilderUtils.buildStringDef(Constants.CCM_PHONE_NAME,Constants.LABLE_CCM_PHONE_NAME);
		ccmPhoneName.setReadOnly(true);
		ccmPhoneName.setDefaultValue(Constants.NOT_ACCESSIBLE);
		
		CtdStringDefinition ccmPhoneInetAddressIPv4 = CtdBuilderUtils.buildStringDef(Constants.CCM_PHONE_INET_ADDRESS_IPV4,Constants.LABLE_CCM_PHONE_INET_ADDRESS_IPV4);
		ccmPhoneInetAddressIPv4.setReadOnly(true);
		ccmPhoneInetAddressIPv4.setDefaultValue(Constants.NOT_ACCESSIBLE);
		
		CtdStringDefinition ccmPhoneInetAddressIPv6 = CtdBuilderUtils.buildStringDef(Constants.CCM_PHONE_INET_ADDRESS_IPV6,Constants.LABLE_CCM_PHONE_INET_ADDRESS_IPV6);
		ccmPhoneInetAddressIPv6.setReadOnly(true);
		ccmPhoneInetAddressIPv6.setDefaultValue(Constants.NOT_ACCESSIBLE);
		
		final CtdPropertyDefinition<?>[] propertyDefs = {ccmPhonePhysicalAddress,ccmPhoneIpAddress,ccmPhoneE911Location,ccmPhoneName,ccmPhoneInetAddressIPv4,ccmPhoneInetAddressIPv6};
		//appliesToTypeName para in buildConfigDef must be same as defineElementType in CcmPhoneInfo.
		ProbeMain.ccmPhoneInfoConfigDef = CtdBuilderUtils.buildConfigDef(Constants.LABLE_CCM_PHONE_INFO_ELEMENT, Constants.CCM_PHONE_INFO_ELEMENT, Constants.CCM_PHONE_INFO_ELEMENT, propertyDefs);
		graph.addConfigDefinition(ProbeMain.ccmPhoneInfoConfigDef);
		
	}
	public static void createCucmGroupFolder(SnmpCreditionals snmpCreditionals, ArrayList<OidForm> oidFormList, Folder cucmFolder, InventoryDataset inventoryDataset, GraphHelper graph){
		Vector<? extends VariableBinding> indexList = null;
		ArrayList<String> devNameIndexList = new ArrayList<String>();
		for (OidForm oidForm : oidFormList) {
			if (oidForm.getOidName().equalsIgnoreCase(Constants.CUCM_GROUP_NAME)) {
				indexList = SNMPUtils.getBulk(snmpCreditionals, oidForm.getOidValue());
				if (indexList.size() != 0) {
					for (int count = 0; count < indexList.size(); count++) {
						devNameIndexList.add(indexList.get(count).getOid().toString().trim().substring(oidForm.getOidValue().trim().length()));
					}
				}
			}

		}


		for (int count = 0; count < devNameIndexList.size(); count++) {
			try {
				CucmGroupFolder cucmGroupFolder =null;
				cucmGroupFolder = CucmGroupFolder.addInstance(inventoryDataset, new EntityId(cucmFolder, indexList.get(count).getVariable().toString()), indexList.get(count).getVariable().toString(), cucmFolder);
//				CtdGroup ctdGroup =cucmGroupFolder.getOrBuildCtdEntity();
//				ctdGroup.setTypeName(indexList.get(count).getVariable().toString());
				cucmGroupFolder.setCucmGroupConfigDef(ProbeMain.cucmGroupConfigDef);
				cucmGroupFolder.setGraphHelper(graph);

				Map<String, Object> valuesMap = new ConcurrentHashMap<String, Object>();
				for (OidForm oidForm : oidFormList) {					
					Log.info("=========OID NAME============= " + oidForm.getOidName());
					VariableBinding variableBinding = SNMPUtils.poll(snmpCreditionals, oidForm.getOidValue() + devNameIndexList.get(count));
					Log.info("=========Variable Binding============= " + variableBinding);
					if(!variableBinding.getVariable().isException())
					valuesMap.put(oidForm.getOidName(), variableBinding.getVariable().toString());
				}
				cucmGroupFolder.setValuesMap(valuesMap);
			} catch (NimException e) {
				// TODO Auto-generated catch block
				Log.error("Exception  ============    " + e);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				Log.error("Exception  ============    " + e);
			}
		}
	}
		/*for (int count = 0; count < devNameIndexList.size(); count++) {
			try {
				H323DeviceInfoFolder h323DeviceInfoFolder =null;
				h323DeviceInfoFolder = H323DeviceInfoFolder.addInstance(inventoryDataset, new EntityId(h323DeviceFolder, indexList.get(count).getVariable().toString()), indexList.get(count).getVariable().toString(), h323DeviceFolder);
				h323DeviceInfoFolder.setH323DeviceConfigDef(ProbeMain.h323DeviceConfigDef);
				h323DeviceInfoFolder.setGraphHelper(graph);

				Map<String, Object> valuesMap = new ConcurrentHashMap<String, Object>();
				for (OidForm oidForm : oidFormList) {					
					Log.info("=========OID NAME============= " + oidForm.getOidName());
					VariableBinding variableBinding = SNMPUtils.poll(snmpCreditionals, oidForm.getOidValue() + devNameIndexList.get(count));
					Log.info("=========Variable Binding============= " + variableBinding);
					if(!variableBinding.getVariable().isException())
					valuesMap.put(oidForm.getOidName(),variableBinding.getVariable().toString());
				}
				h323DeviceInfoFolder.setValuesMap(valuesMap);
			} catch (NimException e) {
				// TODO Auto-generated catch block
				Log.error("Exception  ============    " + e);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				Log.error("Exception  ============    " + e);
			}
		}*/
	
	public static void createCucmTableFolder(SnmpCreditionals snmpCreditionals, ArrayList<OidForm> oidFormList, Folder cucmFolder, InventoryDataset inventoryDataset, GraphHelper graph){
		Vector<? extends VariableBinding> indexList = null;
		ArrayList<String> devNameIndexList = new ArrayList<String>();
		for (OidForm oidForm : oidFormList) {
			if (oidForm.getOidName().equalsIgnoreCase(Constants.CUCM_NAME)) {
				indexList = SNMPUtils.getBulk(snmpCreditionals, oidForm.getOidValue());
				if (indexList.size() != 0) {
					for (int count = 0; count < indexList.size(); count++) {
						devNameIndexList.add(indexList.get(count).getOid().toString().trim().substring(oidForm.getOidValue().trim().length()));
					}
				}
			}

		}
		for (int count = 0; count < devNameIndexList.size(); count++) {
			try {				
				CucmTableChild ccmTableChild =null;
				ccmTableChild = CucmTableChild.addInstance(inventoryDataset, new EntityId(cucmFolder, indexList.get(count).getVariable().toString()), indexList.get(count).getVariable().toString(), cucmFolder);
				CtdElement ctdElement =ccmTableChild.getOrBuildCtdEntity();
//				ctdElement.setTypeName(indexList.get(count).getVariable().toString());
				ccmTableChild.setCucmTableConfigDef(ProbeMain.cucmTableConfigDef);
				ccmTableChild.setGraphHelper(graph);

				Map<String, Object> valuesMap = new ConcurrentHashMap<String, Object>();
				for (OidForm oidForm : oidFormList) {
					Log.info("=========OID NAME============= " + oidForm.getOidName());
					VariableBinding variableBinding = SNMPUtils.poll(snmpCreditionals, oidForm.getOidValue() + devNameIndexList.get(count));
					Log.info("=========Variable Binding============= " + variableBinding);					
					if(oidForm.getElement() !=null && !oidForm.getElement().equals("")){
						MetricDef metric = QOSUtil.getMetricDef(oidForm.getElement(), oidForm.getMetricName());
						ccmTableChild.setMetric((MetricDef) metric, variableBinding.getVariable().isException() ? 0 : variableBinding.getVariable().toLong());

					}else{
						if(!variableBinding.getVariable().isException())
						valuesMap.put(oidForm.getOidName(), variableBinding.getVariable().toString());
					}
				}
				ccmTableChild.setValuesMap(valuesMap);
			} catch (NimException e) {
				// TODO Auto-generated catch block
				Log.error("Exception  ============    " + e);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				Log.error("Exception  ============    " + e);
			}
		}		
	}
	
	/*public static  void getQOSForCCCALoggerTable(ConcurrentHashMap<String,ArrayList<QosForm>> descQosMap, Folder folder, InventoryDataset inventoryDataset, SnmpCreditionals snmpCreditionals,GraphHelper graph) throws NimException, InterruptedException {
		ConcurrentHashMap<String,ArrayList<QosForm>> qosFormLMap=descQosMap;
		Set<String> descList=qosFormLMap.keySet();
		for(String description:descList){
			try{
			CCCALoggerTableChild ccmLoggerChild = CCCALoggerTableChild.addInstance(inventoryDataset, new EntityId(folder, description), description, folder);
			ccmLoggerChild.setCccaLoggerTableConfigDef(ProbeMain.cccaLoggerTableConfigDef);
			ccmLoggerChild.setGraphHelper(graph);
			Map<String, Object> valuesMap = new ConcurrentHashMap<String, Object>();
			ArrayList<QosForm> qosFormList=qosFormLMap.get(description);
			for (QosForm qosForm : qosFormList) {
				if(qosForm!=null && qosForm.getElement()!="" && qosForm.getMetricName()!=""){
					MetricDef metric = QOSUtil.getMetricDef(qosForm.getElement(), qosForm.getMetricName());
					ccmLoggerChild.setMetric((MetricDef) metric,Long.parseLong(qosForm.getQos()) );
				}else{
					valuesMap.put(qosForm.getOidName(),qosForm.getQos());
				}
				
			}
			ccmLoggerChild.setValuesMap(valuesMap);
		}catch(Exception e){
			Log.info("#############################Exception in getQOSForCCCALoggerTable: "+e);
		}
		}
	}*/
	
	public static void getQOSForCCCALoggerTable(SnmpCreditionals snmpCreditionals, ConcurrentHashMap<String,ArrayList<QosForm>> pollOidelement, Folder folder, InventoryDataset inventoryDataset, GraphHelper graph){
		ConcurrentHashMap<String,ArrayList<QosForm>> qosFormLMap=pollOidelement;
		Set<String> descList=qosFormLMap.keySet();
		for(String description:descList){
			try{
				CCCALoggerTableChild ccmLoggerChild = CCCALoggerTableChild.addInstance(inventoryDataset, new EntityId(folder, description), description, folder);
				ccmLoggerChild.setCccaLoggerTableConfigDef(ProbeMain.cccaLoggerTableConfigDef);
				ccmLoggerChild.setGraphHelper(graph);
			ArrayList<QosForm> qosFormList=qosFormLMap.get(description);
			Map<String, Object> valuesMap = new ConcurrentHashMap<String, Object>();
			for (QosForm qosForm : qosFormList) {
				
				if(qosForm.getOidName().equals(Constants.CCCA_LOGGER_SIDE)&&qosForm.getQos().equals(Constants.ONE)){
					valuesMap.put(qosForm.getOidName(),Constants.CCCA_LOGGER_SIDEA_PARSE);
				}else if(qosForm.getOidName().equals(Constants.CCCA_LOGGER_SIDE)&&qosForm.getQos().equals(Constants.TWO)) {
					valuesMap.put(qosForm.getOidName(),Constants.CCCA_ROUTER_SIDEB_PARSE);
				}
				else if(qosForm.getOidName().equals(Constants.CCCA_LOGGER_TYPE)&&qosForm.getQos().equals(Constants.ONE)) {
					valuesMap.put(qosForm.getOidName(),Constants.CCCA_LOGGER_TYPE_STANDARD_PARSE);
				}else if(qosForm.getOidName().equals(Constants.CCCA_LOGGER_TYPE)&&qosForm.getQos().equals(Constants.TWO)) {
					valuesMap.put(qosForm.getOidName(),Constants.CCCA_LOGGER_TYPE_NAM_PARSE);
				}else if(qosForm.getOidName().equals(Constants.CCCA_LOGGER_TYPE)&&qosForm.getQos().equals(Constants.THREE)) {
					valuesMap.put(qosForm.getOidName(),Constants.CCCA_LOGGER_TYPE_CICM_PARSE);
				}else{
					valuesMap.put(qosForm.getOidName(),qosForm.getQos());
				}
				
				 //valuesMap.put(qosForm.getOidName(),qosForm.getQos());
			}
			ccmLoggerChild.setValuesMap(valuesMap);
			}
			catch (NimException e) {
				Log.error("Exception  ============    " + e);
			} catch (InterruptedException e) {
				Log.error("Exception  ============    " + e);
			}
		}}
	
	
	public static  void getQOSForPimTable(ConcurrentHashMap<String,ArrayList<QosForm>> descQosMap, Folder folder, InventoryDataset inventoryDataset, SnmpCreditionals snmpCreditionals,GraphHelper graph) throws NimException, InterruptedException {
		ConcurrentHashMap<String,ArrayList<QosForm>> qosFormLMap=descQosMap;
		Set<String> descList=qosFormLMap.keySet();
		for(String description:descList){
			try{
			CCCAPimTableChild ccmPimChild = CCCAPimTableChild.addInstance(inventoryDataset, new EntityId(folder, description), description, folder);
			ccmPimChild.setPimTableConfigDef(ProbeMain.cccaPimTableConfigDef);
			ccmPimChild.setGraphHelper(graph);
			Map<String, Object> valuesMap = new ConcurrentHashMap<String, Object>();
			ArrayList<QosForm> qosFormList=qosFormLMap.get(description);
			for (QosForm qosForm : qosFormList) {
				if(qosForm!=null && qosForm.getElement()!="" && qosForm.getMetricName()!=""){
					MetricDef metric = QOSUtil.getMetricDef(qosForm.getElement(), qosForm.getMetricName());
					ccmPimChild.setMetric((MetricDef) metric,Long.parseLong(qosForm.getQos()) );
				}else{
					valuesMap.put(qosForm.getOidName(),qosForm.getQos());
				}
				
			}
			ccmPimChild.setValuesMap(valuesMap);
		}catch(Exception e){
			Log.info("#############################Exception in getQOSForCCCALoggerTable: "+e);
		}
		}
	}
	
	/*public static void  getQOSForPimTable(ConcurrentHashMap<String,ArrayList<QosForm>> descQOSFormElementMap, Folder interfaceFolder, InventoryDataset inventoryDataset, SnmpCreditionals snmpCreditionals) throws NimException, InterruptedException {
		ConcurrentHashMap<String,ArrayList<QosForm>> qosFormLMap=descQOSFormElementMap;
		Set<String> descSet=qosFormLMap.keySet();
		for(String description:descSet){
			CCCAPimTable cccaPimTable = CCCAPimTable.addInstance(inventoryDataset, new EntityId(interfaceFolder, description), description, interfaceFolder);
			ArrayList<QosForm> qosFormList=qosFormLMap.get(description);
			for (QosForm qosForm : qosFormList) {
				if(qosForm!=null && qosForm.getElement()!="" && qosForm.getMetricName()!=""){
					MetricDef metric = QOSUtil.getMetricDef(qosForm.getElement(), qosForm.getMetricName());
					cccaPimTable.setMetric((MetricDef) metric,Long.parseLong(qosForm.getQos()) );
				}
			}
		}
	}*/
	
	/*public static void  getQOSForCgTable(ConcurrentHashMap<String,ArrayList<QosForm>> descQOSFormElementMap, Folder interfaceFolder, InventoryDataset inventoryDataset, SnmpCreditionals snmpCreditionals) throws NimException, InterruptedException {
		ConcurrentHashMap<String,ArrayList<QosForm>> qosFormLMap=descQOSFormElementMap;
		Set<String> descSet=qosFormLMap.keySet();
		for(String description:descSet){
			CCCACgTable cccaCgTable = CCCACgTable.addInstance(inventoryDataset, new EntityId(interfaceFolder, description), description, interfaceFolder);
			ArrayList<QosForm> qosFormList=qosFormLMap.get(description);
			for (QosForm qosForm : qosFormList) {
				if(qosForm!=null && qosForm.getElement()!="" && qosForm.getMetricName()!=""){
					MetricDef metric = QOSUtil.getMetricDef(qosForm.getElement(), qosForm.getMetricName());
					cccaCgTable.setMetric((MetricDef) metric,Long.parseLong(qosForm.getQos()) );
				}
			}
		}
	}*/
	
	/*public static  void getQOSForCCCADistTable(ConcurrentHashMap<String,ArrayList<QosForm>> descQosMap, Folder folder, InventoryDataset inventoryDataset, SnmpCreditionals snmpCreditionals,GraphHelper graph) throws NimException, InterruptedException {
		ConcurrentHashMap<String,ArrayList<QosForm>> qosFormLMap=descQosMap;
		Set<String> descList=qosFormLMap.keySet();
		for(String description:descList){
			CCCADistAWTableChild ccmDistChild = CCCADistAWTableChild.addInstance(inventoryDataset, new EntityId(folder, description), description, folder);
			ccmDistChild.setCccaDistAWTableConfigDef(ProbeMain.cccaDistAWTableConfigDef);
			ccmDistChild.setGraphHelper(graph);
			Map<String, Object> valuesMap = new ConcurrentHashMap<String, Object>();
			ArrayList<QosForm> qosFormList=qosFormLMap.get(description);
			for (QosForm qosForm : qosFormList) {
				if(qosForm!=null && qosForm.getElement()!="" && qosForm.getMetricName()!=""){
					MetricDef metric = QOSUtil.getMetricDef(qosForm.getElement(), qosForm.getMetricName());
					ccmDistChild.setMetric((MetricDef) metric,Long.parseLong(qosForm.getQos()) );
				}else{
					valuesMap.put(qosForm.getOidName(),qosForm.getQos());
				}
				
			}
			ccmDistChild.setValuesMap(valuesMap);
		}
	}*/
	
	public static void getQOSForCCCADistTable(SnmpCreditionals snmpCreditionals, ConcurrentHashMap<String,ArrayList<QosForm>> pollOidelement, Folder folder, InventoryDataset inventoryDataset, GraphHelper graph){
		ConcurrentHashMap<String,ArrayList<QosForm>> qosFormLMap=pollOidelement;
		Set<String> descList=qosFormLMap.keySet();
		for(String description:descList){
			try{
				CCCADistAWTableChild ccmDistChild = CCCADistAWTableChild.addInstance(inventoryDataset, new EntityId(folder, description), description, folder);
				ccmDistChild.setCccaDistAWTableConfigDef(ProbeMain.cccaDistAWTableConfigDef);
				ccmDistChild.setGraphHelper(graph);
			ArrayList<QosForm> qosFormList=qosFormLMap.get(description);
			Map<String, Object> valuesMap = new ConcurrentHashMap<String, Object>();
			for (QosForm qosForm : qosFormList) {
				 valuesMap.put(qosForm.getOidName(),qosForm.getQos());
			}
			ccmDistChild.setValuesMap(valuesMap);
			}
			catch (NimException e) {
				Log.error("Exception  ============    " + e);
			} catch (InterruptedException e) {
				Log.error("Exception  ============    " + e);
			}
		}}
	
	
	public static  void getQOSForCCCAPgTable(ConcurrentHashMap<String,ArrayList<QosForm>> descQosMap, Folder folder, InventoryDataset inventoryDataset, SnmpCreditionals snmpCreditionals,GraphHelper graph) throws NimException, InterruptedException {
		ConcurrentHashMap<String,ArrayList<QosForm>> qosFormLMap=descQosMap;
		Set<String> descList=qosFormLMap.keySet();
		for(String description:descList){
			CCCAPgTableChild cccaPgChild = CCCAPgTableChild.addInstance(inventoryDataset, new EntityId(folder, description), description, folder);
			cccaPgChild.setCccaPgTableConfigDef(ProbeMain.cccaPgTableConfigDef);
			cccaPgChild.setGraphHelper(graph);
			Map<String, Object> valuesMap = new ConcurrentHashMap<String, Object>();
			ArrayList<QosForm> qosFormList=qosFormLMap.get(description);
			for (QosForm qosForm : qosFormList) {
				if(qosForm!=null && qosForm.getElement()!="" && qosForm.getMetricName()!=""){
					MetricDef metric = QOSUtil.getMetricDef(qosForm.getElement(), qosForm.getMetricName());
					cccaPgChild.setMetric((MetricDef) metric,Long.parseLong(qosForm.getQos()) );
				}else{
					valuesMap.put(qosForm.getOidName(),qosForm.getQos());
				}
				
			}
			cccaPgChild.setValuesMap(valuesMap);
		}
	}
	
	public static void createH323Device(SnmpCreditionals snmpCreditionals, ConcurrentHashMap<String,ArrayList<QosForm>> pollOidelement, Folder h323DeviceFolder, InventoryDataset inventoryDataset, GraphHelper graph){
		ConcurrentHashMap<String,ArrayList<QosForm>> qosFormLMap=pollOidelement;
		Set<String> descList=qosFormLMap.keySet();
		for(String description:descList){
			try{
			H323DeviceInfoFolder h323DeviceInfoFolder = H323DeviceInfoFolder.addInstance(inventoryDataset, new EntityId(h323DeviceFolder, description), description, h323DeviceFolder);
			h323DeviceInfoFolder.setH323DeviceConfigDef(ProbeMain.h323DeviceConfigDef);
			h323DeviceInfoFolder.setGraphHelper(graph);
			ArrayList<QosForm> qosFormList=qosFormLMap.get(description);
			Map<String, Object> valuesMap = new ConcurrentHashMap<String, Object>();
			for (QosForm qosForm : qosFormList) {
				 valuesMap.put(qosForm.getOidName(),qosForm.getQos());
			}
			h323DeviceInfoFolder.setValuesMap(valuesMap);
			}
			catch (NimException e) {
				Log.error("Exception  ============    " + e);
			} catch (InterruptedException e) {
				Log.error("Exception  ============    " + e);
			}
		}}
	
	public static void getQOSForCCCAGeneralInfo(SnmpCreditionals snmpCreditionals, ConcurrentHashMap<String,ArrayList<QosForm>> elementQosMap, Folder folder, InventoryDataset inventoryDataset, GraphHelper graph){
		ConcurrentHashMap<String,ArrayList<QosForm>> qosFormLMap=elementQosMap;
		Set<String> descList=qosFormLMap.keySet();
		for(String description:descList){
			try{
			CCCAGeneralInfo generalInfoFolder = CCCAGeneralInfo.addInstance(inventoryDataset, new EntityId(folder, description), description, folder);
			generalInfoFolder.setCCCAGeneralInfoConfigDef(ProbeMain.cccaGeneralInfoConfigDef);
			generalInfoFolder.setGraphHelper(graph);
			ArrayList<QosForm> qosFormList=qosFormLMap.get(description);
			Map<String, Object> valuesMap = new ConcurrentHashMap<String, Object>();
			for (QosForm qosForm : qosFormList) {
				 valuesMap.put(qosForm.getOidName(),qosForm.getQos());
			}
			generalInfoFolder.setValuesMap(valuesMap);
			}
			catch (NimException e) {
				Log.error("Exception  in getQOSForCCCAGeneralInfo============    " + e);
			} catch (InterruptedException e) {
				Log.error("Exception in getQOSForCCCAGeneralInfo ============    " + e);
			}
		}}
	
	public static void getQOSForCCCAInstanceTable(SnmpCreditionals snmpCreditionals, ConcurrentHashMap<String,ArrayList<QosForm>> elementQosMap, Folder folder, InventoryDataset inventoryDataset, GraphHelper graph){
		ConcurrentHashMap<String,ArrayList<QosForm>> qosFormLMap=elementQosMap;
		Set<String> descList=qosFormLMap.keySet();
		for(String description:descList){
			try{
			CCCAInstanceTable cccaInstanceTable = CCCAInstanceTable.addInstance(inventoryDataset, new EntityId(folder, description), description, folder);
			cccaInstanceTable.setCCCAInstanceTableConfigDef(ProbeMain.cccaInstanceTableConfigDef);
			cccaInstanceTable.setGraphHelper(graph);
			ArrayList<QosForm> qosFormList=qosFormLMap.get(description);
			Map<String, Object> valuesMap = new ConcurrentHashMap<String, Object>();
			for (QosForm qosForm : qosFormList) {
				 valuesMap.put(qosForm.getOidName(),qosForm.getQos());
			}
			cccaInstanceTable.setValuesMap(valuesMap);
			}
			catch (NimException e) {
				Log.error("Exception  in getQOSForCCCAInstanceTable============    " + e);
			} catch (InterruptedException e) {
				Log.error("Exception in getQOSForCCCAInstanceTable ============    " + e);
			}
		}}
	
	public static void getQOSForCgTable(SnmpCreditionals snmpCreditionals, ConcurrentHashMap<String,ArrayList<QosForm>> elementQosMap, Folder folder, InventoryDataset inventoryDataset, GraphHelper graph){
		ConcurrentHashMap<String,ArrayList<QosForm>> qosFormLMap=elementQosMap;
		Set<String> descList=qosFormLMap.keySet();
		for(String description:descList){
			try{
			CCCACgTable cccaCgTable = CCCACgTable.addInstance(inventoryDataset, new EntityId(folder, description), description, folder);
			cccaCgTable.setCCCACgTableConfigDef(ProbeMain.cccaCgTableConfigDef);
			cccaCgTable.setGraphHelper(graph);
			ArrayList<QosForm> qosFormList=qosFormLMap.get(description);
			Map<String, Object> valuesMap = new ConcurrentHashMap<String, Object>();
			for (QosForm qosForm : qosFormList) {
				 valuesMap.put(qosForm.getOidName(),qosForm.getQos());
			}
			cccaCgTable.setValuesMap(valuesMap);
			}
			catch (NimException e) {
				Log.error("Exception  in getQOSForCCCAInstanceTable============    " + e);
			} catch (InterruptedException e) {
				Log.error("Exception in getQOSForCCCAInstanceTable ============    " + e);
			}
		}}
	
	
	public static void createSystemPropertyFolder(SnmpCreditionals snmpCreditionals, ConcurrentHashMap<String,ArrayList<QosForm>> pollOidelement, Folder systemGlobalFolder, InventoryDataset inventoryDataset, GraphHelper graph){
		ConcurrentHashMap<String,ArrayList<QosForm>> qosFormLMap=pollOidelement;
		Set<String> descList=qosFormLMap.keySet();
		for(String description:descList){
			try{
				SystemGlobalFolder systemGlobalInfoFolder = SystemGlobalFolder.addInstance(inventoryDataset, new EntityId(systemGlobalFolder, description), description, systemGlobalFolder);
				systemGlobalInfoFolder.setSysGlobalConfigDef(ProbeMain.sysGlobalConfigDef);
				systemGlobalInfoFolder.setGraphHelper(graph);
			ArrayList<QosForm> qosFormList=qosFormLMap.get(description);
			Map<String, Object> valuesMap = new ConcurrentHashMap<String, Object>();
			for (QosForm qosForm : qosFormList) {
				 valuesMap.put(qosForm.getOidName(),qosForm.getQos());
			}
			systemGlobalInfoFolder.setValuesMap(valuesMap);
			}
			catch (NimException e) {
				Log.error("Exception  ============    " + e);
			} catch (InterruptedException e) {
				Log.error("Exception  ============    " + e);
			}
		}
	}
	public static void buildCcmGlobalTrunkConfig(GraphHelper graph){
		CtdStringDefinition ccmGatewayTrunkName = CtdBuilderUtils.buildStringDef(Constants.CCM_GATEWAY_TRUNK_NAME,Constants.CCM_GATEWAY_TRUNK_NAME);
		ccmGatewayTrunkName.setReadOnly(true);
		ccmGatewayTrunkName.setDefaultValue(Constants.NOT_ACCESSIBLE);
		final CtdPropertyDefinition<?>[] propertyDefs = {ccmGatewayTrunkName};
		ProbeMain.ccmGlobalTrunkConfigDef=CtdBuilderUtils.buildConfigDef(Constants.LABLE_CCM_GATEWAY_TRUNK_ELEMENT, Constants.CCM_GATEWAY_TRUNK_ELEMENT, Constants.CCM_GATEWAY_TRUNK_ELEMENT, propertyDefs);
		graph.addConfigDefinition(ProbeMain.ccmGlobalTrunkConfigDef);
		
	}
	public static void buildCcmGlobalInfoConfig(GraphHelper graph){
		CtdStringDefinition ccmSystemVersion = CtdBuilderUtils.buildStringDef(Constants.CCM_SYSTEM_VERSION,Constants.CCM_SYSTEM_VERSION);
		ccmSystemVersion.setReadOnly(true);
		ccmSystemVersion.setDefaultValue(Constants.NOT_ACCESSIBLE);
		final CtdPropertyDefinition<?>[] propertyDefs = {ccmSystemVersion};
		ProbeMain.ccmGlobalInfoConfigDef=CtdBuilderUtils.buildConfigDef(Constants.LABLE_CCM_GLOBAL_INFO_ELEMENT, Constants.CCM_GLOBAL_INFO_ELEMENT, Constants.CCM_GLOBAL_INFO_ELEMENT, propertyDefs);
		graph.addConfigDefinition(ProbeMain.ccmGlobalInfoConfigDef);
		
	}
	public static void buildGateWayInfoConfig(GraphHelper graph){
		CtdStringDefinition ccmGatewayName = CtdBuilderUtils.buildStringDef(Constants.CCM_GATEWAY_NAME,Constants.CCM_GATEWAY_NAME);
		ccmGatewayName.setReadOnly(true);
		ccmGatewayName.setDefaultValue(Constants.NOT_ACCESSIBLE);
		
		CtdStringDefinition ccmGatewayType = CtdBuilderUtils.buildStringDef(Constants.CCM_GATEWAY_TYPE,Constants.CCM_GATEWAY_TYPE);
		ccmGatewayType.setReadOnly(true);
		ccmGatewayType.setDefaultValue(Constants.NOT_ACCESSIBLE);
		
		CtdStringDefinition ccmGatewayDescription = CtdBuilderUtils.buildStringDef(Constants.CCM_GATEWAY_DESCRIPTION,Constants.CCM_GATEWAY_DESCRIPTION);
		ccmGatewayDescription.setReadOnly(true);
		ccmGatewayDescription.setDefaultValue(Constants.NOT_ACCESSIBLE);
		
		CtdStringDefinition ccmGatewayInetAddress = CtdBuilderUtils.buildStringDef(Constants.CCM_GATEWAY_INET_ADDRESS,Constants.CCM_GATEWAY_INET_ADDRESS);
		ccmGatewayInetAddress.setReadOnly(true);
		ccmGatewayInetAddress.setDefaultValue(Constants.NOT_ACCESSIBLE);
		
		CtdStringDefinition ccmGatewayInetAddressType = CtdBuilderUtils.buildStringDef(Constants.CCM_GATEWAY_INET_ADDRESS_TYPE,Constants.CCM_GATEWAY_INET_ADDRESS_TYPE);
		ccmGatewayInetAddressType.setReadOnly(true);
		ccmGatewayInetAddressType.setDefaultValue(Constants.NOT_ACCESSIBLE);
		
		CtdStringDefinition ccmGatewayProductId = CtdBuilderUtils.buildStringDef(Constants.CCM_GATEWAY_PRODUCTID,Constants.CCM_GATEWAY_PRODUCTID);
		ccmGatewayProductId.setReadOnly(true);
		ccmGatewayProductId.setDefaultValue(Constants.NOT_ACCESSIBLE);
		
		final CtdPropertyDefinition<?>[] propertyDefs = {ccmGatewayName,ccmGatewayType,ccmGatewayDescription,ccmGatewayInetAddress,ccmGatewayInetAddressType,ccmGatewayProductId};
		ProbeMain.ccmGateWayInfoConfigDef=CtdBuilderUtils.buildConfigDef(Constants.LABLE_CCM_GATEWAY_INFO_ELEMENT, Constants.CCM_GATEWAY_INFO_ELEMENT, Constants.CCM_GATEWAY_INFO_ELEMENT, propertyDefs);
		graph.addConfigDefinition(ProbeMain.ccmGateWayInfoConfigDef);
		
	}
}
