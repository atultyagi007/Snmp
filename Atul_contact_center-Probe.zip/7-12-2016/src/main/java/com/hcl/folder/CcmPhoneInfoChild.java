package com.hcl.folder;
import java.util.Map;

import com.nimsoft.ids.ctd.base.CtdConfig;
import com.nimsoft.ids.ctd.base.CtdConfigDefinition;
import com.nimsoft.ids.ctd.base.CtdEntity;
import com.nimsoft.nimbus.NimException;
import com.nimsoft.pf.common.graph.GraphHelper;
import com.nimsoft.probe.framework.devkit.interfaces.IInventoryDataset;
import com.nimsoft.probe.framework.devkit.inventory.Element;
import com.nimsoft.probe.framework.devkit.inventory.typedefs.EntityId;
import com.nimsoft.types.CcmPhoneInfo;

public class CcmPhoneInfoChild extends CcmPhoneInfo {
	 private GraphHelper graphHelper;
	    private Map<String, Object> valuesMap;
	    private CtdConfigDefinition ccmPhoneInfoConfigDef;

	    /**
	     * @param arg0
	     * @param arg1
	     * @param arg2
	     */
	    public CcmPhoneInfoChild(EntityId entityId, String nameLabel, Element... parents) {
	        super(entityId,nameLabel,parents);
	    }

	    @Override
	    public void setCtdEntity(CtdEntity ctdObj) {
	        String folderId = ctdObj.getId();
	        String idArray[] = folderId.split("idsProbe:");
	        CtdConfig config = this.graphHelper.checkAddConfig(idArray[1], ctdObj, this.ccmPhoneInfoConfigDef, valuesMap); 
	        this.ctdObject = ctdObj;
	    }

	    /**
	     * @param ds
	     * @param entityId
	     * @param nameLabel
	     * @param guiParent
	     * @return
	     * @throws NimException
	     * @throws InterruptedException
	     */
	    public static CcmPhoneInfoChild addInstance(IInventoryDataset ds, EntityId entityId, String nameLabel, Element guiParent)
	            throws NimException, InterruptedException {
	    	CcmPhoneInfoChild ctc = new CcmPhoneInfoChild(entityId, nameLabel, guiParent);
	        ds.addItem(ctc);
	        return ctc;
	    }

	    /**
	     * @param graphHelper the graphHelper to set
	     */
	    public void setGraphHelper(GraphHelper graphHelper) {
	        this.graphHelper = graphHelper;
	    }

	    /**
	     * @param valuesMap the valuesMap to set
	     */
	    public void setValuesMap(Map<String, Object> valuesMap) {
	        this.valuesMap = valuesMap;
	    }

	    /**
	     * @param sysGlobalConfigDef the sysGlobalConfigDef to set
	     */
	    public void setCcmPhoneInfoConfigDef(CtdConfigDefinition ccmPhoneInfoConfigDef) {
	        this.ccmPhoneInfoConfigDef = ccmPhoneInfoConfigDef;
	    }

}
