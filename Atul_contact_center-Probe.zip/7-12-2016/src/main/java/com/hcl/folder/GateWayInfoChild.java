package com.hcl.folder;

import java.util.Map;

import com.nimsoft.ids.ctd.base.CtdConfig;
import com.nimsoft.ids.ctd.base.CtdConfigDefinition;
import com.nimsoft.ids.ctd.base.CtdEntity;
import com.nimsoft.nimbus.NimException;
import com.nimsoft.pf.common.graph.GraphHelper;
import com.nimsoft.probe.framework.devkit.interfaces.IInventoryDataset;
import com.nimsoft.probe.framework.devkit.inventory.Element;
import com.nimsoft.probe.framework.devkit.inventory.typedefs.EntityId;
import com.nimsoft.types.GateWayInfo;

public class GateWayInfoChild extends GateWayInfo {
	private GraphHelper graphHelper;
    private Map<String, Object> valuesMap;
    private CtdConfigDefinition ccmGateWayInfoConfigDef;
    
    
    @Override
    public void setCtdEntity(CtdEntity ctdObj) {
        String folderId = ctdObj.getId();
        String idArray[] = folderId.split("idsProbe:");
        CtdConfig config = this.graphHelper.checkAddConfig(idArray[1], ctdObj, this.ccmGateWayInfoConfigDef, valuesMap); 
        this.ctdObject = ctdObj;
    }
	
	public static GateWayInfoChild addInstance(IInventoryDataset ds, EntityId entityId, String nameLabel, Element guiParent)
            throws NimException, InterruptedException {
		GateWayInfoChild ctc = new GateWayInfoChild(entityId, nameLabel, guiParent);
        ds.addItem(ctc);
        return ctc;
    }
	
	public GateWayInfoChild(EntityId entityId, String nameLabel, Element... parents) {
        super(entityId,nameLabel,parents);
    }

	public void setGraphHelper(GraphHelper graphHelper) {
		this.graphHelper = graphHelper;
	}

	public void setValuesMap(Map<String, Object> valuesMap) {
		this.valuesMap = valuesMap;
	}

	public void setCcmGateWayInfoConfigDef(CtdConfigDefinition ccmGateWayInfoConfigDef) {
		this.ccmGateWayInfoConfigDef = ccmGateWayInfoConfigDef;
	}
	
}
