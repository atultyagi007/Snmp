package com.hcl.folder;
import java.util.Map;

import com.nimsoft.ids.ctd.base.CtdConfig;
import com.nimsoft.ids.ctd.base.CtdConfigDefinition;
import com.nimsoft.ids.ctd.base.CtdEntity;
import com.nimsoft.nimbus.NimException;
import com.nimsoft.pf.common.graph.GraphHelper;
import com.nimsoft.probe.framework.devkit.interfaces.IInventoryDataset;
import com.nimsoft.probe.framework.devkit.inventory.Element;
import com.nimsoft.probe.framework.devkit.inventory.typedefs.EntityId;
import com.nimsoft.types.CcmGlobalInfo;

public class CcmGlobalInfoChild extends CcmGlobalInfo {
	
	private GraphHelper graphHelper;
    private Map<String, Object> valuesMap;
    private CtdConfigDefinition ccmGlobalInfoConfigDef;
	public CcmGlobalInfoChild(EntityId entityId, String nameLabel, Element... parents) {
        super(entityId,nameLabel,parents);
    }
	
	@Override
    public void setCtdEntity(CtdEntity ctdObj) {
        String folderId = ctdObj.getId();
        String idArray[] = folderId.split("idsProbe:");
        CtdConfig config = this.graphHelper.checkAddConfig(idArray[1], ctdObj, this.ccmGlobalInfoConfigDef, valuesMap); 
        this.ctdObject = ctdObj;
    }
	
	public static CcmGlobalInfoChild addInstance(IInventoryDataset ds, EntityId entityId, String nameLabel, Element guiParent)
            throws NimException, InterruptedException {
		CcmGlobalInfoChild ctc = new CcmGlobalInfoChild(entityId, nameLabel, guiParent);
        ds.addItem(ctc);
        return ctc;
    }

    /**
     * @param graphHelper the graphHelper to set
     */
    public void setGraphHelper(GraphHelper graphHelper) {
        this.graphHelper = graphHelper;
    }

    /**
     * @param valuesMap the valuesMap to set
     */
    public void setValuesMap(Map<String, Object> valuesMap) {
        this.valuesMap = valuesMap;
    }

    /**
     * @param sysGlobalConfigDef the sysGlobalConfigDef to set
     */
    public void setCcmGlobalInfoConfigDef(CtdConfigDefinition ccmGlobalInfoConfigDef) {
        this.ccmGlobalInfoConfigDef = ccmGlobalInfoConfigDef;
    }

}
