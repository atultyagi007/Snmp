package com.hcl.axl;

public final class AXLConstants {
	public static final String CONTENT_TYPE_KEY="Content-Type";
	public static final String CONTENT_TYPE_VALUE="application/text/xml";
	public static final String SOAP_ACTION_KEY="soapAction";
	public static final String AXL_CONFIG_FILE_NAME="axlConfig.properties";
	public static final String IP="ip";
	public static final String PORT="port";
	public static final String USERNAME="username";
	public static final String PASSWORD="password";
	public static final String AXL_CLASSES_FILE_NAME="classes.txt";
	
}
