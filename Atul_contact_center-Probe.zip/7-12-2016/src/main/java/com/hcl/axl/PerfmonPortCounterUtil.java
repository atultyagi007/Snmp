package com.hcl.axl;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.FutureTask;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import com.hcl.probe.Constants;
import com.nimsoft.pf.common.log.Log;

public final class PerfmonPortCounterUtil{
	private AXLClient axlClient;
	private BufferedReader classesReader;
	private final Map<String, Map<String,List<QOS>>> map=new Hashtable<String,Map<String,List<QOS>>>();
	private static PerfmonPortCounterUtil perfmonPortCounterImpl;
	private static final SAXParserFactory FACTORY = SAXParserFactory.newInstance();
	private PerfmonPortCounterUtil(AXLClient axlClient,BufferedReader classesReader){
		this.axlClient=axlClient;
		this.classesReader=classesReader;
	}
	public static final PerfmonPortCounterUtil getInstance()throws IOException,Exception{
		if(perfmonPortCounterImpl==null){
			final Properties axlConfig=new Properties();
			final Thread currentThread=Thread.currentThread();
			final ClassLoader classLoader=currentThread.getContextClassLoader();
			//System.out.println(classLoader);
			axlConfig.load(classLoader.getResourceAsStream(Constants.AXL_CONFIG_FILE_NAME));
			Log.info("Getting AXL Config file for setting credentials ======== "+Constants.AXL_CONFIG_FILE_NAME);
			final BufferedReader classesReader=new BufferedReader(new InputStreamReader(classLoader.getResourceAsStream(Constants.AXL_CLASSES_FILE_NAME)));
			final String ip=axlConfig.getProperty(Constants.IP);
			final int port=Integer.parseInt(axlConfig.getProperty(Constants.PORT));
			final String username=axlConfig.getProperty(Constants.USERNAME);
			final String password=axlConfig.getProperty(Constants.PASSWORD);
			Log.debug("Creating AXLClient with credentials =========== ");
			Log.debug("ip : "+ip);
			Log.debug("port : "+port);
			Log.debug("username : "+username);
			Log.debug("password : *******************");
			final AXLClient axlClient=new AXLClient(ip,port,username,password);
			perfmonPortCounterImpl=new PerfmonPortCounterUtil(axlClient,classesReader);
		}
		return perfmonPortCounterImpl;
	}
	
	private final class Task implements Runnable{
		private final PerfmonCollectCounterDataRequest perfmonCollectCounterDataRequest;
		private final String key;
		public Task(String key,PerfmonCollectCounterDataRequest perfmonCollectCounterDataRequest) {
			this.perfmonCollectCounterDataRequest=perfmonCollectCounterDataRequest;
			this.key=key;
		}
		
		public void run() {
			map.put(key,getResponse(perfmonCollectCounterDataRequest));
		}
		@Override
		public String toString() {
			return "Task[ permonCollectCounterDataRequest = "+perfmonCollectCounterDataRequest+", object = "+key+"]";
		}
	}
	private final Map<String,List<QOS>> getResponse(PerfmonCollectCounterDataRequest perfmonCollectCounterDataRequest){
		
		try{
			final SAXParser saxParser = FACTORY.newSAXParser();
			Log.error("Creating request to axlCient with request data ============= "+perfmonCollectCounterDataRequest);
			final AXLResponse response=axlClient.doService(perfmonCollectCounterDataRequest);
			//System.out.println("response : "+response);
	    	if(!response.isError()){
	    		final PerfmonCollectCounterDataXmlResponseHandler	perfmonCollectCounterDataXmlResponseHandler=new PerfmonCollectCounterDataXmlResponseHandler();
	    		saxParser.parse(response.getData(), perfmonCollectCounterDataXmlResponseHandler); 
	    		final Map<String, List<QOS>> parseResponse=perfmonCollectCounterDataXmlResponseHandler.getResponse();
	    		Log.error("Got Success response from axlCient with response data after parsing ============= "+parseResponse);
	    		return parseResponse;
	    	}
		}catch(Exception exception){
			Log.error("Error occured while getting response from axl server : ",exception);
		}
		return new HashMap<>();
	}
	
	public final Map<String, Map<String,List<QOS>>> getAXLList(String hostNameOrIp)throws Exception{
		final List<FutureTask<Boolean>> taskList=new ArrayList<FutureTask<Boolean>>();
		final ExecutorService executorService=Executors.newFixedThreadPool(5);
		String line="";
		
		while((line=classesReader.readLine())!=null){
			final String[] lines=line.split("=");
			if(lines[1].equalsIgnoreCase("Yes")){
				Log.info("Sending Request for enabled "+lines[0].trim());
				final PerfmonCollectCounterDataRequest perfmonCollectCounterDataRequest=new PerfmonCollectCounterDataRequest();
				perfmonCollectCounterDataRequest.setHost(hostNameOrIp);
				perfmonCollectCounterDataRequest.setCategory(lines[0]);
				final Task task=new Task(lines[0],perfmonCollectCounterDataRequest);
				final FutureTask<Boolean> futureTask=new FutureTask<Boolean>(task, true);
				taskList.add(futureTask);
				executorService.submit(futureTask);
			}
		}
		for (int j = 0; j < taskList.size(); j++) {
            final FutureTask<Boolean> futureTask=taskList.get(j);
            Log.info("result of futureTask : "+futureTask.get());
        }
		executorService.shutdownNow();
		return map;
	}
}
