package com.hcl.axl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class PerfmonCollectCounterDataXmlResponseHandler extends DefaultHandler{
	private boolean name = false;
	private boolean value = false;
	private String nameString=null;
	private String valueString=null;
	private final Map<String,List<QOS>> response=new HashMap<String,List<QOS>>();
	   @Override
	   public void startElement(String uri, 
	      String localName, String qName, Attributes attributes)
	         throws SAXException {
	      if (qName.equalsIgnoreCase("name")) {
	    	  name=true;
	      } else if (qName.equalsIgnoreCase("value")) {
	         value = true;
	      } 
	   }

	   @Override
	   public void endElement(String uri, 
	      String localName, String qName) throws SAXException {
	      if (qName.equalsIgnoreCase("student")) {
	         System.out.println("End Element :" + qName);
	      }
	   }

	   @Override
	   public void characters(char ch[], int start, int length) throws SAXException {
	      if (name) {
	    	 nameString=new String(ch,start,length);
	         name = false;
	      } else if (value) {
	    	  valueString=new String(ch,start,length);
	         value = false;
	      } 
	      if(nameString!=null&&valueString!=null){
	    	  final int keyIndex=nameString.lastIndexOf("\\");
	    	  final String keyString=nameString.substring(keyIndex+1);
	    	  final int startIndex=nameString.indexOf("(");
	    	  final int endIndex=nameString.indexOf(")");
	    	  String subName="";
	    	  if(startIndex!=-1||endIndex!=-1){
	    		  subName=nameString.substring(startIndex+1,endIndex);
	    	  }else{
	    		  final int newIndex=nameString.lastIndexOf("\\", keyIndex-1);;
	    		  subName=nameString.substring(newIndex+1, keyIndex);
	    	  }
	    		  
	    	  if(response.containsKey(subName)){
	    		  final QOS qos=new QOS();
	    		  qos.setKey(keyString);
	    		  qos.setValue(Long.parseLong(valueString));
	    		  response.get(subName).add(qos);
	    	  }else{
	    		  final List<QOS> qoses=new ArrayList<QOS>(2);
	    		  final QOS qos=new QOS();
	    		  qos.setKey(keyString);
	    		  qos.setValue(Long.parseLong(valueString));
	    		  qoses.add(qos);
	    		  response.put(subName, qoses);
	    	  }
	    	  nameString=null;
	    	  valueString=null;
	      }
	   }
	   public Map<String,List<QOS>> getResponse() {
		   return response;
	   }
}
