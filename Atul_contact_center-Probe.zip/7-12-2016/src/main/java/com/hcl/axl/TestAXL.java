package com.hcl.axl;

import java.io.IOException;
import java.net.MalformedURLException;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class TestAXL {
	private static final String IP="10.112.77.128";
public static void main(String[] args) throws MalformedURLException,IOException,Exception {
		
		final PerfmonPortCounterUtil perfmonPortCounterImpl=PerfmonPortCounterUtil.getInstance();
		long tStart = System.currentTimeMillis();
		final Map<String,Map<String,List<QOS>>> map=perfmonPortCounterImpl.getAXLList(IP);
		long tElapsed=System.currentTimeMillis()-tStart;
		System.out.println("time taken " + tElapsed + " ms");
		
		final Set<String> set=map.keySet();
		for(final String element:set){
			System.out.println(element);
			final Map<String, List<QOS>> map1=map.get(element);
			final Set<String> set1=map1.keySet();
			for(String element1:set1){
				System.out.println("=====> "+element1);
				for(final QOS qos:map1.get(element1)){
					System.out.println("=============> "+qos);
				}
			}
			System.out.println("");
		}
		
		
	}
}
