package com.hcl.axl;

import java.io.IOException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;

import javax.net.ssl.HttpsURLConnection;

import org.apache.commons.codec.binary.Base64;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.ssl.TrustStrategy;

import com.hcl.probe.Constants;
import com.nimsoft.pf.common.log.Log;

public final class AXLClient {
	private final String authorization;
	private final String ip;
	private final int port;
	private static HttpClient HTTP_CLIENT;
	static{
		try{
			HTTP_CLIENT=HttpClients.custom().setSSLHostnameVerifier(new NoopHostnameVerifier()).setSslcontext(new SSLContextBuilder().loadTrustMaterial(null,new TrustStrategy() {	
				public boolean isTrusted(X509Certificate[] arg0, String arg1)
						throws CertificateException {
					return true;
				}
			}).build()).build();
		}catch(Exception exception){
			Log.error("Error occured while creating secure httpClient for AxlClient",exception);
		}
	}
	public AXLClient(String ip, int port, String username,String password){
		this.ip=ip;
		this.port=port;
		this.authorization=Base64.encodeBase64String((username+":"+password).getBytes());
	}
    public final AXLResponse doService(AXLRequest request)throws IOException,Exception{
    	final HttpPost postRequest = new HttpPost("https://"+ip+":"+port+request.getUrl());
		postRequest.setHeader("Authorization","Basic "+authorization);
		postRequest.setHeader(Constants.SOAP_ACTION_KEY,request.getSoapAction());
		final StringEntity entity=new StringEntity(request.getBody());
		entity.setContentType(Constants.CONTENT_TYPE_VALUE);
		postRequest.setEntity(entity);
		final HttpResponse httpResponse = HTTP_CLIENT.execute(postRequest);
		final AXLResponse axlResponse=new AXLResponse();        //Read the response
    	if(httpResponse.getStatusLine().getStatusCode()==HttpsURLConnection.HTTP_OK){
        	axlResponse.setError(false);
        }else{
        	axlResponse.setError(true);
        }
    	Log.info("Response Code : "+httpResponse.getStatusLine().getStatusCode()+" Response Message : "+httpResponse.getStatusLine().getReasonPhrase());
    	axlResponse.setData(httpResponse.getEntity().getContent());
    	axlResponse.setResponseCode(httpResponse.getStatusLine().getStatusCode());
    	axlResponse.setResponseMessage(httpResponse.getStatusLine().getReasonPhrase());
        return axlResponse;
    }
}