package com.hcl.axl;

import java.io.InputStream;

public class AXLResponse {
	private boolean error;
	private InputStream data;
	private int responseCode;
	private String responseMessage;
	public boolean isError() {
		return error;
	}
	public void setError(boolean error) {
		this.error = error;
	}
	public InputStream getData() {
		return data;
	}
	public void setData(InputStream data) {
		this.data = data;
	}
	public int getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(int responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponseMessage() {
		return responseMessage;
	}
	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}
	@Override
	public String toString() {
		return "AXLResponse [error=" + error + ", data=" + data + ", responseCode=" + responseCode
				+ ", responseMessage=" + responseMessage + "]";
	}
	
}
