package com.hcl.axl;

public abstract class AXLRequest {
	private String body;
	private String url="/axl";
	private String soapAction="CUCM:DB ver=10.0";
	public String getBody() {
		return body;
	}
	public String getUrl() {
		return url;
	}
	public String getSoapAction() {
		return soapAction;
	}
	@Override
	public String toString() {
		return "AXLRequest [body=" + body + ", url=" + url + ", soapAction=" + soapAction + "]";
	}
}
