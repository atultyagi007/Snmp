package com.hcl.axl;

public final class PerfmonCollectCounterDataRequest extends AXLRequest{
	private String host;
	private String category;
	private static final String SOAP_ACTION="http://schemas.cisco.com/ast/soap/action/#PerfmonPort#perfmonCollectCounterData";
	private static String URL="/perfmonservice/services/PerfmonPort";
	public String getHost() {
		return host;
	}
	public void setHost(String host) {
		this.host = host;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	@Override
	public String getSoapAction() {
		return super.getSoapAction()+" "+SOAP_ACTION;
	}
	@Override
	public String getUrl() {
		return URL;
	}
	@Override
	public String getBody() {
		final String b="<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:soap=\"http://schemas.cisco.com/ast/soap\">"
				+"<soapenv:Header/>"
			   +"<soapenv:Body>"
			      +"<soap:perfmonCollectCounterData>"
			         +"<soap:Host>"+host+"</soap:Host>"
			         +"<soap:Object>"+category+"</soap:Object>"
			      +"</soap:perfmonCollectCounterData>"
			   +"</soapenv:Body>"
			+"</soapenv:Envelope>";
		return b;
	}
	@Override
	public String toString() {
		return "PerfmonCollectCounterDataRequest [host=" + host + ", category=" + category +", soapAction=" + getSoapAction()+", url=" + URL+", body=" + getBody()+ "]";
	}
	
}
