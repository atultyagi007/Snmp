package com.hcl.probe;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class OidListReader {
	public List<OidForm> messageList;

	public static ConcurrentHashMap<String,ConcurrentHashMap<String, ArrayList<OidForm>>> getOidList(InputStream fXmlFile) {


		ConcurrentHashMap<String,ConcurrentHashMap<String, ArrayList<OidForm>>> groupList =null;
		ConcurrentHashMap<String, ArrayList<OidForm>> elementMap=null;
		
		try{
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(fXmlFile);
			NodeList groupListNode = doc.getElementsByTagName("group");
			
			groupList=new ConcurrentHashMap<String,ConcurrentHashMap<String, ArrayList<OidForm>>>();
			for(int groupCount = 0; groupCount < groupListNode.getLength(); groupCount++){
				elementMap = new ConcurrentHashMap<String, ArrayList<OidForm>>();
				Node groupNode = groupListNode.item(groupCount);
				Element groupElement = (Element) groupNode;
				String groupName=groupElement.getAttribute("name");
				NodeList elementList = groupElement.getElementsByTagName("element");
				
				
				for (int elementCount = 0;elementCount < elementList.getLength(); elementCount++) {
					Node nNode1 = elementList.item(elementCount);
					Element elementNode = (Element) nNode1;
					String elementName=elementNode.getAttribute("name");
					NodeList listOid = elementNode.getElementsByTagName("oid");
					ArrayList<OidForm> oidFormList=new ArrayList<OidForm>();
					
					for (int oidCount = 0;oidCount < listOid.getLength(); oidCount++) {
						Node oidNode = listOid.item(oidCount);
						Element oidElement = (Element) oidNode;
						OidForm oidForm=new OidForm();
						oidForm.setOidName(oidElement.getAttribute("name").trim());
						oidForm.setElement(oidElement.getAttribute("element").trim());
						oidForm.setMetricName(oidElement.getAttribute("metricName").trim());
						oidForm.setOidValue(oidElement.getAttribute("value").trim());
						oidFormList.add(oidForm);
						
					}
					elementMap.put(elementName, oidFormList);
				}
				groupList.put(groupName,elementMap);
			}
			
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return groupList;
		}
	
}
