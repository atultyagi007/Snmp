package com.hcl.probe;

public class QosForm {
	private String oidName;
	private String oidValue;
	private String element;
	private String metricName;
	private String description;
	private String index;
	private String qos;
	public String getOidName() {
		return oidName;
	}
	public void setOidName(String oidName) {
		this.oidName = oidName;
	}
	public String getOidValue() {
		return oidValue;
	}
	public String getIndex() {
		return index;
	}
	public void setIndex(String index) {
		this.index = index;
	}
	public void setOidValue(String oidValue) {
		this.oidValue = oidValue;
	}
	public String getElement() {
		return element;
	}
	public void setElement(String element) {
		this.element = element;
	}
	public String getMetricName() {
		return metricName;
	}
	public void setMetricName(String metricName) {
		this.metricName = metricName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getQos() {
		return qos;
	}
	public void setQos(String qos) {
		this.qos = qos;
	}
	

}
