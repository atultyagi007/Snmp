package com.hcl.probe;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Vector;
import java.util.concurrent.ConcurrentHashMap;
import org.snmp4j.smi.VariableBinding;
import com.hcl.axl.PerfmonPortCounterUtil;
import com.hcl.axl.QOS;
import com.hcl.snmp.ListenerThread;
import com.hcl.snmp.SNMPUtils;
import com.hcl.snmp.SnmpCreditionals;
import com.hcl.util.ConfigBuildUtil;
import com.hcl.util.QOSUtil;
import com.nimsoft.ids.ctd.base.CtdConfigDefinition;
import com.nimsoft.ids.ctd.base.CtdOptionList;
import com.nimsoft.ids.ctd.base.CtdOptionList.CtdOptionListBuilder;
import com.nimsoft.ids.ctd.ui.CtdOption;
import com.nimsoft.ids.ctd.ui.definitions.CtdDropDownDefinition;
import com.nimsoft.ids.ctd.ui.definitions.CtdNumberDefinition;
import com.nimsoft.nimbus.NimException;
import com.nimsoft.pf.common.log.Log;
import com.nimsoft.pf.common.pom.MvnPomVersion;
import com.nimsoft.probe.framework.devkit.InventoryDataset;
import com.nimsoft.probe.framework.devkit.ProbeBase;
import com.nimsoft.probe.framework.devkit.configuration.CtdPropertyDefinitionsList;
import com.nimsoft.probe.framework.devkit.configuration.ResourceConfig;
import com.nimsoft.probe.framework.devkit.interfaces.IInventoryDataset;
import com.nimsoft.probe.framework.devkit.interfaces.IProbeInventoryCollection;
import com.nimsoft.probe.framework.devkit.inventory.Folder;
import com.nimsoft.probe.framework.devkit.inventory.typedefs.ElementDef;
import com.nimsoft.probe.framework.devkit.inventory.typedefs.EntityId;
import com.nimsoft.vm.cfg.IProbeResourceTypeInfo;

public class ProbeMain extends ProbeBase implements IProbeInventoryCollection {

	/*
	 * Probe Name, Version, and Vendor are required when initializing the probe.
	 */
	public final static  String PROBE_NAME = "contact_center";
	public static final  String PROBE_VERSION = MvnPomVersion.get("com.hcl", PROBE_NAME);
	public static final  String PROBE_VENDOR = "com.hcl";
	public static final  String HOST_NAME = "hostName";
	public static final  String PORT = "Port";
	public static final  String COMMUNITY_STRING = "community_string";
	public static final  String VERSION = "version";
	public static final  String SYSOID = "1.3.6.1.2.1.1.2.0";
	public static final  String TYPE = "TYPE";
	public static CtdConfigDefinition sysGlobalConfigDef;
	public static CtdConfigDefinition cucmGroupConfigDef;
	public static CtdConfigDefinition cucmTableConfigDef;
	public static CtdConfigDefinition h323DeviceConfigDef;
	public static CtdConfigDefinition ccmPhoneInfoConfigDef;
	public static ResourceConfig resourceConfig1; 
	public static CtdConfigDefinition ccmGlobalInfoConfigDef;
	public static CtdConfigDefinition ccmGateWayInfoConfigDef;
	public static CtdConfigDefinition ccmGlobalTrunkConfigDef;
	public static CtdConfigDefinition cucmGroupTableConfigDef;
	public static CtdConfigDefinition cccaGeneralInfoConfigDef;
	public static CtdConfigDefinition cccaInstanceTableConfigDef;
	public static CtdConfigDefinition cccaRouterTableConfigDef;
	public static CtdConfigDefinition cccaLoggerTableConfigDef;
	public static CtdConfigDefinition cccaDistAWTableConfigDef;  
	public static CtdConfigDefinition cccaPgTableConfigDef;
	public static CtdConfigDefinition cccaCgTableConfigDef;
	public static CtdConfigDefinition cccaComponentTableConfigDef;
	public static CtdConfigDefinition cccaPimTableConfigDef;
	

	/**
	 * Every probe is a stand alone Java program that must start itself up and
	 * register itself with the bus. The Probe Framework provides all the logic
	 * for doing this in the {@code ProbeBase} base class. So all we must do when
	 * implementing a probe is create a simple {@code main()} method that invokes
	 * the proper life cycle methods in {@code ProbeBase}
	 *
	 * @param args
	 */
	public static void main(final String[] args) {
		try {
			ProbeBase.initLogging(args);
			ProbeMain probeProcess = new ProbeMain(args);
			Log.info("Probe " + PROBE_NAME + " startup");
			ListenerThread listenerThread = new ListenerThread();
			listenerThread.setName("ListenerThread");
			listenerThread.start();
			probeProcess.execute();
			
		} catch (final Exception e) {
			ProbeBase.reportProbeStartupError(e, PROBE_NAME);
		}
	}

	/**
	 * You must implement a constructor that calls the super constructor 
	 * and passes in the parameters shown below. You will call your 
	 * constructor from the main() method and you may modify the method
	 * signature to suit your needs. For example if you wanted to pass some
	 * additional arguments. 
	 * @throws NimException
	 */
	public ProbeMain(String[] args) throws NimException {
		super(args, PROBE_NAME, PROBE_VERSION, PROBE_VENDOR);
	}

	/**
	 * This is where you configure what you want to display in the probe configuration UI.
	 * 
	 * Note: Implementing this method is optional. If your probe does not require the ability to
	 * specify configuration options in the Probe Configuration UI then you may skip implementing
	 * this method.
	 */
	@Override
	public void addDefaultProbeConfigurationToGraph() {
		// Add standard actions to add/delete/verify a profile
		ElementDef resDef = ElementDef.getElementDef("RESOURCE");
		resDef.addStandardAction(IProbeResourceTypeInfo.StandardActionType.DeleteProfileAction);
		resDef.addStandardAction(IProbeResourceTypeInfo.StandardActionType.VerifySelectionAction, "Verify Profile Configuration");
		resDef.addStandardAction(IProbeResourceTypeInfo.StandardActionType.AddProfileActionOnProbe, "Add Profile");
		// Set the properties that will be available when a new profile is created in the probe configuration UI
		CtdPropertyDefinitionsList profilePropDefs = CtdPropertyDefinitionsList.createCtdPropertyDefinitionsList("RESOURCE", getGraph());
		profilePropDefs.addStandardIdentifierProperty();
		// Remote probes require host/port/user/password
		profilePropDefs.addStandardHostProperty();
		CtdNumberDefinition standardPort= profilePropDefs.addStandardPortProperty();
		standardPort.setDefaultValue(161);
		//        profilePropDefs.addStandardPasswordProperty();
		profilePropDefs.addStandardAlarmMessageProperty();
		profilePropDefs.addStandardIntervalProperty();
		profilePropDefs.addStandardActiveProperty();
		/*profilePropDefs.addStringPropertyUsingEditField(HOST_NAME, "Host Name","");*/
		/*profilePropDefs.addStringPropertyUsingEditField(PORT, "Port","161");*/
		profilePropDefs.addStringPropertyUsingEditField(COMMUNITY_STRING, "Community String","");
		profilePropDefs.addStringPropertyUsingEditField(VERSION, "Version","");
		
		// this peice of code is required to add drop down
		final Map<String, String> dropDownOptions = new ConcurrentHashMap<String, String>();
		dropDownOptions.put("CUCM", "CUCM");
		dropDownOptions.put("UCCX", "UCCX");
		dropDownOptions.put("UCCE", "UCCE");
		CtdOptionList options=createOptionList("Typeffff", dropDownOptions);
		
		final List<CtdOption> values = new ArrayList<CtdOption>();

        for (final Map.Entry<String, String> entry : dropDownOptions.entrySet()) {
            final CtdOption option = new CtdOption(entry.getKey(), entry.getValue());
            values.add(option);
        }

		final CtdOption[] optionValues = values.toArray(new CtdOption[0]);
		final CtdOptionList optionList = CtdOptionListBuilder.builder().setName("Type" + "_option").setOptions(optionValues).build();
		getGraph().addOptionList(optionList);
		CtdDropDownDefinition ctdDropDownDefinition = profilePropDefs.addStringPropertyUsingDropDownField("TYPE", "TYPE", "CUCM", options);
		ctdDropDownDefinition.setOptionListName("Type" + "_option");

		//----------------
		// You must always invoke the super method
		super.addDefaultProbeConfigurationToGraph();
	}

	public static CtdOptionList createOptionList(final String fieldName, final Map<String, String> dropDownOptions) {
		final List<CtdOption> values = new ArrayList<CtdOption>();

		for (final Map.Entry<String, String> entry : dropDownOptions.entrySet()) {
			final CtdOption option = new CtdOption(entry.getKey(), entry.getValue());
			values.add(option);
		}

		final CtdOption[] optionValues = values.toArray(new CtdOption[0]);
		final CtdOptionList optionList = CtdOptionListBuilder.builder().setName(fieldName + "_option").setOptions(optionValues).build();
		return optionList;
	}
	/**
	 * Allows the user to test a profile configuration from the UI by using 
	 * the pull down: Actions->verify.
	 * </p>
	 * All probe framework probes must implement this method.
	 * </p>
	 * The method should be implemented to validate the probe configuration. For example
	 * if the configuration specifies remote system connectivity information. If unable 
	 * to successfully verify the configuration then this method should throw an {@code Exception}
	 * with a message about the nature of the problem.
	 * </p>
	 * Note: The tests performed here do not need to be limited to connectivity. You should verify
	 * anything and everything related to your probe configuration.
	 * 
	 * Note: The methods {@code testResource()} and {@code getUpdatedInventory()} are both from the 
	 * interface {@code IProbeInventoryCollection}. You will need to implement these methods if your 
	 * probe implements {@code IProbeInventoryCollection}. Please see the JavaDoc on that interface 
	 * for more details.
	 * 
	 * @param resource Configuration information.
	 *
	 * @return IInventoryDataset Optional. This is reserved for a future enhancement for an advanced probe 
	 * to provide additional resource configuration information. However this is presently not used,
	 * so the best practice is to return {@code null}
	 *
	 * @throws Exception if any errors are encountered during the testing of the configuration.
	 */
	@Override
	public IInventoryDataset testResource(ResourceConfig res) throws NimException, InterruptedException { 
		Log.info("==== testResource: " + res.getName());

		/**
		 * ***** Insert your test logic here *****
		 * If your test is successful you need not do anything, simply 
		 * allow this method to return null. If you need to report an error
		 * then throw a NimException
		 */

		// If we get to here then our tests were successful. Since we dont have 
		// any advanced information we wish to return we can simply return null

		return null;
	}

	/**
	 * This is called by the framework on the inventory collection cycle. In this method 
	 * we construct the inventory, and attach metrics. We always attach all metrics, and the
	 * framework will determine which ones to publish based on how the probe is configured.
	 * 
	 * We return data to the framework in both the returned InventoryDataset, AND the passed
	 * in ResourceConfig. Every inventory Element you create will be attached to the InventoryDataset,
	 * those Elements must also be constructed in a hierarchy attached to ResourceConfig.
	 * 
	 * Note: The methods {@code testResource()} and {@code getUpdatedInventory()} are both from the 
	 * interface {@code IProbeInventoryCollection}. You will need to implement these methods if your 
	 * probe implements {@code IProbeInventoryCollection}. Please see the JavaDoc on that interface 
	 * for more details.
	 */
	@Override
	public IInventoryDataset getUpdatedInventory(final ResourceConfig resourceConfig, IInventoryDataset previousDataset) throws NimException, InterruptedException {
		// A recommended best practice is to read configuration information
		// on each call to getUpdatedInventory(). This ensures configuration changes
		// take effect without the need for a full restart of the probe.
		// Also, please note that the configuration information is cached by the 
		// framework, so there is very low overhead here.
		int counter = resourceConfig.updateCounter;
		Log.info("==== Begin getUpdatedInventory: Pass-" + counter + "   " + resourceConfig.getName());
		// Create a new empty InventoryDataset
		
		InventoryDataset inventoryDataset = new InventoryDataset(resourceConfig);
		String hostName = resourceConfig.getResourceProperty("host");
		if (hostName == null || hostName.isEmpty()) {
			String errMsg = "No hostName   Specified.";
			Log.error("testResource: " + resourceConfig.getName() + "   " + errMsg);
			throw new NimException(NimException.E_ERROR, errMsg);
		} 
		if(deviceDiscovery(resourceConfig)){
			SnmpCreditionals snmpCreditionals =new SnmpCreditionals();
			snmpCreditionals = getSnmpCredentials(resourceConfig);
			if(snmpCreditionals.getType().equalsIgnoreCase("CUCM")){
				inventoryDataset=getUpdatedInventoryCUCM(resourceConfig);
			}else if(snmpCreditionals.getType().equalsIgnoreCase("UCCX")){
				inventoryDataset=getUpdatedInventoryUCCX(resourceConfig);
			}else if(snmpCreditionals.getType().equalsIgnoreCase("UCCE")){
				inventoryDataset=getUpdatedInventoryUCCE(resourceConfig);
			}
			return inventoryDataset;
			}else{
			Log.error("Device Discovery Failed: "+hostName);
			throw new NimException(NimException.E_ERROR,"Failed to discover device "+hostName);
		}        
	}  
	public SnmpCreditionals getSnmpCredentials(ResourceConfig resourceConfig) throws NimException {
		SnmpCreditionals snmpCreditionals =new SnmpCreditionals();
		String communityString = resourceConfig.getResourceProperty(COMMUNITY_STRING);
		String type = resourceConfig.getResourceProperty(TYPE);
		if (communityString == null || communityString.isEmpty()) {
			String errMsg = "No Community String  Specified.";
			Log.error("testResource: " + resourceConfig.getName() + "   " + errMsg);
			throw new NimException(NimException.E_ERROR, errMsg);
		}
		String version = resourceConfig.getResourceProperty(VERSION);
		if (version == null || version.isEmpty()) {
			String errMsg = "No Version String  Specified.";
			Log.error("testResource: " + resourceConfig.getName() + "   " + errMsg);
			throw new NimException(NimException.E_ERROR, errMsg);
		}

		String hostName = resourceConfig.getResourceProperty("host");
		if (hostName == null || hostName.isEmpty()) {
			String errMsg = "No hostName   Specified.";
			Log.error("testResource: " + resourceConfig.getName() + "   " + errMsg);
			throw new NimException(NimException.E_ERROR, errMsg);
		}
		String port = resourceConfig.getResourceProperty("port");
		if (port == null || port.isEmpty()) {
			String errMsg = "No port   Specified.";
			Log.error("testResource: " + resourceConfig.getName() + "   " + errMsg);
			throw new NimException(NimException.E_ERROR, errMsg);
		}
		snmpCreditionals.setIpAddress(hostName);
		snmpCreditionals.setPort(port);
		snmpCreditionals.setCommunity(communityString);
		snmpCreditionals.setVersion(version);
		snmpCreditionals.setType(type);
		return snmpCreditionals;
	}
	public boolean deviceDiscovery(ResourceConfig resourceConfig) throws NimException{
		SnmpCreditionals snmpCreditionals =new SnmpCreditionals();
		snmpCreditionals = getSnmpCredentials(resourceConfig);
		snmpCreditionals.setRequestType("GET");
		List<String> oIdList=new ArrayList<String>();
		boolean deviceDiscovered = false;
		oIdList.add(SYSOID);
		Vector<? extends VariableBinding> variableBinding= SNMPUtils.poll(snmpCreditionals, oIdList);
		if(variableBinding != null && variableBinding.size() != 0){
			Log.info(snmpCreditionals.getIpAddress() + " SysObjectId: "+ variableBinding.get(0).getVariable());
			deviceDiscovered = true;
		} 
		return deviceDiscovered;
	}
	
	public InventoryDataset getUpdatedInventoryUCCX(ResourceConfig resourceConfig) {
		InventoryDataset inventoryDataset = null;
		try {
			inventoryDataset=new InventoryDataset(resourceConfig);
			final SnmpCreditionals snmpCreditionals = getSnmpCredentials(resourceConfig);
			snmpCreditionals.setRequestType("GET");
			String fileName="/UCCX_OidList.txt";
			InputStream in = getClass().getResourceAsStream(fileName); 
			ConcurrentHashMap<String,ConcurrentHashMap<String, ArrayList<OidForm>>>	 oidListMap = OidListReader.getOidList(in);
			ConcurrentHashMap<String,ConcurrentHashMap<String,IndexElement>> oidIndexList = QOSUtil.getOidIndexList(oidListMap,snmpCreditionals);
			ConcurrentHashMap<String,ConcurrentHashMap<String,ConcurrentHashMap<String,ArrayList<QosForm>>>> pollOidList = QOSUtil.pollOid(oidIndexList,snmpCreditionals);
			Set<String> groupSet=pollOidList.keySet();
			for (String group : groupSet) {
				if (group.equalsIgnoreCase(Constants.UCCX_HOST_RESOURCE)) {
					Folder hostResourceFolder = Folder.addInstance(inventoryDataset, new EntityId(resourceConfig, Constants.HOST_RESOURCE_ELEMENT), Constants.HOST_RESOURCE_ELEMENT, resourceConfig);
					Folder processorFolder = Folder.addInstance(inventoryDataset, new EntityId(hostResourceFolder, Constants.PROCESSOR), Constants.PROCESSOR, hostResourceFolder);
					Folder memoryFolder = Folder.addInstance(inventoryDataset, new EntityId(hostResourceFolder, Constants.MEMORY_VOLUME), Constants.MEMORY_VOLUME, hostResourceFolder);
					ConcurrentHashMap<String,ConcurrentHashMap<String,ArrayList<QosForm>>> groupList = pollOidList.get(group);
					Set<String> elementSet = groupList.keySet();
					for(String element:elementSet){
						if(element.equalsIgnoreCase(Constants.UCCX_PROCESSOR)){
							ConcurrentHashMap<String,ArrayList<QosForm>> pollOidElement = groupList.get(element);
							QOSUtil.getQOSForUCCXProcessors(pollOidElement,processorFolder,inventoryDataset,snmpCreditionals);
						}
						if (element.equalsIgnoreCase(Constants.UCCX_MEMORY)) {
							ConcurrentHashMap<String,ArrayList<QosForm>> pollOidElement = groupList.get(element);
							QOSUtil.getQOSForUCCXMemory(pollOidElement, memoryFolder, inventoryDataset, snmpCreditionals);
						}
					}
				}
				if(group.equalsIgnoreCase(Constants.UCCX_INTERFACE)){
					Folder interfaceFolder = Folder.addInstance(inventoryDataset, new EntityId(resourceConfig, Constants.INTERFACE), Constants.INTERFACE, resourceConfig);
					ConcurrentHashMap<String,ConcurrentHashMap<String,ArrayList<QosForm>>> groupList = pollOidList.get(group);
					Set<String> elementSet = groupList.keySet();
					for(String element:elementSet){
						if(element.equalsIgnoreCase(Constants.UCCX_INTERFACE)){
							ConcurrentHashMap<String,ArrayList<QosForm>> pollOidElement = groupList.get(element);
							QOSUtil.getQOSForUCCXInterface(pollOidElement,interfaceFolder,inventoryDataset,snmpCreditionals);
						}
					}
				}else if(group.equalsIgnoreCase(Constants.UCCX_SOFTWARE)){
					Folder processfaceFolder = Folder.addInstance(inventoryDataset, new EntityId(resourceConfig, Constants.PROCESSES), Constants.PROCESSES, resourceConfig);
					ConcurrentHashMap<String,ConcurrentHashMap<String,ArrayList<QosForm>>> groupList = pollOidList.get(group);
					Set<String> elementSet = groupList.keySet();
					for(String element:elementSet){
						if(element.equalsIgnoreCase(Constants.UCCX_SOFTWARE)){
							ConcurrentHashMap<String,ArrayList<QosForm>> pollOidElement = groupList.get(element);
							QOSUtil.getQOSForUCCXProcess(pollOidElement,processfaceFolder,inventoryDataset,snmpCreditionals);
						}
					}
				}else if(group.equalsIgnoreCase(Constants.SYSTEM_PROPERTY)){
					Folder sysGlobalFolder = Folder.addInstance(inventoryDataset, new EntityId(resourceConfig, Constants.SYSTEM_PROPERTY), Constants.SYSTEM_PROPERTY, resourceConfig);
					ConcurrentHashMap<String,ConcurrentHashMap<String,ArrayList<QosForm>>> groupList=pollOidList.get(group);
					Set<String> elementSet = groupList.keySet();
					for( String element:elementSet){
						if(element.equalsIgnoreCase(Constants.SYSTEM_PROPERTY)){
							ConfigBuildUtil.buildSystemPropertyConfig(getGraph());
							ConcurrentHashMap<String,ArrayList<QosForm>> pollOidElement=groupList.get(element);
							ConfigBuildUtil.createSystemPropertyFolder(snmpCreditionals, pollOidElement, sysGlobalFolder, inventoryDataset, getGraph());
						}
					}
					
				}
			}
		} catch (Exception ex) {
			Log.error("Exception occour "+ex);
		}
		return inventoryDataset;
	}
	
	public InventoryDataset getUpdatedInventoryUCCE(ResourceConfig resourceConfig) {
		InventoryDataset inventoryDataset = null;
		try {
			inventoryDataset=new InventoryDataset(resourceConfig);
			final SnmpCreditionals snmpCreditionals = getSnmpCredentials(resourceConfig);
			snmpCreditionals.setRequestType("GET");
			String fileName="/UCCE_OidList.txt";
			InputStream in = getClass().getResourceAsStream(fileName); 
			ConcurrentHashMap<String,ConcurrentHashMap<String, ArrayList<OidForm>>>	 oidListMap = OidListReader.getOidList(in);
			ConcurrentHashMap<String,ConcurrentHashMap<String,IndexElement>> oidIndexList = QOSUtil.getOidIndexList(oidListMap,snmpCreditionals);
			ConcurrentHashMap<String,ConcurrentHashMap<String,ConcurrentHashMap<String,ArrayList<QosForm>>>> pollOidList = QOSUtil.pollOid(oidIndexList,snmpCreditionals);
			Set<String> groupSet=pollOidList.keySet();
			for (String group : groupSet) {
				if (group.equalsIgnoreCase(Constants.UCCE_HOST_RESOURCE)) {
					Folder hostResourceFolder = Folder.addInstance(inventoryDataset, new EntityId(resourceConfig, Constants.HOST_RESOURCE_ELEMENT), Constants.HOST_RESOURCE_ELEMENT, resourceConfig);
					Folder processorFolder = Folder.addInstance(inventoryDataset, new EntityId(hostResourceFolder, Constants.PROCESSOR), Constants.PROCESSOR, hostResourceFolder);
					Folder memoryFolder = Folder.addInstance(inventoryDataset, new EntityId(hostResourceFolder, Constants.MEMORY_VOLUME), Constants.MEMORY_VOLUME, hostResourceFolder);
					ConcurrentHashMap<String,ConcurrentHashMap<String,ArrayList<QosForm>>> groupList = pollOidList.get(group);
					Set<String> elementSet = groupList.keySet();
					for(String element:elementSet){
						if(element.equalsIgnoreCase(Constants.UCCE_PROCESSOR)){
							ConcurrentHashMap<String,ArrayList<QosForm>> pollOidElement = groupList.get(element);
							QOSUtil.getQOSForUCCEProcessors(pollOidElement,processorFolder,inventoryDataset,snmpCreditionals);
						}
						if (element.equalsIgnoreCase(Constants.UCCE_MEMORY)) {
							ConcurrentHashMap<String,ArrayList<QosForm>> pollOidElement = groupList.get(element);
							QOSUtil.getQOSForUCCEMemory(pollOidElement, memoryFolder, inventoryDataset, snmpCreditionals);
						}
					}

				}
				if(group.equalsIgnoreCase(Constants.UCCE_INTERFACE)){
					Folder interfaceFolder = Folder.addInstance(inventoryDataset, new EntityId(resourceConfig, Constants.INTERFACE), Constants.INTERFACE, resourceConfig);
					ConcurrentHashMap<String,ConcurrentHashMap<String,ArrayList<QosForm>>> groupList = pollOidList.get(group);
					Set<String> elementSet = groupList.keySet();
					for(String element:elementSet){
						if(element.equalsIgnoreCase(Constants.UCCE_INTERFACE)){
							ConcurrentHashMap<String,ArrayList<QosForm>> pollOidElement = groupList.get(element);
							QOSUtil.getQOSForUCCEInterface(pollOidElement,interfaceFolder,inventoryDataset,snmpCreditionals);
						}
					}
				} if(group.equalsIgnoreCase(Constants.UCCE_SOFTWARE)){
					Folder processfaceFolder = Folder.addInstance(inventoryDataset, new EntityId(resourceConfig, Constants.PROCESSES), Constants.PROCESSES, resourceConfig);
					ConcurrentHashMap<String,ConcurrentHashMap<String,ArrayList<QosForm>>> groupList = pollOidList.get(group);
					Set<String> elementSet = groupList.keySet();
					for(String element:elementSet){
						if(element.equalsIgnoreCase(Constants.UCCE_SOFTWARE)){
							ConcurrentHashMap<String,ArrayList<QosForm>> pollOidElement = groupList.get(element);
							QOSUtil.getQOSForUCCEProcess(pollOidElement,processfaceFolder,inventoryDataset,snmpCreditionals);
						}
					}
				} if(group.equalsIgnoreCase(Constants.SYSTEM_PROPERTY)){
					Folder sysGlobalFolder = Folder.addInstance(inventoryDataset, new EntityId(resourceConfig, Constants.LABEL_SYSTEM_PROPERTY), Constants.LABEL_SYSTEM_PROPERTY, resourceConfig);
					ConcurrentHashMap<String,ConcurrentHashMap<String,ArrayList<QosForm>>> groupList=pollOidList.get(group);
					Set<String> elementSet = groupList.keySet();
					for( String element:elementSet){
						if(element.equalsIgnoreCase(Constants.SYSTEM_PROPERTY)){
							ConfigBuildUtil.buildSystemPropertyConfig(getGraph());
							ConcurrentHashMap<String,ArrayList<QosForm>> pollOidElement=groupList.get(element);
							ConfigBuildUtil.createSystemPropertyFolder(snmpCreditionals, pollOidElement, sysGlobalFolder, inventoryDataset, getGraph());
						}
					}
				}
				if (group.equalsIgnoreCase(Constants.CCCA_GENERAL_INFO_GROUP)) {
					
					ConcurrentHashMap<String,ConcurrentHashMap<String,ArrayList<QosForm>>> groupMap=pollOidList.get(group);
					Set<String> elementSet = groupMap.keySet();
					for( String element:elementSet){
						if(element.equalsIgnoreCase(Constants.CCCA_GENERAL_INFO_ELEMENT)){
							Folder folder = Folder.addInstance(inventoryDataset, new EntityId(resourceConfig, Constants.CCCA_GENERAL_INFO_ELEMENT), Constants.CCCA_GENERAL_INFO_LABLE, resourceConfig);
							ConfigBuildUtil.buildCCCAGeneralInfoConfig(getGraph());
							ConcurrentHashMap<String,ArrayList<QosForm>> elementQosMap=groupMap.get(element);
							ConfigBuildUtil.getQOSForCCCAGeneralInfo(snmpCreditionals, elementQosMap, folder, inventoryDataset, getGraph());
						}
					}
				}if (group.equalsIgnoreCase(Constants.CCCA_INSTANCE_TABLE_GROUP)) {
					
					ConcurrentHashMap<String,ConcurrentHashMap<String,ArrayList<QosForm>>> groupMap=pollOidList.get(group);
					Set<String> elementSet = groupMap.keySet();
					for( String element:elementSet){
						if(element.equalsIgnoreCase(Constants.CCCA_INSTANCE_TABLE_ELEMENT)){
							Folder folder = Folder.addInstance(inventoryDataset, new EntityId(resourceConfig, Constants.CCCA_INSTANCE_TABLE_ELEMENT), Constants.CCCA_INSTANCE_TABLE_LABLE, resourceConfig);
							ConfigBuildUtil.buildCCCAInstanceTableConfig(getGraph());
							ConcurrentHashMap<String,ArrayList<QosForm>> elementQosMap=groupMap.get(element);
							ConfigBuildUtil.getQOSForCCCAInstanceTable(snmpCreditionals, elementQosMap, folder, inventoryDataset, getGraph());
						}
					}
				}if (group.equalsIgnoreCase(Constants.CCCA_COMPONENT_TABLE_GROUP)) {
					
					ConcurrentHashMap<String,ConcurrentHashMap<String,ArrayList<QosForm>>> groupMap=pollOidList.get(group);
					Set<String> elementSet = groupMap.keySet();
					for( String element:elementSet){
						if(element.equalsIgnoreCase(Constants.CCCA_COMPONENT_TABLE_ELEMENT)){
							Folder folder = Folder.addInstance(inventoryDataset, new EntityId(resourceConfig, Constants.CCCA_COMPONENT_TABLE_ELEMENT), Constants.CCCA_COMPONENT_TABLE_LABLE, resourceConfig);
							ConcurrentHashMap<String,ArrayList<QosForm>> elementQosMap=groupMap.get(element);
							ConfigBuildUtil.buildcccaComponentTableConfig(getGraph());
							QOSUtil.getQOSForCccaComponentTable(elementQosMap, folder, inventoryDataset, snmpCreditionals,getGraph());
						}
					}
				}if (group.equalsIgnoreCase(Constants.CCCA_ROUTER_TABLE_GROUP)) {
					
					ConcurrentHashMap<String,ConcurrentHashMap<String,ArrayList<QosForm>>> groupMap=pollOidList.get(group);
					Set<String> elementSet = groupMap.keySet();
					for( String element:elementSet){
						if(element.equalsIgnoreCase(Constants.CCCA_ROUTER_TABLE_ELEMENT)){
							Folder folder = Folder.addInstance(inventoryDataset, new EntityId(resourceConfig, Constants.CCCA_ROUTER_TABLE_ELEMENT), Constants.CCCA_ROUTER_TABLE_LABLE, resourceConfig);
							ConcurrentHashMap<String,ArrayList<QosForm>> elementQosMap=groupMap.get(element);
							ConfigBuildUtil.buildcccaRouterTableConfig(getGraph());
							QOSUtil.getQOSForRouterTable(snmpCreditionals,elementQosMap, folder, inventoryDataset,getGraph() );
						}
					}
				}if (group.equalsIgnoreCase(Constants.CCCA_LOGGER_TABLE_GROUP)) {
					
					ConcurrentHashMap<String,ConcurrentHashMap<String,ArrayList<QosForm>>> groupMap=pollOidList.get(group);
					Set<String> elementSet = groupMap.keySet();
					for( String element:elementSet){
						if(element.equalsIgnoreCase(Constants.CCCA_LOGGER_TABLE_ELEMENT)){
							Folder folder = Folder.addInstance(inventoryDataset, new EntityId(resourceConfig, Constants.CCCA_LOGGER_TABLE_ELEMENT), Constants.CCCA_LOGGER_TABLE_LABLE, resourceConfig);
							ConfigBuildUtil.buildCCCALoggerTableConfig(getGraph());
							ConcurrentHashMap<String,ArrayList<QosForm>> elementQosMap=groupMap.get(element);
							ConfigBuildUtil.getQOSForCCCALoggerTable(snmpCreditionals,elementQosMap, folder, inventoryDataset,getGraph());
						}
					}
				}if (group.equalsIgnoreCase(Constants.CCCA_DISTAW_TABLE_GROUP)) {
					
					ConcurrentHashMap<String,ConcurrentHashMap<String,ArrayList<QosForm>>> groupMap=pollOidList.get(group);
					Set<String> elementSet = groupMap.keySet();
					for( String element:elementSet){
						if(element.equalsIgnoreCase(Constants.CCCA_DISTAW_TABLE_ELEMENT)){
							Folder folder = Folder.addInstance(inventoryDataset, new EntityId(resourceConfig, Constants.CCCA_DISTAW_TABLE_ELEMENT), Constants.CCCA_DISTAW_TABLE_LABLE, resourceConfig);
							ConfigBuildUtil.buildCCCADistAwTableConfig(getGraph());
							ConcurrentHashMap<String,ArrayList<QosForm>> elementQosMap=groupMap.get(element);
							//ConfigBuildUtil.getQOSForCCCADistTable(elementQosMap, folder, inventoryDataset,snmpCreditionals, getGraph());
							ConfigBuildUtil.getQOSForCCCADistTable(snmpCreditionals, elementQosMap, folder, inventoryDataset, getGraph());
						}
					}
				}if (group.equalsIgnoreCase(Constants.CCCA_PG_TABLE_GROUP)) {
					
					ConcurrentHashMap<String,ConcurrentHashMap<String,ArrayList<QosForm>>> groupMap=pollOidList.get(group);
					Set<String> elementSet = groupMap.keySet();
					for( String element:elementSet){
						if(element.equalsIgnoreCase(Constants.CCCA_PG_TABLE_ELEMENT)){
							Folder folder = Folder.addInstance(inventoryDataset, new EntityId(resourceConfig, Constants.CCCA_PG_TABLE_ELEMENT), Constants.CCCA_PG_TABLE_LABLE, resourceConfig);
							ConfigBuildUtil.buildCCCAPgTableConfig(getGraph());
							ConcurrentHashMap<String,ArrayList<QosForm>> elementQosMap=groupMap.get(element);
							ConfigBuildUtil.getQOSForCCCAPgTable(elementQosMap, folder, inventoryDataset,snmpCreditionals, getGraph());
						}
					}
				}if (group.equalsIgnoreCase(Constants.CCCA_PIM_TABLE_GROUP)) {
					
					ConcurrentHashMap<String,ConcurrentHashMap<String,ArrayList<QosForm>>> groupMap=pollOidList.get(group);
					Set<String> elementSet = groupMap.keySet();
					for( String element:elementSet){
						if(element.equalsIgnoreCase(Constants.CCCA_PIM_TABLE_ELEMENT)){
							Folder folder = Folder.addInstance(inventoryDataset, new EntityId(resourceConfig, Constants.CCCA_PIM_TABLE_ELEMENT), Constants.CCCA_PIM_TABLE_LABLE, resourceConfig);
							ConcurrentHashMap<String,ArrayList<QosForm>> elementQosMap=groupMap.get(element);
							ConfigBuildUtil.buildCCCAPimTableConfig(getGraph());
							ConfigBuildUtil.getQOSForPimTable(elementQosMap, folder, inventoryDataset,snmpCreditionals,getGraph());
						}
					}
				}if (group.equalsIgnoreCase(Constants.CCCA_CG_TABLE_GROUP)) {
					
					ConcurrentHashMap<String,ConcurrentHashMap<String,ArrayList<QosForm>>> groupMap=pollOidList.get(group);
					Set<String> elementSet = groupMap.keySet();
					for( String element:elementSet){
						if(element.equalsIgnoreCase(Constants.CCCA_CG_TABLE_ELEMENT)){
							Folder folder = Folder.addInstance(inventoryDataset, new EntityId(resourceConfig, Constants.CCCA_CG_TABLE_ELEMENT), Constants.CCCA_CG_TABLE_LABLE, resourceConfig);
							ConfigBuildUtil.buildCCCACgTableConfig(getGraph());
							ConcurrentHashMap<String,ArrayList<QosForm>> elementQosMap=groupMap.get(element);
							//ConfigBuildUtil.getQOSForCgTable(elementQosMap, folder, inventoryDataset,snmpCreditionals);
							ConfigBuildUtil.getQOSForCgTable(snmpCreditionals,elementQosMap, folder, inventoryDataset,getGraph());
						}
					}
				}
				
			} 
		}catch (Exception ex) {
			Log.error("Exception in CUCE:"+ex);
		}
		
		return inventoryDataset;
	}

	
	
	
	
	public InventoryDataset getUpdatedInventoryCUCM(ResourceConfig resourceConfig) {
		InventoryDataset inventoryDataset = null;
		try {
			inventoryDataset=new InventoryDataset(resourceConfig);
			final SnmpCreditionals snmpCreditionals = getSnmpCredentials(resourceConfig);
			snmpCreditionals.setRequestType("GET");
			String fileName="/CUCM_OidList.txt";
			InputStream in = getClass().getResourceAsStream(fileName); 
			ConcurrentHashMap<String,ConcurrentHashMap<String, ArrayList<OidForm>>>	 oidListMap = OidListReader.getOidList(in);
			ConcurrentHashMap<String,ConcurrentHashMap<String,IndexElement>> oidIndexList = QOSUtil.getOidIndexList(oidListMap,snmpCreditionals);
			final Map<String, Map<String,List<QOS>>> axlListMap = PerfmonPortCounterUtil.getInstance().getAXLList(snmpCreditionals.getIpAddress());
			ConcurrentHashMap<String,ConcurrentHashMap<String,ConcurrentHashMap<String,ArrayList<QosForm>>>> pollOidList = QOSUtil.pollOid(oidIndexList,snmpCreditionals);
			Set<String> groupSet=pollOidList.keySet();
			for (String group : groupSet) {
				
				if (group.equalsIgnoreCase(Constants.HOST_RESOURCE)) {
					Folder hostResourceFolder = Folder.addInstance(inventoryDataset, new EntityId(resourceConfig, Constants.HOST_RESOURCE_ELEMENT), Constants.HOST_RESOURCE_ELEMENT, resourceConfig);
					Folder processorFolder = Folder.addInstance(inventoryDataset, new EntityId(hostResourceFolder, Constants.PROCESSOR), Constants.PROCESSOR, hostResourceFolder);
					Folder memoryFolder = Folder.addInstance(inventoryDataset, new EntityId(hostResourceFolder, Constants.MEMORY_VOLUME), Constants.MEMORY_VOLUME, hostResourceFolder);
					ConcurrentHashMap<String,ConcurrentHashMap<String,ArrayList<QosForm>>> groupList = pollOidList.get(group);
					Set<String> elementSet = groupList.keySet();
					for(String element:elementSet){
						if(element.equalsIgnoreCase(Constants.PROCESSOR)){
							ConcurrentHashMap<String,ArrayList<QosForm>> pollOidElement = groupList.get(element);
							QOSUtil.getQOSForProcessors(pollOidElement,processorFolder,inventoryDataset,snmpCreditionals);
						}
						if (element.equalsIgnoreCase(Constants.MEMORY)) {
							ConcurrentHashMap<String,ArrayList<QosForm>> pollOidElement = groupList.get(element);
							QOSUtil.getQOSForMemory(pollOidElement, memoryFolder, inventoryDataset, snmpCreditionals);
						}
					}

				}
				else if(group.equalsIgnoreCase(Constants.INTERFACE)){
					Folder interfaceFolder = Folder.addInstance(inventoryDataset, new EntityId(resourceConfig, Constants.INTERFACE), Constants.INTERFACE, resourceConfig);
					ConcurrentHashMap<String,ConcurrentHashMap<String,ArrayList<QosForm>>> groupList = pollOidList.get(group);
					Set<String> elementSet = groupList.keySet();
					for(String element:elementSet){
						if(element.equalsIgnoreCase(Constants.INTERFACE)){
							ConcurrentHashMap<String,ArrayList<QosForm>> pollOidElement = groupList.get(element);
							QOSUtil.getQOSForInterface(pollOidElement,interfaceFolder,inventoryDataset,snmpCreditionals);
						}
					}
				}else if(group.equalsIgnoreCase(Constants.SOFTWARE)){
					Folder processfaceFolder = Folder.addInstance(inventoryDataset, new EntityId(resourceConfig, Constants.PROCESSES), Constants.PROCESSES, resourceConfig);
					ConcurrentHashMap<String,ConcurrentHashMap<String,ArrayList<QosForm>>> groupList = pollOidList.get(group);
					Set<String> elementSet = groupList.keySet();
					for(String element:elementSet){
						if(element.equalsIgnoreCase(Constants.SOFTWARE)){
							ConcurrentHashMap<String,ArrayList<QosForm>> pollOidElement = groupList.get(element);
							QOSUtil.getQOSForProcess(pollOidElement,processfaceFolder,inventoryDataset,snmpCreditionals);
						}
					}
				}else if(group.equalsIgnoreCase(Constants.SYSTEM_PROPERTY)){
					Folder sysGlobalFolder = Folder.addInstance(inventoryDataset, new EntityId(resourceConfig, Constants.LABEL_SYSTEM_PROPERTY), Constants.LABEL_SYSTEM_PROPERTY, resourceConfig);
					ConcurrentHashMap<String,ConcurrentHashMap<String,ArrayList<QosForm>>> groupList=pollOidList.get(group);
					Set<String> elementSet = groupList.keySet();
					for( String element:elementSet){
						if(element.equalsIgnoreCase(Constants.SYSTEM_PROPERTY)){
							ConfigBuildUtil.buildSystemPropertyConfig(getGraph());
							ConcurrentHashMap<String,ArrayList<QosForm>> pollOidElement=groupList.get(element);
							ConfigBuildUtil.createSystemPropertyFolder(snmpCreditionals, pollOidElement, sysGlobalFolder, inventoryDataset, getGraph());
						}
					}
				}
				else if (group.equalsIgnoreCase(Constants.GATEWAY_INFO)) {
					final Folder gateWayInfoFolder = Folder.addInstance(inventoryDataset, new EntityId(resourceConfig, Constants.GATEWAY_INFO_ELEMENT), Constants.GATEWAY_INFO_ELEMENT, resourceConfig);
					ConcurrentHashMap<String,ConcurrentHashMap<String,ArrayList<QosForm>>> groupList = pollOidList.get(group);
					Set<String> elementSet = groupList.keySet();
					for(String element:elementSet){
						if(element.equalsIgnoreCase(Constants.GATEWAY_INFO)){
							ConfigBuildUtil.buildGateWayInfoConfig(getGraph());
							ConcurrentHashMap<String,ArrayList<QosForm>> pollOidElement = groupList.get(element);
							QOSUtil.getQOSForGateWayInfo(pollOidElement,gateWayInfoFolder,inventoryDataset,snmpCreditionals,getGraph());
						}
					}
				}
				else if(group.equalsIgnoreCase(Constants.CCM_GATEWAY_TRUNK_GROUP)){
					 
					 ConcurrentHashMap<String,ConcurrentHashMap<String,ArrayList<QosForm>>> elementMap = pollOidList.get(group);
					Set<String> elementSet = elementMap.keySet();
					for(String element:elementSet){
						if(element.equalsIgnoreCase(Constants.CCM_GATEWAY_TRUNK_ELEMENT)){
							Folder folder = Folder.addInstance(inventoryDataset, new EntityId(resourceConfig, Constants.GATEWAY_TRUNK_INFO), Constants.GATEWAY_TRUNK_INFO, resourceConfig);
							ConfigBuildUtil.buildCcmGlobalTrunkConfig(getGraph());
							ConcurrentHashMap<String,ArrayList<QosForm>> descQosMap=elementMap.get(element);
							QOSUtil.getQOSForTrunk(descQosMap,folder,inventoryDataset,snmpCreditionals, getGraph());
						}
					}
				}
				else if(group.equalsIgnoreCase(Constants.H323DEVICE)){
					Folder h323DeviceFolder = Folder.addInstance(inventoryDataset, new EntityId(resourceConfig, Constants.H323DEVICE_ELEMENT), Constants.H323DEVICE_ELEMENT, resourceConfig);
					ConcurrentHashMap<String,ConcurrentHashMap<String,ArrayList<QosForm>>> groupList=pollOidList.get(group);
					Set<String> elementSet = groupList.keySet();
					for( String element:elementSet){
						if(element.equalsIgnoreCase(Constants.H323DEVICE)){
							ConfigBuildUtil.buildH323DeviceConfig(getGraph());
							ConcurrentHashMap<String,ArrayList<QosForm>> pollOidElement=groupList.get(element);
							ConfigBuildUtil.createH323Device(snmpCreditionals, pollOidElement, h323DeviceFolder, inventoryDataset, getGraph());
						}
					}
				} else if (group.equalsIgnoreCase(Constants.CCM_GLOBAL_INFO_GROUP)){
					ConcurrentHashMap<String,ConcurrentHashMap<String,ArrayList<QosForm>>> elementMap = pollOidList.get(group);
					Set<String> elementSet = elementMap.keySet();
					for(String element:elementSet){
						if(element.equalsIgnoreCase(Constants.CCM_GLOBAL_INFO_ELEMENT)){
							Folder folder = Folder.addInstance(inventoryDataset, new EntityId(resourceConfig, Constants.CCM_GLOBAL_INFO_ELEMENT1), Constants.CCM_GLOBAL_INFO_ELEMENT1, resourceConfig);
							ConfigBuildUtil.buildCcmGlobalInfoConfig(getGraph());
							ConcurrentHashMap<String,ArrayList<QosForm>> descQosMap=elementMap.get(element);
							QOSUtil.getQOSForCcmGlobalInfo(descQosMap,folder,inventoryDataset,snmpCreditionals,getGraph());
							
						}
					}
				}else if(group.equalsIgnoreCase(Constants.CCM_PHONE_INFO_GROUP)){
					ConcurrentHashMap<String,ConcurrentHashMap<String,ArrayList<QosForm>>> elementMap = pollOidList.get(group);
					Set<String> elementSet = elementMap.keySet();
					for(String element:elementSet){
						if(element.equalsIgnoreCase(Constants.CCM_PHONE_INFO_ELEMENT)){
							Folder folder = Folder.addInstance(inventoryDataset, new EntityId(resourceConfig, Constants.CCM_PHONE_INFO), Constants.CCM_PHONE_INFO, resourceConfig);
							ConfigBuildUtil.buildCcmPhoneInfoConfig(getGraph());
							ConcurrentHashMap<String,ArrayList<QosForm>> descQosMap=elementMap.get(element);
							QOSUtil.getCcmPhoneInfo(descQosMap,folder,inventoryDataset,snmpCreditionals, getGraph());
						}
					}
				}else if(group.equalsIgnoreCase(Constants.CUCM_GROUP)){
					 ConcurrentHashMap<String,ConcurrentHashMap<String,ArrayList<QosForm>>> elementMap = pollOidList.get(group);
					Set<String> elementSet = elementMap.keySet();
					for(String element:elementSet){
						if(element.equalsIgnoreCase(Constants.CUCM_ELEMENT_1)){
							Folder folder = Folder.addInstance(inventoryDataset, new EntityId(resourceConfig, Constants.CUCM_ELEMENT_1), Constants.CUCM_ELEMENT_1, resourceConfig);
							ConfigBuildUtil.buildCucmGroupTableConfig(getGraph());
							ConcurrentHashMap<String,ArrayList<QosForm>> descQosMap=elementMap.get(element);
							QOSUtil.getQOSForCucmGroupTable(descQosMap,folder,inventoryDataset,snmpCreditionals, getGraph());
						}if(element.equalsIgnoreCase(Constants.CUCM_ELEMENT_2)){
							Folder folder = Folder.addInstance(inventoryDataset, new EntityId(resourceConfig, Constants.CALL_MANAGER_ELEMENT), Constants.CALL_MANAGER_ELEMENT, resourceConfig);
							ConfigBuildUtil.buildCucmTableConfig(getGraph());
							ConcurrentHashMap<String,ArrayList<QosForm>> descQosMap=elementMap.get(element);
							QOSUtil.getQOSForCucmTable(descQosMap,folder,inventoryDataset,snmpCreditionals, getGraph());
						}
					}
				}
			}

			final Folder axlGlobalFolder = Folder.addInstance(inventoryDataset, new EntityId(resourceConfig,Constants.AXL), Constants.AXL, resourceConfig);
			final Set<String> elementSet = axlListMap.keySet();
			for( String element:elementSet){
				if(element.equalsIgnoreCase(Constants.CISCO_TOMCAT_JVM_DESCRIPTION)){
					Log.info("element name for CiscoTomcatJVM ==========================     "+element);
					final Folder ciscoTomcatJVMFolder = Folder.addInstance(inventoryDataset, new EntityId(axlGlobalFolder, element), element, axlGlobalFolder);
					final Map<String,List<QOS>> pollOidElement=axlListMap.get(element);
					QOSUtil.setQosForAxlCiscoTomcatJVM(pollOidElement,snmpCreditionals,ciscoTomcatJVMFolder,inventoryDataset);
				}else if(element.equalsIgnoreCase(Constants.CISCO_TOMCAT_WEB_APPLICATION_DESCRIPTION)){
					Log.info("element name for CiscoTomcatWebApplication ==========================     "+element);
					final Folder ciscoTomcatWebApplicationFolder = Folder.addInstance(inventoryDataset, new EntityId(axlGlobalFolder, element), element, axlGlobalFolder);
					final Map<String,List<QOS>> pollOidElement=axlListMap.get(element);
					QOSUtil.setQosForAxlCiscoTomcatWebApplication(pollOidElement,snmpCreditionals,ciscoTomcatWebApplicationFolder,inventoryDataset);
				}else if(element.equalsIgnoreCase(Constants.DB_LOCAL_DSN_DESCRIPTION)){
					Log.info("element name for DBLocal_DSN ==========================     "+element);
					final Folder dbLocalDSNFolder = Folder.addInstance(inventoryDataset, new EntityId(axlGlobalFolder, element), element, axlGlobalFolder);
					final Map<String,List<QOS>> pollOidElement=axlListMap.get(element);
					QOSUtil.setQosForAxlDBLocalDSN(pollOidElement,snmpCreditionals,dbLocalDSNFolder,inventoryDataset);
				}else if(element.equalsIgnoreCase(Constants.CISCO_REPLICATION_DBSPACE_MONITORS_DESCRIPTION)){
					Log.info("element name for CiscoReplicationDBSpaceMonitors ==========================     "+element);
					final Folder ciscoReplicationDBSpaceMonitorsFolder = Folder.addInstance(inventoryDataset, new EntityId(axlGlobalFolder, element), element, axlGlobalFolder);
					final Map<String,List<QOS>> pollOidElement=axlListMap.get(element);
					QOSUtil.setQosForAxlEnterpriseReplicationDBSpaceMonitors(pollOidElement,snmpCreditionals,ciscoReplicationDBSpaceMonitorsFolder,inventoryDataset);
				}else if(element.equalsIgnoreCase(Constants.MEMORY)){
					Log.info("element name for Memory ==========================     "+element);
					final Folder memoryFolder = Folder.addInstance(inventoryDataset, new EntityId(axlGlobalFolder, element), element, axlGlobalFolder);
					final Map<String,List<QOS>> pollOidElement=axlListMap.get(element);
					QOSUtil.setQosForAxlMemory(pollOidElement,snmpCreditionals,memoryFolder,inventoryDataset);
				}else if(element.equalsIgnoreCase(Constants.PARTITION)){
					Log.info("element name for Partition ==========================     "+element);
					final Folder partitionFolder = Folder.addInstance(inventoryDataset, new EntityId(axlGlobalFolder, element), element, axlGlobalFolder);
					final Map<String,List<QOS>> pollOidElement=axlListMap.get(element);
					QOSUtil.setQosForAxlPartition(pollOidElement,snmpCreditionals,partitionFolder,inventoryDataset);
				}else if(element.equalsIgnoreCase(Constants.SYSTEM)){
					Log.info("element name for System ==========================     "+element);
					final Folder systemFolder = Folder.addInstance(inventoryDataset, new EntityId(axlGlobalFolder, element), element, axlGlobalFolder);
					final Map<String,List<QOS>> pollOidElement=axlListMap.get(element);
					QOSUtil.setQosForAxlSystem(pollOidElement,snmpCreditionals,systemFolder,inventoryDataset);
				}else if(element.equalsIgnoreCase(Constants.TCP)){
					Log.info("element name for TCP ==========================     "+element);
					final Folder tcpFolder = Folder.addInstance(inventoryDataset, new EntityId(axlGlobalFolder, element), element, axlGlobalFolder);
					final Map<String,List<QOS>> pollOidElement=axlListMap.get(element);
					QOSUtil.setQosForAxlTCP(pollOidElement,snmpCreditionals,tcpFolder,inventoryDataset);
				}else if(element.equalsIgnoreCase(Constants.THREAD)){
					Log.info("element name for Thread ==========================     "+element);
					final Folder threadFolder = Folder.addInstance(inventoryDataset, new EntityId(axlGlobalFolder, element), element, axlGlobalFolder);
					final Map<String,List<QOS>> pollOidElement=axlListMap.get(element);
					QOSUtil.setQosForAxlThread(pollOidElement,snmpCreditionals,threadFolder,inventoryDataset);
				}else if(element.equalsIgnoreCase(Constants.CISCO_CALLMANAGER_DESCRIPTION)){
					Log.info("element name for CiscoCallManager ==========================     "+element);
					final Folder ciscoCallManagerFolder = Folder.addInstance(inventoryDataset, new EntityId(axlGlobalFolder, element), element, axlGlobalFolder);
					final Map<String,List<QOS>> pollOidElement=axlListMap.get(element);
					QOSUtil.setQosForAxlCiscoCallManager(pollOidElement,snmpCreditionals,ciscoCallManagerFolder,inventoryDataset);
				}else if(element.equalsIgnoreCase(Constants.CISCO_H323_DESCRIPTION)){
					Log.info("element name for Cisco H323 ==========================     "+element);
					final Folder ciscoH323Folder = Folder.addInstance(inventoryDataset, new EntityId(axlGlobalFolder, element), element, axlGlobalFolder);
					final Map<String,List<QOS>> pollOidElement=axlListMap.get(element);
					QOSUtil.setQosForAxlCiscoH323(pollOidElement,snmpCreditionals,ciscoH323Folder,inventoryDataset);
				}else if(element.equalsIgnoreCase(Constants.CISCO_MGCP_FXO_DEVICE_DESCRIPTION)){
					Log.info("element name for Cisco MGCP FXO Device ==========================     "+element);
					final Folder ciscoMGCPFXODeviceFolder = Folder.addInstance(inventoryDataset, new EntityId(axlGlobalFolder, element), element, axlGlobalFolder);
					final Map<String,List<QOS>> pollOidElement=axlListMap.get(element);
					QOSUtil.setQosForAxlCiscoMGCPFXODevice(pollOidElement,snmpCreditionals,ciscoMGCPFXODeviceFolder,inventoryDataset);
				}else if(element.equalsIgnoreCase(Constants.CISCO_MGCP_FXS_DEVICE_DESCRIPTION)){
					Log.info("element name for Cisco MGCP FXS Device ==========================     "+element);
					final Folder ciscoMGCPFXSDeviceFolder = Folder.addInstance(inventoryDataset, new EntityId(axlGlobalFolder, element), element, axlGlobalFolder);
					final Map<String,List<QOS>> pollOidElement=axlListMap.get(element);
					QOSUtil.setQosForAxlCiscoMGCPFXSDevice(pollOidElement,snmpCreditionals,ciscoMGCPFXSDeviceFolder,inventoryDataset);
				}else if(element.equalsIgnoreCase(Constants.CISCO_MGCP_GATEWAYS_DESCRIPTION)){
					Log.info("element name for Cisco MGCP Gateways ==========================     "+element);
					final Folder ciscoMGCPGatewaysFolder = Folder.addInstance(inventoryDataset, new EntityId(axlGlobalFolder, element), element, axlGlobalFolder);
					final Map<String,List<QOS>> pollOidElement=axlListMap.get(element);
					QOSUtil.setQosForAxlCiscoMGCPGateways(pollOidElement,snmpCreditionals,ciscoMGCPGatewaysFolder,inventoryDataset);
				}else if(element.equalsIgnoreCase(Constants.CISCO_MTP_DEVICE_DESCRIPTION)){
					Log.info("element name for Cisco MTP Device ==========================     "+element);
					final Folder ciscoMTPDeviceFolder = Folder.addInstance(inventoryDataset, new EntityId(axlGlobalFolder, element), element, axlGlobalFolder);
					final Map<String,List<QOS>> pollOidElement=axlListMap.get(element);
					QOSUtil.setQosForAxlCiscoMTPDevice(pollOidElement,snmpCreditionals,ciscoMTPDeviceFolder,inventoryDataset);
				}else if(element.equalsIgnoreCase(Constants.CISCO_PHONES_DESCRIPTION)){
					Log.info("element name for Cisco Phones ==========================     "+element);
					final Folder ciscoPhonesFolder = Folder.addInstance(inventoryDataset, new EntityId(axlGlobalFolder, element), element, axlGlobalFolder);
					final Map<String,List<QOS>> pollOidElement=axlListMap.get(element);
					QOSUtil.setQosForAxlCiscoPhones(pollOidElement,snmpCreditionals,ciscoPhonesFolder,inventoryDataset);
				}else if(element.equalsIgnoreCase(Constants.CISCO_SIP_DESCRIPTION)){
					Log.info("element name for Cisco SIP ==========================     "+element);
					final Folder ciscoSIPFolder = Folder.addInstance(inventoryDataset, new EntityId(axlGlobalFolder, element), element, axlGlobalFolder);
					final Map<String,List<QOS>> pollOidElement=axlListMap.get(element);
					QOSUtil.setQosForAxlCiscoSIP(pollOidElement,snmpCreditionals,ciscoSIPFolder,inventoryDataset);
				}else if(element.equalsIgnoreCase(Constants.CISCO_TFTP_DESCRIPTION)){
					Log.info("element name for Cisco TFTP ==========================     "+element);
					final Folder ciscoTFTPFolder = Folder.addInstance(inventoryDataset, new EntityId(axlGlobalFolder, element), element, axlGlobalFolder);
					final Map<String,List<QOS>> pollOidElement=axlListMap.get(element);
					QOSUtil.setQosForAxlCiscoTFTP(pollOidElement,snmpCreditionals,ciscoTFTPFolder,inventoryDataset);
				}
			}
		
		} catch (Exception ex) {
			Log.error("Exception occour "+ex);
		}
		return inventoryDataset;

	}
}
