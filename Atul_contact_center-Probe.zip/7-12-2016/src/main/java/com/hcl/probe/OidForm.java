package com.hcl.probe;

public class OidForm {
	private String oidName;
	private String oidValue;
	private String element;
	private String metricName;
	public String getOidName() {
		return oidName;
	}
	public void setOidName(String oidName) {
		this.oidName = oidName;
	}
	public String getOidValue() {
		return oidValue;
	}
	public void setOidValue(String oidValue) {
		this.oidValue = oidValue;
	}
	public String getElement() {
		return element;
	}
	public void setElement(String element) {
		this.element = element;
	}
	public String getMetricName() {
		return metricName;
	}
	public void setMetricName(String metricName) {
		this.metricName = metricName;
	}

}
