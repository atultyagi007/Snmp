package com.hcl.probe;


public interface Constants {
	
	public static final String PACKAGE_COM_NIMSOFT_TYPES="com.nimsoft.types.";
	public static final String SYSTEM_PROPERTY = "System_Property";	
	public static final String SYSTEM_OBJECT_ID = "sysObjectID";
	public static final String NOT_ACCESSIBLE = "NA";
	public static final String SYSTEM_DESCRIPTION = "sysDescr";
	public static final String SYSTEM_UP_TIME = "sysUpTime";
	public static final String SYSTEM_CONTACT = "sysContact";
	public static final String SYSTEM_NAME = "sysName";
	public static final String SYSTEM_LOCATION = "sysLocation";
	public static final String SYSTEM_SERVICES = "sysServices";

	public static final String CUCM_GROUP = "Cucm";
	public static final String CUCM_ELEMENT_1 = "CUCMGroupTable";
	public static final String CUCM_ELEMENT_2 = "CUCMTable";
	public static final String CALL_MANAGER_ELEMENT = "Call Manager Table";
	public static final String CUCM_GROUP_NAME = "cucmGroupName";
	public static final String CUCM_GROUP_TFTP_DEFAULT = "cucmGroupTftpDefault";
	public static final String CUCM_NAME = "cucmName";
	public static final String CUCM_DESCRIPTION = "cucmDescription";
	public static final String CUCM_VERSION = "cucmVersion";
	public static final String CUCM_STATUS = "cucmStatus";
	public static final String CUCM_INET_ADDRESS_TYPE = "cucmInetAddressType";
	public static final String CUCM_INET_ADDRESS = "cucmInetAddress";
	public static final String CUCM_CLUSTER_ID = "cucmClusterId";
	public static final String CUCM_INET_ADDRESS2_TYPE = "cucmInetAddress2Type";
	public static final String CUCM_INET_ADDRESS2 = "cucmInetAddress2";
	public static final String ZERO = "0";
	public static final String ONE = "1";
	public static final String TWO = "2";
	public static final String THREE = "3";
	
	public static final String LABEL_SYSTEM_PROPERTY = "System Property";
	public static final String LABEL_SYSTEM_OBJECT_ID = "Object Id";
	public static final String LABEL_DESCRIPTION = "Description";
	public static final String LABEL_SYSTEM_UP_TIME = "Up Time";
	public static final String LABEL_SYSTEM_CONTACT = "Contact";
	public static final String LABEL_NAME = "Name";
	public static final String LABEL_LOCATION = "Location";
	public static final String LABEL_SYSTEM_SERVICES = "Services Provide";
	public static final String LABEL_VERSION = "Version";
	public static final String LABEL_STATUS = "Status";
	public static final String LABEL_INET_ADDRESS_TYPE = "Inet Address Type";
	public static final String LABEL_INET_ADDRESS = "Inet Address";
	public static final String LABEL_CLUSTER_ID = "Cluster Id";
	public static final String LABEL_INET_ADDRESS2_TYPE = "Inet Address Type 2";
	public static final String LABEL_INET_ADDRESS2 = "Inet Address 2";
	public static final String LABEL_CUCM_GROUP = "Cucm Group";
	public static final String LABEL_CUCM_TABLE = "Cucm Table";	
	public static final String LABEL_CUCM_GROUP_NAME = "CUCM Group Name";
	public static final String LABEL_CUCM_GROUP_TFTP_DEFAULT = "Group Tftp Default";
	public static final String LABEL_INDEX = "INDEX";
	public static final String LABLE_PRODUCT_ID = "ProductId";
	public static final String LABLE_INET_ADDRESS_TYPE = "InetAddress Type";
	public static final String LABLE_INET_ADDRESS = "InetAddress";
	public static final String LABLE_H323DEVICE = "h323Device";
	public static final String LABLE_H323DEVICE1 = "H.323Device";
	public static final String H323DEVICE = "H323Device";
	public static final String H323DEVICE_ELEMENT = "H.323 Device";
	public static final String H323DEVICE_NAME = "ccmH323DevName";
	public static final String CCCA_NAME = "cccaName";
	public static final String CCCA_NAME_LABLE = "Name";
	public static final String CCCA_DESCRIPITION = "cccaDescription";
	public static final String CCCA_DESCRIPITION_LABLE = "Description";
	public static final String CCCA_VERSION = "cccaVersion";
	public static final String CCCA_VERSION_LABLE = "Version";
	public static final String H323DEVICE_INDEX = "ccmH323DevIndex";
	public static final String H323DEVICE_PRODUCT_ID = "ccmH323DevProductId";
	public static final String H323DEVICE_DESCRIPTION = "ccmH323DevDescription";
	public static final String H323DEVICE_INET_ADDRESS_TYPE = "ccmH323DevInetAddressType";
	public static final String H323DEVICE_INET_ADDRESS = "ccmH323DevInetAddress";
	public static final String SOFTWARE = "Software";
	public static final String PROCESSES = "Processes";
	public static final String UCCX_SOFTWARE = "UCCXSoftware";
	public static final String UCCE_SOFTWARE = "UCCESoftware";
	public static final String INTERFACE = "Interface";
	public static final String UCCX_INTERFACE = "UCCXInterface";
	public static final String UCCE_INTERFACE = "UCCEInterface";
	public static final String HR_SW_RUNINDEX = "hrSWRunIndex";
	public static final String HR_SW_RUNNAME = "hrSWRunName";
	public static final String IF_INDEX = "IfIndex";
	public static final String IF_DESC = "IfDesc";
	public static final String GATEWAY_INFO = "GateWayInfo";
	public static final String GATEWAY_TRUNK_INFO = "GateWay Trunk Info";
	public static final String GATEWAY_INFO_ELEMENT = "GateWay Info";
	public static final String CCM_GATEWAY_TRUNK_GROUP = "GateWayTrunk";
	public static final String CCM_GATEWAY_TRUNK_ELEMENT = "GateWayTrunk";
	public static final String CCM_GATEWAY_TRUNK = "GateWay Trunk";
	public static final String CCM_GATEWAY_TRUNK_TYPE = "ccmGatewayTrunkType";
	public static final String CCM_GATEWAY_TRUNK_NAME = "ccmGatewayTrunkName";
	public static final String CCM_GATEWAY_NAME = "ccmGatewayName";
	public static final String HOST_RESOURCE = "HostResource";
	public static final String UCCE_HOST_RESOURCE = "UCCEHostResource";
	public static final String UCCX_HOST_RESOURCE = "UCCXHostResource";
	public static final String HOST_RESOURCE_ELEMENT = "Host Resource";
	public static final String PROCESSOR = "Processor";
	public static final String UCCX_PROCESSOR = "UCCXProcessor";
	public static final String UCCE_PROCESSOR = "UCCEProcessor";
	public static final String MEMORY = "Memory";
	public static final String MEMORY_VOLUME = "Memory & Volume";
	public static final String UCCX_MEMORY = "UCCXMemory";
	public static final String UCCE_MEMORY = "UCCEMemory";
	public static final String HR_STORAGE_INDEX = "hrStorageIndex";
	public static final String HR_STORAGE_DESC = "hrStorageDescr";
	public static final String HR_PROCESS_LOAD = "hrProcessorLoad";
	public static final String DECIMAL_FORMAT = "#0.00000";
	
	
	
	public static final String LABLE_CCM_PHONE_PHYSICAL_ADDRESS = "Phone Physical Address";
	public static final String LABLE_CCM_PHONE_IP_ADDRESS = "Phone Ip Address";
	public static final String LABLE_CCM_PHONE_STATUS = "Phone Status";
	public static final String LABLE_CCM_PHONE_E911_LOCATION = "Phone E911 Location";
	public static final String LABLE_CCM_PHONE_NAME = "Phone Name";
	public static final String LABLE_CCM_PHONE_INET_ADDRESS_IPV4 = "Phone Inet Address IPv4";
	public static final String LABLE_CCM_PHONE_INET_ADDRESS_IPV6 = "Phone Inet Address IPv6";
	public static final String LABLE_CCM_PHONE_INFO_ELEMENT = "CcmPhone Info";
	public static final String LABLE_CCM_GLOBAL_INFO_ELEMENT = "CcmGlobalInfo";
	public static final String LABLE_CCM_GATEWAY_TRUNK_ELEMENT = "GateWay Trunk";
	public static final String LABLE_CCM_GATEWAY_INFO_ELEMENT = "Gateway Info";
	public static final String LABLE_CCM_SYSTEM_VERSION = "System Version"; 
	public static final String CCM_PHONE_INFO_GROUP = "CcmPhoneInfo"; 
	public static final String CCCA_GENERAL_INFO_GROUP = "CCCAGeneralInfo";
	public static final String CCCA_GENERAL_INFO_ELEMENT = "CCCAGeneralInfo";
	public static final String CCCA_GENERAL_INFO_LABLE = "General Info";
	public static final String CCCA_COMPONENT_TABLE_GROUP = "CCCAComponentTable";
	public static final String CCCA_COMPONENT_TABLE_ELEMENT = "CCCAComponentTable";
	public static final String CCCA_COMPONENT_TABLE_LABLE = "UCCE Component Info";
	public static final String CCCA_COMPONENT_NAME = "cccaComponentname";
	public static final String CCCA_COMPONENT_NAME_LABLE = "Component Name";
	public static final String CCCA_COMPONENT_TYPE = "cccaComponenttype";
	public static final String CCCA_COMPONENT_TYPE_LABLE = "Component Type";
	public static final String CCM_PHONE_INFO = "Call Manager Phone Info";
	public static final String CCCA_ROUTER_TABLE_GROUP = "CCCARouterTable";
	public static final String CCCA_ROUTER_TABLE_ELEMENT = "CCCARouterTable";
	public static final String CCCA_ROUTER_TABLE_LABLE = "Router Info";
	public static final String CCCA_ROUTER_SIDE = "cccaRouterSide";
	public static final String CCCA_ROUTER_SIDE_LABLE = "Router Side";
	public static final String CCCA_ROUTER_SIDEA_PARSE = "sideA";
	public static final String CCCA_ROUTER_SIDEB_PARSE = "sideB";
	
	public static final String CCCA_LOGGER_TABLE_GROUP = "CCCALoggerTable";
	public static final String CCCA_LOGGER_TABLE_ELEMENT = "CCCALoggerTable";
	public static final String CCCA_LOGGER_TABLE_LABLE = "Logger Info";
	public static final String CCCA_LOGGER_ROUTER_SIDEA_NAME = "cccaLoggerRouterSideAName";
	public static final String CCCA_LOGGER_ROUTER_SIDEB_NAME = "cccaLoggerRouterSideBName";
	public static final String CCCA_LOGGER_ROUTER_SIDEA_NAME_LABLE = "Logger Router SideA Name";
	public static final String CCCA_LOGGER_ROUTER_SIDEB_NAME_LABLE = "Logger Router SideB Name";
	public static final String CCCA_LOGGER_SIDE = "cccaLoggerSide";
	public static final String CCCA_LOGGER_TYPE = "cccaLoggerType";
	public static final String CCCA_LOGGER_SIDE_LABLE = "Logger Side";
	public static final String CCCA_LOGGER_TYPE_LABLE = "Logger Type";
	public static final String CCCA_LOGGER_SIDEA_PARSE = "sideA";
	public static final String CCCA_LOGGER_SIDEB_PARSE = "sideB";
	public static final String CCCA_LOGGER_TYPE_STANDARD_PARSE = "standard";
	public static final String CCCA_LOGGER_TYPE_NAM_PARSE = "nam";
	public static final String CCCA_LOGGER_TYPE_CICM_PARSE = "cicm";
	
	public static final String CCCA_DISTAW_TABLE_GROUP = "CCCADistAWTable";
	public static final String CCCA_DISTAW_TABLE_ELEMENT = "CCCADistAWTable";
	public static final String CCCA_DISTAW_TABLE_LABLE = "Distributor Administrator Workstation Info";
	public static final String CCCA_DISTAW_ADMIN_SITE_NAME = "cccaDistAwAdminSiteName";
	public static final String CCCA_DISTAW_ROUTER_SIDEA_NAME = "cccaDistAwRouterSideAName";
	public static final String CCCA_DISTAW_ROUTER_SIDEB_NAME = "cccaDistAwRouterSideBName";
	public static final String CCCA_DISTAW_LOGGER_SIDEA_NAME = "cccaDistAwLoggerSideAName";
	public static final String CCCA_DISTAW_LOGGER_SIDEB_NAME = "cccaDistAwLoggerSideBName";
	public static final String CCCA_DISTAW_ADMIN_SITE_NAME_LABLE = "Dist AwAdmin Site Name";
	public static final String CCCA_DISTAW_SIDE = "cccaDistAwSide";
	public static final String CCCA_DISTAW_SIDE_LABLE = "DistAw Side";
	public static final String CCCA_DISTAW_TYPE = "cccaDistAwType";
	public static final String CCCA_DISTAW_TYPE_LABLE = "DistAw Type";
	public static final String CCCA_DISTAW_ROUTER_SIDEA_NAME_LABLE = "DistAw Router SideA Name";
	public static final String CCCA_DISTAW_ROUTER_SIDEB_NAME_LABLE = "DistAw Router SideB Name";
	public static final String CCCA_DISTAW_LOGGER_SIDEA_NAME_LABLE = "DistAw Logger SideA Name";
	public static final String CCCA_DISTAW_LOGGER_SIDEB_NAME_LABLE = "DistAw Logger SideB Name";
	
	public static final String CCCA_PG_TABLE_GROUP = "CCCAPgTable";
	public static final String CCCA_PG_TABLE_ELEMENT = "CCCAPgTable";
	public static final String CCCA_PG_TABLE_LABLE = "Peripheral Gateway Info";
	public static final String CCCA_PG_ROUTER_SIDEA_NAME = "cccaPgRouterSideAName";
	public static final String CCCA_PG_ROUTER_SIDEB_NAME = "cccaPgRouterSideBName";
	public static final String CCCA_PG_ROUTER_SIDEA_NAME_LABLE = "PgRouter SideA Name";
	public static final String CCCA_PG_ROUTER_SIDEB_NAME_LABLE = "PgRouter SideB Name";
	
	
	public static final String CCCA_PIM_TABLE_GROUP = "CCCAPimTable";
	public static final String CCCA_PIM_TABLE_ELEMENT = "CCCAPimTable";
	public static final String CCCA_PIM_TABLE_LABLE = "Peripheral Interface Manager Info";
	public static final String CCCA_PIM_PERIPHERAL_NAME = "cccaPimPeripheralName";  
	public static final String CCCA_PIM_PERIPHERAL_TYPE = "cccaPimPeripheralType"; 
	public static final String CCCA_PIM_PERIPHERAL_LABLE = "Peripheral Type"; 
	
	public static final String CCCA_CG_TABLE_GROUP = "CCCACgTable";
	public static final String CCCA_CG_TABLE_ELEMENT = "CCCACgTable";
	public static final String CCCA_CG_TABLE_LABLE = "CTI Gatway Info";
	public static final String CCCA_CG_NUMBER = "cccaCgNumber";
	public static final String CCCA_CG_SIDE = "cccaCgSide";
	public static final String CCCA_CG_NUMBER_LABLE = "CTI Gatway Number";
	public static final String CCCA_CG_SIDE_LABLE = "CTI Gatway Side";
	
	public static final String CCCA_INSTANCE_TABLE_GROUP = "CCCAInstanceTable";
	public static final String CCCA_INSTANCE_NAME = "cccaInstanceName";
	public static final String CCCA_INSTANCE_NAME_LABLE = "Instance Name";
	public static final String CCCA_INSTANCE_TABLE_ELEMENT = "CCCAInstanceTable";
	public static final String CCCA_INSTANCE_TABLE_LABLE = "Instance Table";
	public static final String CCM_PHONE_INFO_ELEMENT = "CcmPhoneInfo";
	public static final String CCM_PHONE_PHYSICAL_ADDRESS = "ccmPhonePhysicalAddress";
	public static final String CCM_PHONE_IP_ADDRESS = "ccmPhoneIpAddress";
	public static final String CCM_PHONE_STATUS = "ccmPhoneStatus";
	public static final String CCM_PHONE_TYPE = "ccmPhoneType";
	public static final String CCM_PHONE_E911_LOCATION = "ccmPhoneE911Location";
	public static final String CCM_PHONE_NAME = "ccmPhoneName";
	public static final String CCM_PHONE_INET_ADDRESS_IPV4 = "ccmPhoneInetAddressIPv4";
	public static final String CCM_PHONE_INET_ADDRESS_IPV6 = "ccmPhoneInetAddressIPv6";
	public static final String LAST_CHANGE = "ifLastChange";
	public static final String GATEWAY_TRUNK = "GateWayTrunk";
	public static final String CCM_GLOBAL_INFO_ELEMENT = "CcmGlobalInfo";
	public static final String CCM_GLOBAL_INFO_ELEMENT2 = "Call Manager Global Info";
	public static final String CCM_GLOBAL_INFO_ELEMENT1 = "Call Manager Global Info";
	public static final String CCM_GATEWAY_INFO_ELEMENT = "GatewayInfo";
	public static final String CCM_GLOBAL_INFO_GROUP = "CcmGlobalInfo";
	public static final String CCM_SYSTEM_VERSION = "ccmSystemVersion";
	public static final String CCM_SYSTEM_VERSION_LABLE = "System Version";
	public static final String CCM_GATEWAY_TYPE = "ccmGatewayType";
	public static final String CCM_GATEWAY_DESCRIPTION = "ccmGatewayDescription";
	public static final String CCM_GATEWAY_INET_ADDRESS = "ccmGatewayInetAddress";
	public static final String CCM_GATEWAY_INET_ADDRESS_TYPE = "ccmGatewayInetAddressType";
	public static final String CCM_GATEWAY_PRODUCTID = "ccmGatewayProductId";
	
	//Trap Information
	public static final String TRAP_FILE_NAME = "/TrapList.txt";
	public static final String UCCE_MESSAGE_ID_FILE_NAME = "/UcceMessageId.txt";
	public static final String TRAP = "trap";
	public static final String OID = "oid";
	public static final String SUBSYSTEM_ID = "2.5.1.";
	public static final String ATTRIBUTE_NAME = "attributeName";
	public static final String SNMP_TRAP_OID = "1.3.6.1.6.3.1.1.4.1.0";
	public static final String CCM_GATEWAY_NAME_OID = "1.3.6.1.4.1.9.9.156.1.3.1.1.2.0";	
	public static final String CCM_GATEWAY_INET_ADDRESS_TYPE_OID = "1.3.6.1.4.1.9.9.156.1.3.1.1.7.0";
	public static final String CCM_GATEWAY_INET_ADDRESS_OID = "1.3.6.1.4.1.9.9.156.1.3.1.1.8.0";
	public static final String CCM_ALARM_SEVERITY = "1.3.6.1.4.1.9.9.156.1.10.1.0";
	public static final String CCM_FAIL_CAUSE_CODE_MESSAGE_ = "1.3.6.1.4.1.9.9.156.1.10.2.0";
	public static final String CCM_PHONE_FAILURES = "1.3.6.1.4.1.9.9.156.1.10.3.0";
	public static final String CCM_PHONE_UPDATES = "1.3.6.1.4.1.9.9.156.1.10.4.0";
	public static final String CCM_GATEWAY_FAIL_CAUSE_CODE = "1.3.6.1.4.1.9.9.156.1.10.5.0";
	public static final String CCM_MEDIA_RESOURCE_TYPE = "1.3.6.1.4.1.9.9.156.1.10.6.0";
	public static final String CCM_MEDIA_RESOURCE_LIST_NAME = "1.3.6.1.4.1.9.9.156.1.10.7.0";
	public static final String CCM_ROUTE_LIST_NAME = "1.3.6.1.4.1.9.9.156.1.10.8.0";
	public static final String CCM_GATEWAY_PHYS_IF_INDEX = "1.3.6.1.4.1.9.9.156.1.10.9.0";
	public static final String CCM_GATEWAY_PHYS_IF_L2_STATUS = "1.3.6.1.4.1.9.9.156.1.10.10.0"; 
	public static final String CCM_MALI_CALL_CALLED_PARTY_NAME = "1.3.6.1.4.1.9.9.156.1.10.11.0";
	public static final String CCM_MALI_CALL_CALLED_PARTY_NUMBER = "1.3.6.1.4.1.9.9.156.1.10.12.0";
	public static final String CCM_MALI_CALL_CALLED_DEVICE_NAME = "1.3.6.1.4.1.9.9.156.1.10.13.0";
	public static final String CCM_MALI_CALL_CALLING_PARTY_NAME = "1.3.6.1.4.1.9.9.156.1.10.14.0";
	public static final String CCM_MALI_CALL_CALLING_PARTY_NUMBER = "1.3.6.1.4.1.9.9.156.1.10.15.0";
	public static final String CCM_MALI_CALL_CALLING_DEVICE_NAME = "1.3.6.1.4.1.9.9.156.1.10.16.0";
	public static final String CCM_MALI_CALL_TIME = "1.3.6.1.4.1.9.9.156.1.10.17.0";
	public static final String CCM_QUALITY_REPORT_SOURCE_DEV_NAME = "1.3.6.1.4.1.9.9.156.1.10.18.0";
	public static final String CCM_QUALITY_REPORT_CLUSTER_ID = "1.3.6.1.4.1.9.9.156.1.10.19.0";
	public static final String CCM_QUALITY_REPORT_CATEGORY = "1.3.6.1.4.1.9.9.156.1.10.20.0";
	public static final String CCM_QUALITY_REPORT_REASON_CODE = "1.3.6.1.4.1.9.9.156.1.10.21.0";
	public static final String CCM_QUALITY_REPORT_TIME = "1.3.6.1.4.1.9.9.156.1.10.22.0";
	public static final String CCM_TLS_DEV_NAME = "1.3.6.1.4.1.9.9.156.1.10.23.0";
	public static final String CCM_TLS_DEV_INET_ADDRESS_TYPE = "1.3.6.1.4.1.9.9.156.1.10.24.0";
	public static final String CCM_TLS_DEV_INET_ADDRESS = "1.3.6.1.4.1.9.9.156.1.10.25.0";
	public static final String CCM_TLS_CONN_FAIL_TIME = "1.3.6.1.4.1.9.9.156.1.10.26.0";
	public static final String CCM_TLS_CONN_FAIL_REASON_CODE = "1.3.6.1.4.1.9.9.156.1.10.27.0";
	public static final String CCM_GATEWAY_REG_FAIL_CAUSE_CODE = "1.3.6.1.4.1.9.9.156.1.10.28.0";
	public static final String CVA_ALARM_SEVERITY_OID = "1.3.6.1.4.1.9.9.190.1.2.1.0";
	public static final String CVA_MODULE_NAME_OID = "1.3.6.1.4.1.9.9.190.1.2.2.0";
	public static final String CVA_PROCESS_ID_OID = "1.3.6.1.4.1.9.9.190.1.2.3.0";
	public static final String CVA_MODULE_FAILURE_NAME_OID = "1.3.6.1.4.1.9.9.190.1.2.4.0";
	public static final String CVA_MODULE_FAILURE_CAUSE_OID = "1.3.6.1.4.1.9.9.190.1.2.5.0";
	public static final String CVA_MODULE_FAILURE_MESSAGE_OID = "1.3.6.1.4.1.9.9.190.1.2.6.0";
	public static final String CVA_MODULE_RUN_TIME_FAILURE_CAUSE_OID = "1.3.6.1.4.1.9.9.190.1.2.7.0";
	public static final String CCCA_EVENT_COMPONENT_ID_OID = "1.3.6.1.4.1.9.9.473.1.4.1.0";
	public static final String CCCA_EVENT_MESSAGE_ID_OID = "1.3.6.1.4.1.9.9.473.1.4.3.0";
	public static final String CCCA_EVENT_ORIGINATING_PROCESS_NAME_OID = "1.3.6.1.4.1.9.9.473.1.4.6.0";	
	public static final String CCCA_EVENT_SEVERITY_OID = "1.3.6.1.4.1.9.9.473.1.4.9.0";
	public static final String CCCA_EVENT_TIMESTAMP_OID = "1.3.6.1.4.1.9.9.473.1.4.10.0";
	public static final String CCCA_EVENT_TEXT_OID = "1.3.6.1.4.1.9.9.473.1.4.11.0";
	
	public static final String TRAP_UNDEFINED = "Trap Type Undefined for ";
	public static final String CCM_CALL_MANAGER_FAILED = "ccmCallManagerFailed";
	public static final String CCM_PHONE_FAILED = "ccmPhoneFailed";
	public static final String CCM_PHONE_STATUS_UPDATE = "ccmPhoneStatusUpdate";
	public static final String CCM_GATEWAY_FAILED = "ccmGatewayFailed";
	public static final String CCM_MEDIA_RESOURCE_LIST_EXHAUSTED = "ccmMediaResourceListExhausted";
	public static final String CCM_ROUTE_LIST_EXHAUSTED = "ccmRouteListExhausted";
	public static final String CCM_GATEWAY_LAYER_CHANGE = "ccmGatewayLayer2Change";
	public static final String CCM_MALICIOUS_CALL = "ccmMaliciousCall";
	public static final String CCM_QUALITY_REPORT = "ccmQualityReport";
	public static final String CCM_TLS_CONNECTION_FAILURE = "ccmTLSConnectionFailure";
	public static final String CCM_GATEWAY_FAILED_REASON = "ccmGatewayFailedReason";
	public static final String CVA_MODULE_START = "cvaModuleStart";
	public static final String CVA_MODULE_STOP = "cvaModuleStop";
	public static final String CVA_MODULE_RUN_TIME_FAILURE = "cvaModuleRunTimeFailure";
	public static final String CVA_PROCESS_START = "cvaProcessStart";
	public static final String CVA_PROCESS_STOP = "cvaProcessStop";
	public static final String CCCA_ICM_EVENT = "cccaIcmEvent";
	public static final String UNKNOWN = "unknown";
	public static final String IPV4 = "ipv4";
	public static final String IPV6 = "ipv6";
	public static final String IPV4Z = "ipv4z";
	public static final String IPV6Z = "ipv6z";
	public static final String DNS = "dns";
	
	public static final String CCM_FAIL_CAUSE_CODE_MESSAGE_1 = "The failure of Call Manager is Unknown.";
	public static final String CCM_FAIL_CAUSE_CODE_MESSAGE_2 = "The CallManager stops generating a heartbeat.";
	public static final String CCM_FAIL_CAUSE_CODE_MESSAGE_3 = "The CallManager detects the death of the router thread.";
	public static final String CCM_FAIL_CAUSE_CODE_MESSAGE_4 = "The CallManager detects the death of the timer thread.";
	public static final String CCM_FAIL_CAUSE_CODE_MESSAGE_5 = "The CallManager detects the death of one of its critical threads.";
	public static final String CCM_FAIL_CAUSE_CODE_MESSAGE_6 = "The CallManager fails to start its device manager subsystem.";
	public static final String CCM_FAIL_CAUSE_CODE_MESSAGE_7 = "The CallManager fails to start its digit analysis subsystem.";
	public static final String CCM_FAIL_CAUSE_CODE_MESSAGE_8 = "The CallManager fails to start its call control subsystem.";
	public static final String CCM_FAIL_CAUSE_CODE_MESSAGE_9 = "The CallManager fails to start its link manager subsystem.";
	public static final String CCM_FAIL_CAUSE_CODE_MESSAGE_10 = "The CallManager fails to start its database manager subsystem.";
	public static final String CCM_FAIL_CAUSE_CODE_MESSAGE_11 = "The CallManager fails to start its message translation manager subsystem.";
	public static final String CCM_FAIL_CAUSE_CODE_MESSAGE_12 = "The CallManager fails to start its supplementary services subsystem.";
	public static final String CCM_PHONE_FAILURES_MESSAGE = "The count of phone initialization or communication failure = ";
	public static final String CCM_PHONE_UPDATE_MESSAGE = "The count of the phone whose status is changed = ";
	public static final String CCM_GATEWAY_FAILED_MESSAGE_0 = "No Error";
	public static final String CCM_GATEWAY_FAILED_MESSAGE_1 = "Unknown";
	public static final String CCM_GATEWAY_FAILED_MESSAGE_2 = "No Entry In Database";
	public static final String CCM_GATEWAY_FAILED_MESSAGE_3 = "Database Configuration Error";
	public static final String CCM_GATEWAY_FAILED_MESSAGE_4 = "Device Name Unresolveable";
	public static final String CCM_GATEWAY_FAILED_MESSAGE_5 = "Maximum Dev Reg Reached";
	public static final String CCM_GATEWAY_FAILED_MESSAGE_6 = "Connectivity Error";
	public static final String CCM_GATEWAY_FAILED_MESSAGE_7 = "Initialization Error";
	public static final String CCM_GATEWAY_FAILED_MESSAGE_8 = "Device Initiated Reset";
	public static final String CCM_GATEWAY_FAILED_MESSAGE_9 = "Call Manager Reset";
	public static final String CCM_GATEWAY_FAILED_MESSAGE_10 = "Authentication Error";
	public static final String CCM_GATEWAY_FAILED_MESSAGE_11 = "Invalid X509 Name In Certificate";
	public static final String CCM_GATEWAY_FAILED_MESSAGE_12 = "Invalid TLS Cipher";
	public static final String CCM_GATEWAY_FAILED_MESSAGE_13 = "Directory Number Mismatch";
	public static final String CCM_GATEWAY_FAILED_MESSAGE_14 = "Malformed Register";
	public static final String CCM_GATEWAY_FAILED_MESSAGE = "The Gateway %GatewayName - %IpAddress with Inet Address Type %IpAddressType is failed due to %FailedCode.";	
	public static final String CCM_MEDIA_LIST_EXHAUSTED_MESSAGE = "The Media List - %MediaListName of Type - %MediaListType is exhausted.";
	public static final String CCM_ROUTE_LIST_EXHAUSTED_MESSAGE = "The Route List - %RouteListName is exhausted.";
	public static final String CCM_GATEWAY_LAYER2_CHANGE_MESSAGE = "The layer 2 status of Interface - %InterfaceName in Gateway - %GatewayName(%GatewayInetAddress) that has registered with the local CallManager is %GatewayInterfaceStatus.";
	public static final String CCM_GATEWAY_LAYER2_CHANGE_MESSAGE_1 = "Up";
	public static final String CCM_GATEWAY_LAYER2_CHANGE_MESSAGE_2 = "Down";
	public static final String CCM_MALICIOUS_CALL_MESSAGE = "The Calling Party: %CcmMaliCallCallingPartyName with Party Number: %CcmMaliCallCallingPartyNumber and Device Name: %CcmMaliCallCallingDeviceName registers a call as malicious with the call manager with Party Name: %CcmMaliCallCalledPartyName, Party Number: %CcmMaliCallCalledPartyNumber and Device Name: %CcmMaliCallCalledDeviceName at %CcmMaliCallTime.";
	public static final String CCM_QUALITY_REPORT_MESSAGE = "The Source: %CcmQualityRprtSourceDevName in Cluster: %CcmQualityRprtClusterId reports a quality problem of Category: %CcmQualityRprtCategory with Reason Code: %CcmQualityRprtReasonCode at ccmQualityRprtTime.";
	public static final String CCM_TLS_CONNECTION_FAILURE_MESSAGE = "The CallManager fails to open TLS connection for TLS Dev: %CcmTLSDevName(%ccmTLSDevInetAddress) due to Reason: %CcmTLSConnectionFailReasonCode at %CcmTLSConnFailTime.";
	public static final String CCM_TLS_CONNECTION_FAILURE_MESSAGE_2 = "Authentication Error";
	public static final String CCM_TLS_CONNECTION_FAILURE_MESSAGE_3 = "Invalid x509 Name in Certificate";
	public static final String CCM_TLS_CONNECTION_FAILURE_MESSAGE_4 = "Invalid TLS Cipher";
	public static final String CCM_GATEWAY_FAILED_REASON_MESSAGE = "The Gateway: %CcmGatewayName(%CcmGatewayInetAddress) has attempted to register or communicate with the CallManager and failed due to Reason: %CcmGatewayRegFailCauseCode.";
	public static final String CCM_GATEWAY_FAILED_REASON_MESSAGE_0 = "No Error";
	public static final String CCM_GATEWAY_FAILED_REASON_MESSAGE_1 = "Unknown";
	public static final String CCM_GATEWAY_FAILED_REASON_MESSAGE_2 = "No Entry In Database";
	public static final String CCM_GATEWAY_FAILED_REASON_MESSAGE_3 = "Database Configuration Error";
	public static final String CCM_GATEWAY_FAILED_REASON_MESSAGE_4 = "DeviceName Unresolveable";
	public static final String CCM_GATEWAY_FAILED_REASON_MESSAGE_5 = "Max Dev Reg Exceeded";
	public static final String CCM_GATEWAY_FAILED_REASON_MESSAGE_6 = "Connectivity Error";
	public static final String CCM_GATEWAY_FAILED_REASON_MESSAGE_7 = "Initialization Error";
	public static final String CCM_GATEWAY_FAILED_REASON_MESSAGE_8 = "Device Initiated Reset";
	public static final String CCM_GATEWAY_FAILED_REASON_MESSAGE_9 = "Call Manager Reset";
	public static final String CCM_GATEWAY_FAILED_REASON_MESSAGE_10 = "Authentication Error";
	public static final String CCM_GATEWAY_FAILED_REASON_MESSAGE_11 = "Invalid X509 Name In Certificate";
	public static final String CCM_GATEWAY_FAILED_REASON_MESSAGE_12 = "Invalid TLS Cipher";
	public static final String CCM_GATEWAY_FAILED_REASON_MESSAGE_13 = "Directory Number Mismatch";
	public static final String CCM_GATEWAY_FAILED_REASON_MESSAGE_14 = "Malformed Register Message";
	public static final String CCM_GATEWAY_FAILED_REASON_MESSAGE_15 = "Protocol Mismatch";
	public static final String CCM_GATEWAY_FAILED_REASON_MESSAGE_16 = "Device Not Active";
	public static final String CCM_GATEWAY_FAILED_REASON_MESSAGE_17 = "Authenticated Device Already Exists";
	public static final String CCM_GATEWAY_FAILED_REASON_MESSAGE_18 = "Obsolete Protocol Version";
	public static final String CCM_GATEWAY_FAILED_REASON_MESSAGE_23 = "Database Timeout";
	public static final String CCM_GATEWAY_FAILED_REASON_MESSAGE_25 = "Registration Sequence Error";
	public static final String CCM_GATEWAY_FAILED_REASON_MESSAGE_26 = "Invalid Capabilities";
	public static final String CCM_GATEWAY_FAILED_REASON_MESSAGE_27 = "Capability Response Timeout";
	public static final String CCM_GATEWAY_FAILED_REASON_MESSAGE_28 = "Security Mismatch";
	public static final String CCM_GATEWAY_FAILED_REASON_MESSAGE_29 = "Auto Register DB Error";
	public static final String CCM_GATEWAY_FAILED_REASON_MESSAGE_30 = "DB Access Error";
	public static final String CCM_GATEWAY_FAILED_REASON_MESSAGE_31 = "Auto Register DB Config Timeout";
	public static final String CCM_GATEWAY_FAILED_REASON_MESSAGE_32 = "Device Type Mismatch";
	public static final String CCM_GATEWAY_FAILED_REASON_MESSAGE_33 = "Addressing Mode Mismatch";
	public static final String CVA_MODULE_START_MESSAGE = "The application module or subsystem with Module Name %ModuleName has successfully started and transitioned into in-service state.";
	public static final String CVA_MODULE_STOP_MESSAGE = "An application module or subsystem has stopped with module name %ModuleName. The Module Failure cause is %FailureCause. The Module Failure Name is %FailureName. The Module Failure Message is %FailureMessage.";
	public static final String CVA_MODULE_RUN_TIME_FAILURE_MESSAGE = "A run time failure has occurred. Module name = %ModuleName, Module Run Time Failure Cause = %RunTimeFailureCause, Module Failure Name = %FailureName, Module Failure Message = %FailureMessage.";
	public static final String CVA_PROCESS_START_MESSAGE = "A process with Module Name %ModuleName has just started. The Process Id is %ProcessId.";
	public static final String CVA_PROCESS_STOP_MESSAGE = "A process with Module Name %ModuleName has just stopped. The Process Id is %ProcessId.";
	public static final String CCCA_ICM_EVENT_MESSAGE = "%CccaEventText Event occurred at %CccaEventTimestamp Due to Process %CccaEventOriginatingProcessName";
	
	//Probe Callback
	public static final String CONTROLLER_PATH = "controller";
	public static final String CONTROLLER_CALLBACK_GET_INFO = "get_info";
	public static final String CONTROLLER_CALLBACK_GET_INFO_ROBOT_IP = "robotip";
	
	//Exception Message
	public static final String EXCEPTION_MESSAGE = "Exception Message = ";
	public static final String TRAP_LISTENING_ERROR = "Error in Listening for Trap";
	public static final String CONTROLLER_IP_RETREIVING_ERROR = "Error in Retreiving IP from Controller.";
	public static final String CONTROLLER_PDS_NULL = "Size of Controller Callback PDS is null.";
	public static final String ROBOT_IP_NOT_FOUND = "Robot IP Not Found.";
	public static final String TRAP_LISTENING_NOT_STARTED = "Trap Listening Not Started.";

	//AXL Information
	public static final String SYSTEM_AXL="SystemAXL";
	public static final String MEMORY_AXL="MemoryAXL";
	public static final String AXL = "AXL";	
	public static final String CONTENT_TYPE_KEY="Content-Type";
	public static final String CONTENT_TYPE_VALUE="application/text/xml";
	public static final String SOAP_ACTION_KEY="soapAction";
	public static final String AXL_CONFIG_FILE_NAME="axlConfig.properties";
	//public static final String IP="ip";
	public static final String PORT="PORT";
	public static final String USERNAME="USERNAME";
	public static final String PASSWORD="PASSWORD";
	public static final String AXL_CLASSES_FILE_NAME="classes.txt";	
	

	public static final String CISCO_TOMCAT_JVM="CiscoTomcatJVM";
	public static final String CISCO_TOMCAT_JVM_DESCRIPTION="Cisco Tomcat JVM";
	// Cisco Tomcat JVM QOS start
	public static final String K_BYTES_MEMORY_FREE="KBytesMemoryFree";
	public static final String K_BYTES_MEMORY_MAX="KBytesMemoryMax";
	public static final String K_BYTES_MEMORY_TOTAL="KBytesMemoryTotal";
	
	
	// Cisco Tomcat JVM QOS end
	
	
	public static final String CISCO_TOMCAT_WEB_APPLICATION="CiscoTomcatWebApplication";
	public static final String CISCO_TOMCAT_WEB_APPLICATION_DESCRIPTION="Cisco Tomcat Web Application";
	
	// CISCO TOMCAT WEB APPLICATION INSTANCE START
	public static final String CCM_TRUST_CERTS="CCMTrustCerts";
	public static final String CD_RON_DEMAND_SERVICE="CDRonDemandService";
	public static final String CD_RON_DEMAND_SERVICE2="CDRonDemandService2";
	public static final String CALL_RECORD_SERVICE="CallRecordService";
	public static final String HELP="Help";
	public static final String HELP_PAGES="Help_pages";
	public static final String PHONE_GUIDES="PhoneGuides";
	public static final String SNMP_SERVICE="SNMPService";
	public static final String ROOT="_root";
	public static final String AST="ast";
	public static final String CAR_REPORTS="carreports";
	public static final String CCM_ADMIN="ccmadmin";
	public static final String CCM_CIP="ccmcip";
	public static final String CCM_PD="ccmpd";
	public static final String CCM_SERVICE="ccmservice";
	public static final String CCM_USER="ccmuser";
	public static final String CHANGE_CREDENTIALS="changecredential";
	public static final String CM_PLATFORM="cmplatform";
	public static final String CONTROL_CENTER_SERVICE="controlcenterservice";
	public static final String CONTROL_CENTER_SERVICE2="controlcenterservice2";
	public static final String CUCM_UDS="cucm-uds";
	public static final String CUC_REPORTS="cucreports";
	public static final String DP_SERVICE="dpservice";
	public static final String DRF="drf";
	public static final String E_911_PROXY="e911proxy";
	public static final String ELM_ADMIN="elm-admin";
	public static final String ELM_CLIENT_SERVICES="elm-client-services";
	public static final String EM_APP="emapp";
	public static final String GRT="grt";
	public static final String LOG4J_INIT="log4jinit";
	public static final String LOG_COLLECTION_SERVICE="logcollectionservice";
	public static final String LOG_COLLECTION_SERVICE2="logcollectionservice2";
	public static final String MANAGER="manager";
	public static final String PERFMON_SERVICE="perfmonservice";
	public static final String PERFMON_SERVICE2="perfmonservice2";
	public static final String PKT_CAP="pktCap";
	public static final String PLATFORM_SERVICES="platform-services";
	public static final String PLUGINS="plugins";
	public static final String REAL_TIME_SERVICE="realtimeservice";
	public static final String REAL_TIME_SERVICE2="realtimeservice2";
	public static final String REPORTER_SERVLET="reporter-servlet";
	public static final String TOMCAT_STATS="tomcatstats";
	public static final String TRACE_COLLECTION="tracecollection";
	public static final String UCM_ADMIN="ucmadmin";
	public static final String UCM_USER="ucmuser";
	
	// CISCO TOMCAT WEB APPLICATION INSTANCE END
	
	// CISCO TOMCAT WEB APPLICATION QOS START
	public static final String ERRORS="Errors";
	
	public static final String SESSION_ACTIVE="SessionsActive";
	
	
	// CISCO TOMCAT WEB APPLICATION QOS END
	
	/*public static final String DB_USER_HOST_INFORMATION_COUNTERS="DBUserHostInformationCounters";
	public static final String DB_USER_HOST_INFORMATION_COUNTERS_DESCRIPTION="DB User Host Information Counters";
	public static final String DATABASE_CUCM9="database:cucm9";
	public static final String DBAMC_CUCM9="dbamc:cucm9";
	public static final String DBMON_CUCM9="dbmon:cucm9";
	public static final String INFORMIX="informix:";
	public static final String INFORMIX_CUCM9="informix:cucm9";
	public static final String DB_USER_HOST_INSTANCES="DB:User:Host Instances";*/
	
	public static final String DB_LOCAL_DSN="DBLocal_DSN";
	public static final String DB_LOCAL_DSN_DESCRIPTION="DB Local_DSN";
	public static final String CN_DB_SPACE_USED="CNDbSpace_Used";
	public static final String CCM_DB_SPACE_USED="CcmDbSpace_Used";
	public static final String CCM_TEMP_SPACE_USED="CcmtempDbSpace_Used";
	public static final String DATABASE_CONNECTIONS_ACTIVE="DatabaseConnectionsActive";
	public static final String LOCAL_DSN="LocalDSN";
	public static final String ROOT_DB_SPACE_USED="RootDbSpace_Used";
	public static final String SHARED_MEMORY_FREE="SharedMemory_Free";
	public static final String SHARED_MEMORY_USED="SharedMemory_Used";
	
	
	public static final String CISCO_REPLICATION_DBSPACE_MONITORS="EnterpriseReplicationDBSpaceMonitors";
	public static final String CISCO_REPLICATION_DBSPACE_MONITORS_DESCRIPTION="Enterprise Replication DBSpace Monitors";
	public static final String DSN_CCM_NODE_NAME_CUCM9="DSN=ccm;NodeName=cucm9";
	public static final String DSN_CCM_NODE_NAME_CUCM9_DESCRIPTION="DSN=ccm;: NodeName = cucm9";
	public static final String ER_DB_SPACE_USED="ERDbSpace_Used";
	public static final String ER_SB_DB_SPACE_USED="ERSBDbSpace_Used";
	
	
	
	
	
	
	
	// Memory QOS start
	public static final String MEMORY_USED="MemUsed";
	public static final String PAGE_USED="PageUsage";
	public static final String VM_USED="VMUsed";
	public static final String BUFFERS_K_BYTES="BuffersKBytes";
	public static final String CACHED_K_BYTES="CachedKBytes";
	public static final String FREE_K_BYTES="FreeKBytes";
	public static final String FREE_SWAP_K_BYTES="FreeSwapKBytes";
	public static final String HIGH_FREE="HighFree";
	public static final String HIGH_TOTAL="HighTotal";
	public static final String LOW_FREE="LowFree";
	public static final String LOW_TOTAL="LowTotal";
	public static final String PAGE_FAULTS_PER_SEC="PageFaultsPerSec";
	public static final String PAGE_MAJOR_FAULTS_PER_SEC="PageMajorFaultsPerSec";
	public static final String PAGES="Pages";
	public static final String PAGES_INPUT="PagesInput";
	public static final String PAGES_INPUT_PER_SEC="PagesInputPerSec";
	public static final String PAGES_OUTPUT="PagesOutput";
	public static final String PAGES_OUTPUT_PER_SEC="PagesOutputPerSec";
	public static final String SHARED_K_BYTES="SharedKBytes";
	public static final String SLAB_CACHE="SlabCache";
	public static final String SWAP_CACHED="SwapCached";
	public static final String TOTAL_K_BYTES="TotalKBytes";
	public static final String TOTAL_SWAP_K_BYTES="TotalSwapKBytes";
	public static final String TOTAL_VM_K_BYTES="TotalVMKBytes";
	public static final String USED_K_BYTES="UsedKBytes";
	public static final String USED_SWAP_K_BYTES="UsedSwapKBytes";
	public static final String USED_VM_K_BYTES="UsedVMKBytes";
	
	public static final String MEMORY_USED_DESCRIPTION="% Mem Used";
	public static final String PAGE_USED_DESCRIPTION="% Page Usage";
	public static final String VM_USED_DESCRIPTION="% VM Used";
	public static final String BUFFERS_K_BYTES_DESCRIPTION="Buffers KBytes";
	public static final String CACHED_K_BYTES_DESCRIPTION="Cached KBytes";
	public static final String FREE_K_BYTES_DESCRIPTION="Free KBytes";
	public static final String FREE_SWAP_K_BYTES_DESCRIPTION="Free Swap KBytes";
	public static final String LOW_FREE_DESCRIPTION="Low Free";
	public static final String LOW_TOTAL_DESCRIPTION="Low Total";
	public static final String PAGE_FAULTS_PER_SEC_DESCRIPTION="Page Faults Per Sec";
	public static final String PAGE_MAJOR_FAULTS_PER_SEC_DESCRIPTION="Page Major Faults Per Sec";
	public static final String PAGES_INPUT_DESCRIPTION="Pages Input";
	public static final String PAGES_INPUT_PER_SEC_DESCRIPTION="Pages Input Per Sec";
	public static final String PAGES_OUTPUT_DESCRIPTION="Pages Output";
	public static final String PAGES_OUTPUT_PER_SEC_DESCRIPTION="Pages Output Per Sec";
	public static final String SHARED_K_BYTES_DESCRIPTION="Shared KBytes";
	public static final String TOTAL_K_BYTES_DESCRIPTION="Total KBytes";
	public static final String TOTAL_SWAP_K_BYTES_DESCRIPTION="Total Swap KBytes";
	public static final String TOTAL_VM_K_BYTES_DESCRIPTION="Total VM KBytes";
	public static final String USED_K_BYTES_DESCRIPTION="Used KBytes";
	public static final String USED_SWAP_K_BYTES_DESCRIPTION="Used Swap KBytes";
	public static final String USED_VM_K_BYTES_DESCRIPTION="Used VM KBytes";
	
	// Memory QOS end
	
	//Partition Instance start
	public static final String ACTIVE="Active";
	public static final String SWAP="Swap";
	public static final String INACTIVE="Inactive";
	public static final String SHARED_MEMORY="SharedMemory";
	public static final String BOOT="Boot";
	public static final String COMMON="Common";
	// Partition Instance end

	// Partition QOS start
	public static final String CPU_TIME="CPUTime";
	public static final String USED="Used";
	public static final String WAIT_IN_READ="WaitinRead";
	public static final String WAIT_IN_WRITE="WaitinWrite";
	public static final String AWAIT_READ_TIME="AwaitReadTime";
	public static final String AWAIT_TIME="AwaitTime";
	public static final String AWAIT_WRITE_TIME="AwaitWriteTime";
	public static final String QUEUE_LENGTH="QueueLength";
	public static final String READ_BYTES_PER_SEC="ReadBytesPerSec";
	public static final String TOTAL_M_BYTES="TotalMbytes";
	public static final String USED_M_BYTES="UsedMbytes";
	public static final String WRITE_BYTES_PER_SEC="WriteBytesPerSec";
	
	public static final String CPU_TIME_DESCRIPTION="% CPU Time";
	public static final String USED_DESCRIPTION="% Used";
	public static final String WAIT_IN_READ_DESCRIPTION="% Wait in Read";
	public static final String WAIT_IN_WRITE_DESCRIPTION="% Wait in Write";
	public static final String AWAIT_READ_TIME_DESCRIPTION="Await Read Time";
	public static final String AWAIT_TIME_DESCRIPTION="Await Time";
	public static final String AWAIT_WRITE_TIME_DESCRIPTION="Await Write Time";
	public static final String QUEUE_LENGTH_DESCRIPTION="Queue Length";
	public static final String READ_BYTES_PER_SEC_DESCRIPTION="Read Bytes Per Sec";
	public static final String TOTAL_M_BYTES_DESCRIPTION="Total Mbytes";
	public static final String USED_M_BYTES_DESCRIPTION="Used Mbytes";
	public static final String WRITE_BYTES_PER_SEC_DESCRIPTION="Write Bytes Per Sec";
	// Partition QOS end
	
	
	// System QOS start
	
	public static final String ALLOCATED_FDS="AllocatedFDs";
	public static final String BEING_USED_FDS="BeingUsedFDs";
	public static final String FREED_FDS="FreedFDs";
	public static final String IO_AWAIT="IOAwait";
	public static final String IO_CPU_UTIL="IOCpuUtil";
	public static final String IO_K_BYTES_READ_PER_SECOND="IOKBytesReadPerSecond";
	public static final String IO_K_BYTES_WRITTEN_PER_SECOND="IOKBytesWrittenPerSecond";
	public static final String IO_PER_SECOND="IOPerSecond";
	public static final String IO_READ_REQ_MERGED_PER_SECOND="IOReadReqMergedPerSecond";
	public static final String IO_READ_REQ_PER_SECOND="IOReadReqPerSecond";
	public static final String IO_REQ_QUEUE_SIZE_AVG="IOReqQueueSizeAvg";
	public static final String IO_SECTORS_READ_PER_SECOND="IOSectorsReadPerSecond";
	public static final String IO_SECTORS_REQ_SIZE_AVG="IOSectorsReqSizeAvg";
	public static final String IO_SECTORS_WRITTEN_PER_SECOND="IOSectorsWrittenPerSecond";
	public static final String IO_SERVICE_TIME="IOServiceTime";
	public static final String IO_WRITE_REQ_MERGED_PER_SECOND="IOWriteReqMergedPerSecond";
	public static final String IO_WRITE_REQ_PER_SECOND="IOWriteReqPerSecond";
	public static final String MAX_FDS="MaxFDs";
	public static final String TOTAL_CPU_TIME="TotalCPUTime";
	public static final String TOTAL_PROCESSED="TotalProcesses";
	public static final String TOTAL_THREADS="TotalThreads";
	
	public static final String ALLOCATED_FDS_DESCRIPTION="Allocated FDs";
	public static final String BEING_USED_FDS_DESCRIPTION="Being Used FDs";
	public static final String FREED_FDS_DESCRIPTION="Freed FDs";
	public static final String MAX_FDS_DESCRIPTION="Max FDs";
	public static final String TOTAL_CPU_TIME_DESCRIPTION="Total CPU Time";
	public static final String TOTAL_PROCESSED_DESCRIPTION="Total Processes";
	public static final String TOTAL_THREADS_DESCRIPTION="Total Threads";
	
	
	// System QOS end
	
	public static final String TCP="TCP";
	// TCP QOS start
	public static final String ACTIVE_OPENS="ActiveOpens";
	public static final String CURR_ESTAB="CurrEstab";
	public static final String ESTAB_RESETS="EstabResets";
	public static final String IN_SEGS="InSegs";
	public static final String IN_OUT_SEGS="InOutSegs";
	public static final String OUT_SEGS="OutSegs";
	public static final String PASSIVE_OPENS="PassiveOpens";
	public static final String RETRANS_SEGS="RetransSegs";
	public static final String ACTIVE_OPENS_DESCRIPTION="ActiveOpens";
	public static final String CURR_ESTAB_DESCRIPTION="CurrEstab";
	public static final String ESTAB_RESETS_DESCRIPTION="EstabResets";
	public static final String IN_SEGS_DESCRIPTION="InSegs";
	public static final String IN_OUT_SEGS_DESCRIPTION="InOutSegs";
	public static final String OUT_SEGS_DESCRIPTION="OutSegs";
	public static final String PASSIVE_OPENS_DESCRIPTION="PassiveOpens";
	public static final String RETRANS_SEGS_DESCRIPTION="RetransSegs";
	// TCP QOS end
	public static final String THREAD="Thread";
	
	// Thread QOS start
	public static final String PID="PID";
	// Thred QOS end
	
	public static final String CISCO_CALLMANAGER="CiscoCallManager";
	public static final String CISCO_CALLMANAGER_DESCRIPTION="Cisco CallManager";
	// Cisco CallManager QOS start
	public static final String ANNUCIATOR_OUT_OF_RESOURCES="AnnunciatorOutOfResources";
	public static final String ANNUCIATOR_RESOURCE_ACTIVE="AnnunciatorResourceActive";
	public static final String ANNUCIATOR_RESOURCE_AVAILABLE="AnnunciatorResourceAvailable";
	public static final String ANNUCIATOR_RESOURCE_TOTAL="AnnunciatorResourceTotal";
	public static final String AUTHENTICATED_CALLS_ACTIVE="AuthenticatedCallsActive";
	public static final String AUTHENTICATED_CALLS_COMPLETED="AuthenticatedCallsCompleted";
	public static final String AUTHENTICATED_PARTIALLY_REGISTERED_PHONE="AuthenticatedPartiallyRegisteredPhone";
	public static final String AUTHENTICATED_REGISTERED_PHONES="AuthenticatedRegisteredPhones";
	public static final String BRI_CHANNELS_ACTIVE="BRIChannelsActive";
	public static final String BRI_SPANS_IN_SERVICE="BRISpansInService";
	public static final String CALL_MANAGER_HEART_BEAT="CallManagerHeartBeat";
	public static final String CALLS_ACTIVE="CallsActive";
	public static final String CALLS_ATTEMPTED="CallsAttempted";
	public static final String CALLS_COMPLETED="CallsCompleted";
	public static final String CALLS_IN_PROGRESS="CallsInProgress";
	public static final String CUMULATIVE_ALLOCATED_RESOURCE_CANNOT_OPEN_PORT="CumulativeAllocatedResourceCannotOpenPort";
	public static final String ENCRYPTED_CALLS_ACTIVE="EncryptedCallsActive";
	public static final String ENCRYPTED_CALLS_COMPLETED="EncryptedCallsCompleted";
	public static final String ENCRYPTED_PARTIALLY_REGISTERED_PHONES="EncryptedPartiallyRegisteredPhones";
	public static final String ENCRYPTED_REGISTERED_PHONES="EncryptedRegisteredPhones";
	public static final String EXTERNAL_CALL_CONTROL_ENABLED_CALLS_ATTEMPTED="ExternalCallControlEnabledCallsAttempted";
	public static final String EXTERNAL_CALL_CONTROL_ENABLED_CALLS_COMPLTED="ExternalCallControlEnabledCallsCompleted";
	public static final String EXTERNAL_CALL_CONTROL_ENABLED_FAILURE_TREATMENT_APPLIED="ExternalCallControlEnabledFailureTreatmentApplied";
	public static final String FXO_PORTS_ACTIVE="FXOPortsActive";
	public static final String FXO_PORTS_IN_SERVICE="FXOPortsInService";
	public static final String FXS_PORTS_ACTIVE="FXSPortsActive";
	public static final String FXS_PORTS_IN_SERVICE="FXSPortsInService";
	public static final String HW_CONFERENCE_ACTIVE="HWConferenceActive";
	public static final String HW_CONFERENCE_COMPLETED="HWConferenceCompleted";
	public static final String HW_CONFERENCE_OUT_OF_RESOURCES="HWConferenceOutOfResources";
	public static final String HW_CONFERENCE_RESOURCE_ACTIVE="HWConferenceResourceActive";
	public static final String HW_CONFERENCE_RESOURCE_AVAILABLE="HWConferenceResourceAvailable";
	public static final String HW_CONFERENCE_RESOURCE_TOTAL="HWConferenceResourceTotal";
	public static final String HUNT_LISTS_IN_SERVICE="HuntListsInService";
	public static final String INITIALIZATION_STATE="InitializationState";
	public static final String LOCATION_OUT_OF_RESOURCES="LocationOutOfResources";
	public static final String MCU_CONFERENCE_ACTIVE="MCUConferencesActive";
	public static final String MCU_CONFERENCE_COMPLETED="MCUConferencesCompleted";
	public static final String MCU_HTTP_CONNECTION_ERRORS="MCUHttpConnectionErrors";
	public static final String MCU_HTTP_NON_200_OK_RESPONSE="MCUHttpNon200OkResponse";
	public static final String MCU_OUT_OR_RESOURCES="MCUOutOfResources";
	public static final String MOH_MULTICAST_RESOURCE_ACTIVE="MOHMulticastResourceActive";
	public static final String MOH_MULTICAST_RESOURCE_AVAILABLE="MOHMulticastResourceAvailable";
	public static final String MOH_OUT_OF_RESOURCES="MOHOutOfResources";
	public static final String MOH_TOTAL_MULTICAST_RESOURCES="MOHTotalMulticastResources";
	public static final String MOH_TOTAL_UNICAST_RESOURCES="MOHTotalUnicastResources";
	public static final String MOH_UNICAST_RESOURCE_ACTIVE="MOHUnicastResourceActive";
	public static final String MOH_UNICAST_RESOURCE_AVAILABLE="MOHUnicastResourceAvailable";
	public static final String MTP_OUT_OF_RESOURCES="MTPOutOfResources";
	public static final String MTP_REQUESTS_THROTTLED="MTPRequestsThrottled";
	public static final String MTP_RESOURCE_ACTIVE="MTPResourceActive";
	public static final String MTP_RESOURCE_AVAILABLE="MTPResourceAvailable";
	public static final String MTP_RESOURCE_TOTAL="MTPResourceTotal";
	public static final String PRI_CHANNELS_ACTIVE="PRIChannelsActive";
	public static final String PRI_SPANS_IN_SERVICE="PRISpansInService";
	public static final String PARTIALLY_REGISTERED_PHONE="PartiallyRegisteredPhone";
	public static final String REGISTERED_ANALOG_ACCESS="RegisteredAnalogAccess";
	public static final String REGISTERED_HARDWARE_PHONES="RegisteredHardwarePhones";
	public static final String REGISTERED_MGCP_GATEWAY="RegisteredMGCPGateway";
	public static final String REGISTERED_OTHER_STATION_DEVICES="RegisteredOtherStationDevices";
	public static final String SIP_LINE_SERVER_AUTHORIZATION_CHALLENGES="SIPLineServerAuthorizationChallenges";
	public static final String SIP_LINE_SERVER_AUTHORIZATION_FAILURES="SIPLineServerAuthorizationFailures";
	public static final String SIP_TRUNK_APPLICATION_AUTHORIZATION_FAILURES="SIPTrunkApplicationAuthorizationFailures";
	public static final String SIP_TRUNK_APPLICATION_AUTHORIZATIONS="SIPTrunkApplicationAuthorizations";
	public static final String SIP_TRUNK_AUTHORIZATION_FAILURES="SIPTrunkAuthorizationFailures";
	public static final String SIP_TRUNK_AUTHORIZATIONS="SIPTrunkAuthorizations";
	public static final String SIP_TRUNK_SERVER_AUTHENTICATION_CHALLENGES="SIPTrunkServerAuthenticationChallenges";
	public static final String SIP_TRUNK_SERVER_AUTHENTICATION_FAILURES="SIPTrunkServerAuthenticationFailures";
	public static final String SW_CONFERENCE_ACTIVE="SWConferenceActive";
	public static final String SW_CONFERENCE_COMPLETED="SWConferenceCompleted";
	public static final String SW_CONFERENCE_OUT_OF_RESOURCES="SWConferenceOutOfResources";
	public static final String SW_CONFERENCE_RESOURCE_ACTIVE="SWConferenceResourceActive";
	public static final String SW_CONFERENCE_RESOURCE_AVAILABLE="SWConferenceResourceAvailable";
	public static final String SW_CONFERENCE_RESOURCE_TOTAL="SWConferenceResourceTotal";
	public static final String SYSTEM_CALLS_ATTEMPTED="SystemCallsAttempted";
	public static final String T1_CHANNELS_ACTIVE="T1ChannelsActive";
	public static final String T1_SPANS_IN_SERVICE="T1SpansInService";
	public static final String TLS_CONNECTED_SIP_TRUNKS="TLSConnectedSIPTrunks";
	public static final String TLS_CONNECTED_WSM="TLSConnectedWSM";
	public static final String TRANSCODER_OUT_OF_RESOURCES="TranscoderOutOfResources";
	public static final String TRANSCODER_REQUESTS_THROTTLED="TranscoderRequestsThrottled";
	public static final String TRANSCODER_RESOURCE_ACTIVE="TranscoderResourceActive";
	public static final String TRANSCODER_RESOURCE_AVAILABLE="TranscoderResourceAvailable";
	public static final String TRANSCODER_RESOURCE_TOTAL="TranscoderResourceTotal";
	public static final String VCB_CONFERENCES_ACTIVE="VCBConferencesActive";
	public static final String VCB_CONFERENCES_AVAILABLE="VCBConferencesAvailable";
	public static final String VCB_CONFERENCES_COMPLETED="VCBConferencesCompleted";
	public static final String VCB_CONFERENCES_TOTAL="VCBConferencesTotal";
	public static final String VCB_OUT_OF_CONFERENCES="VCBOutOfConferences";
	public static final String VCB_OUT_OF_RESOURCES="VCBOutOfResources";
	public static final String VCB_RESOURCE_ACTIVE="VCBResourceActive";
	public static final String VCB_RESOURCE_AVAILABLE="VCBResourceAvailable";
	public static final String VCB_RESOURCE_TOTAL="VCBResourceTotal";
	public static final String VIDEO_CALLS_ACTIVE="VideoCallsActive";
	public static final String VIDEO_CALLS_COMPLETED="VideoCallsCompleted";
	public static final String VIDEO_OUT_OF_RESOURCES="VideoOutOfResources";
	// Cisco CallManager QOS end
	
	public static final String CISCO_H323="CiscoH323";
	public static final String CISCO_H323_DESCRIPTION="Cisco H323";
	
	// Cisco H323 Start
	
	public static final String CALLS_REJECTED_DUE_TO_ICT_CALL_THROTTLING="CallsRejectedDueToICTCallThrottling";
	
	// Cisco H323 End
	
	public static final String CISCO_MGCP_FXO_DEVICE="CiscoMGCPFXODevice";
	public static final String CISCO_MGCP_FXO_DEVICE_DESCRIPTION="Cisco MGCP FXO Device";
	// Cisco MGCP FXO Device START
	
	public static final String OUTBOUND_BUSY_ATTEMPTS="OutboundBusyAttempts";
	public static final String PORT_STATUS="PortStatus";
	
	// Cisco MGCP FXO Device END
	
	public static final String CISCO_MGCP_FXS_DEVICE="CiscoMGCPFXSDevice";
	public static final String CISCO_MGCP_FXS_DEVICE_DESCRIPTION="Cisco MGCP FXS Device";
	
	public static final String CISCO_MGCP_GATEWAYS="CiscoMGCPGateways";
	public static final String CISCO_MGCP_GATEWAYS_DESCRIPTION="Cisco MGCP Gateways";
	
	public static final String CISCO_MTP_DEVICE="CiscoMTPDevice";
	public static final String CISCO_MTP_DEVICE_DESCRIPTION="Cisco MTP Device";
	
	// Cisco MTP Device QOS start
	
	public static final String OUT_OF_RESOURCES="OutOfResources";
	public static final String RESOURCE_ACTIVE="ResourceActive";
	public static final String RESOURCE_AVAILABLE="ResourceAvailable";
	public static final String RESOURCE_TOTAL="ResourceTotal";
	
	// Cisco MTP Device QOS end
	
	public static final String CISCO_PHONES="CiscoPhones";
	public static final String CISCO_PHONES_DESCRIPTION="Cisco Phones";
	
	public static final String CISCO_SIP="CiscoSIP";
	public static final String CISCO_SIP_DESCRIPTION="Cisco SIP";
	
	public static final String CISCO_TFTP="CiscoTFTPServer";
	public static final String CISCO_TFTP_DESCRIPTION="Cisco TFTP Server";
	//Cisco TFTP QOS start
	
	public static final String BUILD_ABORT_COUNT="BuildAbortCount";
	public static final String BUILD_COUNT="BuildCount";
	public static final String BUILD_DEVICE_COUNT="BuildDeviceCount";
	public static final String BUILD_DIAL_RULE_COUNT="BuildDialruleCount";
	public static final String BUILD_DURATION="BuildDuration";
	public static final String BUILD_FEATURE_POLICY_COUNT="BuildFeaturePolicyCount";
	public static final String BUILD_SIGN_COUNT="BuildSignCount";
	public static final String BUILD_SOFT_KEY_COUNT="BuildSoftkeyCount";
	public static final String BUILD_UNIT_COUNT="BuildUnitCount";
	public static final String CHANGE_NOTIFICATIONS="ChangeNotifications";
	public static final String DEVICE_CHANGE_NOTIFICATIONS="DeviceChangeNotifications";
	public static final String DIAL_RULE_CHANGE_NOTIFICATIONS="DialruleChangeNotifications";
	public static final String ENCRYPT_COUNT="EncryptCount";
	public static final String FEATURE_POLICY_CHANGE_NOTIFICATIONS="FeaturePolicyChangeNotifications";
	public static final String GK_FOUND_COUNT="GKFoundCount";
	public static final String GK_NOT_FOUND_COUNT="GKNotFoundCount";
	public static final String HEART_BEAT="HeartBeat";
	public static final String HTTP_CONNECT_REQUESTS="HttpConnectRequests";
	public static final String HTTP_REQUESTS="HttpRequests";
	public static final String HTTP_REQUESTS_ABORTED="HttpRequestsAborted";
	public static final String HTTP_REQUESTS_NOT_FOUND="HttpRequestsNotFound";
	public static final String HTTP_REQUESTS_OVERFLOW="HttpRequestsOverflow";
	public static final String HTTP_REQUESTS_PROCESSED="HttpRequestsProcessed";
	public static final String HTTP_SERVED_FROM_DISK="HttpServedFromDisk";
	public static final String LD_FOUND_COUNT="LDFoundCount";
	public static final String LD_NOT_FOUND_COUNT="LDNotFoundCount";
	public static final String MAX_SERVING_COUNT="MaxServingCount";
	public static final String REQUESTS="Requests";
	public static final String REQUESTS_ABORTED="RequestsAborted";
	public static final String REQUESTS_IN_PROGRESS="RequestsInProgress";
	public static final String REQUESTS_NOT_FOUND="RequestsNotFound";
	public static final String REQUESTS_OVERFLOW="RequestsOverflow";
	public static final String REQUESTS_PROCESSED="RequestsProcessed";
	public static final String SEP_FOUND_COUNT="SEPFoundCount";
	public static final String SEP_NOT_FOUND_COUNT="SEPNotFoundCount";
	public static final String SIP_FOUND_COUNT="SIPFoundCount";
	public static final String SIP_NOT_FOUND_COUNT="SIPNotFoundCount";
	public static final String SEGMENTS_ACKNOWLEDGED="SegmentsAcknowledged";
	public static final String SEGMENTS_FROM_DISK="SegmentsFromDisk";
	public static final String SEGMENTS_SENT="SegmentsSent";
	public static final String SOFTKEY_CHANGE_NOTIFICATIONS="SoftkeyChangeNotifications";
	public static final String UNIT_CHANGE_NOTIFICATIONS="UnitChangeNotifications";
	
	//Cisco TFTP QOS end
	
	
	public static final String DB_CHANGE_NOTIFICATION_CLIENT="DB Change Notification Client";
	public static final String IP="IP";
	public static final String DB_CHANGE_NOTIFICATION_SERVER="DB Change Notification Server";
	public static final String NETWORK_INTERFACE="Network Interface";
	public static final String NUMBER_OF_REPLICATES_CREATED_AND_STATE_OF_REPLICATION="Number of Replicates Created and State of Replication";
	public static final String PARTITION="Partition";
	public static final String PROCESS="Process";
	public static final String SYSTEM="System";
	
	public static final String CISCO_AXL_WEB_SERVICE="Cisco AXL Web Service";
	public static final String RAMFS="Ramfs";
	public static final String CISCO_ANALOG_ACCESS="Cisco Analog Access";
	public static final String CISCO_ANNUCIATOR_DEVICE="Cisco Annunciator Device";
	public static final String CISCO_CALL_RESTRICTION="Cisco Call Restriction";
	
	public static final String CISCO_CALLMANAGER_SYSTEM_PERFORMANCE="Cisco CallManager System Performance";
	public static final String CISCO_CTI_MANAGER="Cisco CTI Manager";
	public static final String CISCO_DUAL_MODE_MOBILITY="Cisco Dual-Mode Mobility";
	public static final String CISCO_EXTENSION_MOBILITY="Cisco Extension Mobility";
	public static final String CISCO_GATEKEEPER="Cisco Gatekeeper";
	
	public static final String CISCO_HUNT_LISTS="Cisco Hunt Lists";
	public static final String CISCO_HW_CONFERENCE_BRIDGE_DEVICE="Cisco HW Conference Bridge Device";
	public static final String CISCO_IP_MANAGER_ASSISTANT="Cisco IP Manager Assistant";
	public static final String CISCO_LBM_SERVICE="Cisco LBM service";
	public static final String CISCO_LINES="Cisco Lines";
	public static final String CISCO_LOCATIONS_LBM="Cisco Locations LBM";
	public static final String CISCO_LOCATIONS_RSVP="Cisco Locations RSVP";
	public static final String CISCO_MEDIA_STREAMING_APP="Cisco Media Streaming App";
	public static final String CISCO_MESSAGING_INTERFACE="Cisco Messaging Interface";
	public static final String CISCO_MGCP_BRI_DEVICE="Cisco MGCP BRI Device";
	
	
	
	public static final String CISCO_MGCP_PRI_DEVICE="Cisco MGCP PRI Device";
	public static final String CISCO_MGCP_T1CAS_DEVICE="Cisco MGCP T1CAS Device";
	public static final String CISCO_MOBILITY_MANAGER="Cisco Mobility Manager";
	public static final String CISCO_MOH_DEVICE="Cisco MOH Device";
	
	public static final String CISCO_PRESENCE_FEATURES="Cisco Presence Features";
	public static final String CISCO_QSIG_FEATURES="Cisco QSIG Features";
	public static final String CISCO_SIGNALING="Cisco Signaling";
	
	public static final String CISCO_SIP_LINE_NORMALIZATION="Cisco SIP Line Normalization";
	public static final String CISCO_SIP_NORMALIZATION="Cisco SIP Normalization";
	public static final String CISCO_SIP_STACK="Cisco SIP Stack";
	public static final String CISCO_SIP_STATION="Cisco SIP Station";
	public static final String CISCO_SW_CONF_BRIDGE_DEVICE="Cisco SW Conf Bridge Device";
	public static final String CISCO_TELEPRESENCE_MCU_CONFERENCE_BRIDGE_DEVICE="Cisco Telepresence MCU Conference Bridge Device";
	
	public static final String CISCO_TRANSCODE_DEVICE="Cisco Transcode Device";
	public static final String CISCO_VIDEO_CONFERENCE_BRIDGE_DEVICE="Cisco Video Conference Bridge Device";
	public static final String CISCO_WEBDIALER="Cisco WebDialer";
	public static final String CISCO_WSMCONNECTOR="Cisco WSMConnector";
	public static final String IME_CLIENT="IME Client";
	public static final String IME_CLIENT_INSTANCE="IME Client Instance";
	public static final String IME_SAML_SSO="SAML SSO";
	public static final String CISCO_CLIENT_PROFILE_AGENT="Cisco Client Profile Agent";
	public static final String CISCO_PRESENCE_ENGINE="Cisco Presence Engine";
	public static final String CISCO_SERVER_RECOVERY_MANAGER="Cisco Server Recovery Manager";
	public static final String CISCO_SIP_PROXY="Cisco SIP Proxy";
	public static final String CISCO_SYNC_AGENT="Cisco Sync Agent";
	public static final String CISCO_XCP_AUTH_COMPONENT="Cisco XCP Auth Component";
	public static final String CISCO_XCP_CM="Cisco XCP CM";
	public static final String CISCO_XCP_COMPONENT_STANZA_TRAFFIC="Cisco XCP Component Stanza Traffic";
	public static final String CISCO_XCP_JDS="Cisco XCP JDS";
	public static final String CISCO_XCP_JSM="Cisco XCP JSM";
	public static final String CISCO_XCP_JSM_IQ_NAMESPACES="Cisco XCP JSM IQ Namespaces";
	public static final String CISCO_XCP_JSM_SESSION="Cisco XCP JSM Session";
	public static final String CISCO_XCP_MA_BASIC="Cisco XCP MA Basic";
	public static final String CISCO_XCP_ROUTER="Cisco XCP Router";
	public static final String CISCO_XCP_SIP_S2S="Cisco XCP SIP S2S";
	public static final String CISCO_XCP_S2S="Cisco XCP S2S";
	public static final String CISCO_XCP_TC="Cisco XCP TC";
	public static final String CISCO_XCP_TC_ROOM="Cisco XCP TC Room";
	public static final String CISCO_XCP_WEBCM="Cisco XCP WebCM";
	public static final String CUC_DATA_STORE="CUC Data Store";
	public static final String CUC_DATA_STORE_DATABASES="CUC Data Store: Databases";
	public static final String CUC_DIGITAL_NOTIFICATIONS="CUC Digital Notifications";
	public static final String CUC_DIRECTORY_SERVICES="CUC Directory Services";
	public static final String CUC_FEEDER="CUC Feeder";
	public static final String CUC_MAILBOX_SYNC="CUC Mailbox Sync";
	public static final String CUC_MESSAGE_STORE="CUC Message Store";
	public static final String CUC_MESSAGE_STORE_DATABASES="CUC Message Store: Databases";
	public static final String CUC_PERSONAL_CALL_TRANSFER_RULES="CUC Personal Call Transfer Rules";
	public static final String CUC_PHONE_SYSTEM="CUC Phone System";
	public static final String CUC_PHONE_SYSTEM_PORTS="CUC Phone System: Ports";
	public static final String CUC_REPLICATION="CUC Replication";
	public static final String CUC_REPLICATOR_REMOTE_CONNECTION_LOCATIONS="CUC Replicator: Remote Connection Locations";
	public static final String CUC_SESSIONS_CALENDAR_ACCESS="CUC Sessions: Calendar Access";
	public static final String CUC_SESSIONS_EMAIL_ACCESS="CUC Sessions: E-Mail Access";
	public static final String CUC_SESSIONS_IMAP_SERVER="CUC Sessions: IMAP Server";
	public static final String CUC_SESSIONS_RSS="CUC Sessions: RSS";
	public static final String CUC_SESSIONS_SMTP_SERVER="CUC Sessions: SMTP Server";
	public static final String CUC_SESSIONS_SPEECH_VIEW_PROCESSOR="CUC Sessions: SpeechView Processor";
	public static final String CUC_SESSIONS_TRAP="CUC Sessions: TRaP";
	public static final String CUC_SESSIONS_TTS="CUC Sessions: TTS";
	public static final String CUC_SESSIONS_UNIFIED_CLIENT="CUC Sessions: Unified Client";
	public static final String CUC_SESSIONS_VIDEO="CUC Sessions: Video";
	public static final String CUC_SESSIONS_VOICE="CUC Sessions: Voice";
	public static final String CUC_SESSIONS_VUI="CUC Sessions: VUI";
	public static final String CUC_SESSIONS_WEB="CUC Sessions: Web";
	public static final String CUC_SESSIONS_WEB_EMAIL_ACCESS="CUC Sessions: Web E-Mail Access";
	public static final String CUS_SYSTEM_AGENT="CUC System Agent";
}
