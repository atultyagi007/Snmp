package com.hcl.probe;

import java.util.ArrayList;

public class IndexElement {
	private ArrayList<String> indexList;
	private ArrayList<String> descList;
	private ArrayList<OidForm> oidFormList;
	public ArrayList<String> getIndexList() {
		return indexList;
	}
	public void setIndexList(ArrayList<String> indexList) {
		this.indexList = indexList;
	}
	public ArrayList<String> getDescList() {
		return descList;
	}
	public void setDescList(ArrayList<String> descList) {
		this.descList = descList;
	}
	public ArrayList<OidForm> getOidFormList() {
		return oidFormList;
	}
	public void setOidFormList(ArrayList<OidForm> oidFormList) {
		this.oidFormList = oidFormList;
	}
	

}
